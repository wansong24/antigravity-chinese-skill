(function() {
  try {
    window.__AGY_I18N_DATA__ = {
  "exact": {
    ", or": "，或",
    ", or ": "，或 ",
    "? This removes it from your config directory.": "吗？这将从您的配置目录中将其移除。",
    "\"Always Proceed\"": "“总是直接继续”",
    "(Archived)": "（已归档）",
    "+ Add folder": "+ 添加文件夹",
    "+ Add Folder": "+ 添加文件夹",
    "+ Add Hook": "+ 添加钩子",
    "+ Add Project Folder": "+ 添加项目文件夹",
    "+ New": "+ 新建",
    "+ New Chat": "+ 新建对话",
    "1 agent running": "1 个正在运行的智能体",
    "1 Comment": "1 条评论",
    "2. Make sure that your selected workspace is synced to head. This ensures that the installed skills are available in your workspace.": "2. 请确保您所选的工作区已同步至最新提交（Head）。这可确保安装的技能在您的工作区中可用。",
    "A copy of the workspace snapshot recorded at this step.": "在此步骤记录的工作区快照副本。",
    "A full copy of this workspace, uncommitted changes included.": "此工作区的完整副本，包含未提交的更改。",
    "A group with this name already exists.": "已存在同名分组。",
    "A new version is available.": "发现新版本可用。",
    "A nickname for identifying this application in the companion website. Changing this will restart the connection.": "用于在配套网站中标识此应用程序的昵称。更改此项将重启连接。",
    "A shell setup script run before every command the agent executes in this project. Overrides the global script.": "在此项目中智能体每次执行命令前运行的 Shell 初始化脚本。将覆盖全局脚本。",
    "A shell setup script run before every command the agent executes.": "智能体每次执行命令前运行的 Shell 初始化脚本。",
    "A snapshot was saved before running. To restore your previous output:": "运行前已保存快照。若要恢复之前的输出：",
    "Aborted": "已中止",
    "About": "关于",
    "about 1 hour": "约 1 小时",
    "About Antigravity": "关于 Antigravity",
    "Accent": "强调色",
    "Accept": "接受",
    "Accept all": "全部接受",
    "Accept Changes": "接受更改",
    "Accept Step": "接受此步骤",
    "Accept Suggestion": "接受建议",
    "Account": "账户",
    "Account Details": "账户详情",
    "Action": "操作",
    "Action required": "需要操作",
    "Action Required": "需要采取操作",
    "Actions": "操作",
    "Active": "活跃",
    "Active Browser page": "活动浏览器页面",
    "Active Browser pages": "活动浏览器页面列表",
    "Activity Bar": "活动栏",
    "Actual behavior": "实际表现",
    "Actuation": "操作执行",
    "Add": "添加",
    "Add a message...": "输入消息...",
    "Add Automation": "添加自动化",
    "Add Comment": "添加评论",
    "Add context": "添加到上下文",
    "Add Context": "添加到上下文",
    "Add context browser": "添加到上下文",
    "Add Context Browser": "添加到上下文",
    "Add Context Picker": "添加上下文",
    "Add Context Server": "添加上下文服务",
    "Add Context Servers": "添加上下文服务",
    "Add context...": "添加上下文...",
    "Add Context...": "添加上下文...",
    "Add Denied Path": "添加禁止路径",
    "Add folder": "添加文件夹",
    "Add Folder": "添加文件夹",
    "Add Hook Card": "添加钩子配置卡片",
    "Add inline comment": "添加内联批注",
    "Add project folder": "添加项目文件夹",
    "Add Project Folder": "添加项目文件夹",
    "Add recent remote workspace": "添加最近使用的远程工作区",
    "Add terminal": "添加终端",
    "Add Terminal": "添加终端",
    "Add to Chat": "添加到对话",
    "Add to Chat/Quote": "添加到对话 / 引用",
    "Add to context": "添加到上下文",
    "Add to Context": "添加到上下文",
    "Add Workspace": "添加工作区",
    "Added (Staged)": "已添加 (暂存)",
    "Adding...": "正在添加...",
    "Address bar": "地址栏",
    "Advanced": "高级",
    "Advanced Search": "高级搜索",
    "Advanced Settings": "高级设置",
    "Agent": "智能体",
    "Agent Auto-Fix Lints": "智能体自动修复 Lint 代码规范错误",
    "Agent Behavior": "智能体行为",
    "Agent can retrieve console logs from the browser and return it for further processing.": "智能体可获取浏览器控制台日志并返回以作进一步处理。",
    "Agent cannot modify files outside of the workspace in strict mode.": "在严格模式下，智能体不能修改工作区以外的文件。",
    "Agent Edits": "智能体代码编辑",
    "Agent encountered an internal error.": "智能体遇到了内部错误。",
    "Agent finished": "智能体已完成",
    "Agent Hooks Configuration": "智能体钩子配置",
    "Agent Host Address": "智能体主机地址",
    "Agent needs permission to execute JavaScript": "智能体需要获准才能执行 JavaScript",
    "Agent options": "智能体选项",
    "Agent response": "智能体回复",
    "Agent Script": "智能体脚本",
    "Agent Script Command Configuration": "智能体脚本命令配置",
    "Agent Settings": "智能体设置",
    "Agent Stopped": "智能体已停止",
    "AI Credits Used to Generate Response": "生成回复所消耗的 AI 积分",
    "All": "全部",
    "All automations run as Flash": "所有自动化任务均以 Flash 模型运行",
    "All automations run as Flash.": "所有自动化任务均以 Flash 模型运行。",
    "All changes since origin/main": "自 origin/main 以来的全部更改",
    "All changes since origin/main.": "自 origin/main 以来的全部更改。",
    "All changes since origin/master": "自 origin/master 以来的全部更改",
    "All conversations": "全部会话",
    "All Files": "所有文件",
    "All plugins run as Flash": "所有插件均以 Flash 模型运行",
    "All plugins run as Flash.": "所有插件均以 Flash 模型运行。",
    "All tools (*)": "所有工具 (*)",
    "Alphabetical (A-Z)": "按字母顺序 (A-Z)",
    "Also includes": "也包含",
    "Also includes global settings when working in this project": "在此项目中工作时也包含全局设置",
    "Also includes global settings when working in this project.": "在此项目中工作时也包含全局设置。",
    "Alt+Enter On empty prompt, sends next in queue": "Alt+Enter 在输入框为空时发送队列中的下一条消息",
    "Alt+Enter Queues after the turn": "Alt+Enter 轮次结束后进入排队",
    "Alt+Enter Sends immediately": "Alt+Enter 立即发送",
    "Alternatively, request the agent to add the skills:": "或者，请求智能体添加所需技能：",
    "Always": "始终",
    "Always proceed": "总是直接继续",
    "Always Proceed": "总是直接继续",
    "Always Require Approval": "始终需要审批",
    "Always run": "始终运行",
    "Amend": "修补提交 (Amend)",
    "Amend succeeded": "修改提交成功",
    "An error occurred while checking the port. Please try again.": "检查端口时发生错误，请重试。",
    "An error occurred while submitting your feedback. Please try again.": "提交反馈时发生错误，请重试。",
    "Analyzed": "已分析",
    "Analyzed content": "已分析内容",
    "Analyzed Task Log": "已分析任务日志",
    "Analyzing": "正在分析",
    "Analyzing content": "正在分析内容",
    "Analyzing Task Log": "正在分析任务日志",
    "Analyzing...": "正在分析...",
    "and select": "并选择",
    "Antigravity Agent": "Antigravity 智能体",
    "Antigravity would like to use the browser.": "Antigravity 请求使用浏览器。",
    "Any error messages": "任何错误提示或异常报错",
    "Any error messages seen when trying to log in": "登录时看到的任何错误信息",
    "Any relevant information": "其他任何相关信息或上下文",
    "API Endpoint": "API 端点接口",
    "API Key": "API 密钥",
    "API Key is configured": "API 密钥已配置",
    "App": "应用设置",
    "App Data Directory": "应用数据保存路径",
    "App Settings": "应用设置",
    "App version": "应用版本",
    "Application": "应用设置",
    "Apply": "应用",
    "Approve": "批准",
    "Approved": "已批准",
    "Archive": "归档",
    "Archive / Restore": "归档 / 恢复",
    "Archive conversation": "归档会话",
    "Archive Conversation": "归档会话",
    "Archive Environment": "归档环境",
    "Archive project": "归档项目",
    "Archive this conversation": "归档此会话",
    "Archive This Conversation": "归档此会话",
    "Archive Workspace": "归档工作区",
    "Archived": "已归档",
    "Are you sure you want to delete this conversation? This action cannot be undone.": "确定要删除此会话吗？此操作无法撤销。",
    "Are you sure you want to delete this hook card?": "确定要删除此钩子配置卡片吗？",
    "Are you sure you want to delete this project?": "您确定要删除此项目吗？",
    "Are you sure you want to mark 1 conversation as read? This action cannot be undone.": "您确定要将 1 个会话标记为已读吗？此操作无法撤销。",
    "Are you sure you want to quit?": "您确定要退出吗？",
    "around": "大约",
    "Artifact": "产物",
    "Artifact Comments": "产物评论",
    "Artifacts": "产物文档",
    "Ask a quick question without interrupting the main conversation.": "在不打断主会话的情况下快速提问。",
    "At mention code block": "在对话中引用代码块",
    "At Mention Code Block": "在对话中引用代码块",
    "Attach a screenshot": "附上屏幕截图",
    "Attach a screenshot (optional)": "附上屏幕截图（可选）",
    "Attach Antigravity server logs": "附加 Antigravity 服务端运行日志",
    "Attach screenshot (optional)": "附上屏幕截图（可选）",
    "Attach screenshots": "附上屏幕截图",
    "Audio File": "音频文件",
    "Auth and Billing": "身份验证与计费",
    "Authenticated": "已认证",
    "Authenticated via Enterprise Gateway": "已通过企业网关认证",
    "Authenticating...": "正在认证...",
    "Authentication Required": "需要身份认证",
    "Auto (detected)": "自动 (已检测)",
    "Auto Check for Updates": "自动检查更新",
    "Auto Update": "自动更新",
    "Auto-Approve Safe Actions": "自动批准安全操作",
    "Auto-Captured": "自动捕获",
    "Auto-Expand Changes Overview": "自动展开代码更改概览",
    "Auto-Open Edited Files": "自动打开已编辑文件",
    "Automatic": "自动",
    "Automatic Check for Updates": "自动检查更新",
    "Automatically check for updates": "自动检查更新",
    "Automatically download and install updates": "自动下载并安装更新",
    "Automatically expand the Changes Overview toolbar when the agent finishes generating a response.": "当智能体完成回复生成时，自动展开代码更改概览工具栏。",
    "Automatically prompt you to restart the app when a new update is available. When disabled, you can check for updates manually from the app menu.": "当有新版本可用时，自动提示您重启应用程序完成更新。禁用后，您仍可随时从应用菜单手动检查更新。",
    "automation": "自动化任务",
    "Automation": "自动化",
    "Automations": "自动化",
    "Autonomous": "自主模式",
    "Autonomous Execution": "自主执行模式",
    "Autonomous mode": "自主模式",
    "Autonomous Mode": "自主模式",
    "Autonomous mode active: the agent works independently and does not ask questions or request new permissions.": "自主模式已激活：智能体将独立工作，不会提问或请求新权限。",
    "Autopush": "Autopush 自动推送版",
    "Awaiting Authentication...": "正在等待认证...",
    "Back": "返回",
    "Back to home": "返回首页",
    "Background": "背景色",
    "Bad clarification": "澄清提问不当",
    "bad response": "不佳回答",
    "Bad response": "不佳回答",
    "Bad Response": "较差回复",
    "BAD RESPONSE": "不佳回答",
    "Balanced": "平衡模式",
    "Base URL": "基础请求 URL",
    "Battle mode": "对决模式",
    "Battle Mode": "对决模式",
    "Battle Mode Infos": "对决模式信息",
    "Battle Mode Overrides": "对决模式参数重载",
    "Battle Mode requires at least one commit in the Git repository": "对决模式要求 Git 仓库中至少包含一次提交",
    "Battle Mode requires at least one commit in the Git repository.": "对决模式要求 Git 仓库中至少包含一次提交。",
    "Best of N": "多候选对决",
    "Best of N mode": "多候选对决模式",
    "Best of N Mode": "多候选对决模式",
    "Best of N mode is not available": "多候选对决模式不可用",
    "Best-of-N": "多候选对决 (Best-of-N)",
    "Best-of-N Ended": "多选最优模式已结束",
    "Best-of-N mode": "多候选对决模式",
    "Best-of-N Mode": "多候选对决模式",
    "Best-of-N Started": "多选最优模式已开始",
    "Beta": "测试版 (Beta)",
    "Better code quality": "代码质量更高",
    "Better instruction following": "更好地遵循了指令",
    "Binary file": "二进制文件",
    "Block all browser JavaScript execution": "禁止执行所有浏览器 JavaScript 脚本",
    "Block all browser JavaScript execution.": "禁止执行所有浏览器 JavaScript 脚本。",
    "Blocked": "已受阻",
    "Blocked on Your Input": "等待您的输入反馈",
    "Blocked Terminal Commands": "已阻止的终端命令",
    "Blocked, needs input": "已受阻，需要输入",
    "Both are bad": "两项均表现不佳",
    "Both are good": "两项均表现优秀",
    "Both were bad": "两项均表现不佳",
    "Both were good": "两项均表现优秀",
    "Branch": "分支",
    "Branch Changes": "分支更改",
    "Branch main": "分支 main",
    "Branch name can only contain letters, numbers, underscores, dashes, dots, and slashes": "分支名称只能包含字母、数字、下划线、横线、点和斜杠",
    "Browse": "浏览",
    "Browse and enable plugins from the Build With Google catalog.": "浏览并启用 Build With Google 目录中的插件。",
    "Browse the Marketplace": "浏览插件市场",
    "Browser": "浏览器",
    "Browser Actuation Rules": "浏览器操作执行规则",
    "Browser Agent Settings": "浏览器智能体设置",
    "Browser Automation": "浏览器自动化",
    "Browser Launch Args": "浏览器启动参数",
    "Browser Settings": "浏览器设置",
    "Browser settings have moved": "浏览器设置已迁移",
    "Browser settings have moved to the Browser section of General settings": "浏览器设置已迁移至“通用设置”中的“浏览器”板块",
    "Browser settings have moved to the Browser section of General settings.": "浏览器设置已迁移至“通用设置”中的“浏览器”板块。",
    "Browser settings have moved to the Browser section of General settings. Go to General settings": "浏览器设置已迁移至“通用设置”中的“浏览器”板块。前往通用设置",
    "Browser settings have moved to the Browser section of General settings. Go to General settings.": "浏览器设置已迁移至“通用设置”中的“浏览器”板块。前往通用设置。",
    "Browser task": "浏览器任务",
    "Browser Task": "浏览器任务",
    "Browser tools (browser_.*)": "浏览器工具 (browser_.*)",
    "Browser tools are disabled in the Antigravity Android desktop app.": "浏览器工具在 Antigravity Android 桌面应用中已禁用。",
    "Browser tools are not available in the Antigravity Android desktop app.": "浏览器工具在 Antigravity Android 桌面应用中不可用。",
    "Browser User Profile Path": "浏览器用户配置文件路径",
    "Browser Viewport Height": "浏览器视口高度",
    "Bug Report": "问题报告 (Bug)",
    "Build applications with the Gemini Interactions API and Live API including text generation, multi-turn chat, streaming, function calling, managed agents, and real-time audio and video.": "使用 Gemini Interactions API 和 Live API 构建应用，包括文本生成、多轮对话、流式传输、函数调用、托管智能体以及实时音视频。",
    "Build With Google Plugins": "Build With Google 插件目录",
    "Building": "正在构建",
    "Built In": "内置",
    "Built-in Skills": "内置技能",
    "Bundled With the App": "应用内置随附",
    "By step type": "按步骤类型",
    "By using this app, you agree to its": "使用此应用即表示您同意其",
    "By using this app, you agree to its Terms of Service": "使用此应用即表示您同意其服务条款",
    "Bypass Proxy For": "以下地址不使用代理",
    "Cache": "缓存",
    "Cancel": "取消",
    "Cancel (Cmd+D)": "取消 (Cmd+D)",
    "Cancel (Ctrl+D)": "取消 (Ctrl+D)",
    "Cancel All Tasks": "取消所有任务",
    "Cancel questionnaire": "取消问卷",
    "Cancel questionnaire and stop the agent": "取消问卷并停止智能体",
    "Cancel recording": "取消录音",
    "Cancel step": "取消步骤",
    "Cancel Step": "取消步骤",
    "Cancel task": "取消任务",
    "Cancel Task": "取消任务",
    "Canceled": "已取消",
    "Canceling": "正在取消",
    "Candidate": "候选方案",
    "Candidate 1": "候选方案 1",
    "Candidate 2": "候选方案 2",
    "Candidate A": "候选方案 A",
    "Candidate B": "候选方案 B",
    "Candidate C": "候选方案 C",
    "Candidates": "候选方案",
    "Cannot parse folder URI.": "无法解析文件夹 URI。",
    "Cannot reroll a turn that was cleared to save space": "无法重新生成为节省空间已清除的轮次",
    "Cannot revert messages before or at the point where Best of N mode was triggered": "无法撤回触发多候选对决模式 (Best-of-N) 之前或当时的消息",
    "Cannot revert messages with artifact comments": "无法撤回包含产物评论的消息",
    "Cannot revert messages with file diff comments": "无法撤回包含文件差异评论的消息",
    "Cannot revert this message": "无法撤回此消息",
    "Cannot revert to a message that was cleared to save space": "无法还原到为节省空间已清除的消息",
    "Cannot send message to subagent.": "无法向子智能体发送消息。",
    "Cannot store content under the reserved new-tab id": "无法在保留的 new-tab ID 下存储内容",
    "Capture console logs": "捕获控制台日志",
    "Capture screenshot": "截取屏幕截图",
    "Capturing": "正在截取",
    "Changes": "更改",
    "Chat anyways": "仍然对话",
    "Chat Settings": "对话设置",
    "Check again": "再次检查",
    "Check for Updates": "检查更新",
    "Check for Updates Automatically": "自动检查软件更新",
    "Check for Updates on Startup": "启动时检查更新",
    "Check for Updates...": "检查更新...",
    "Check pending conversations in the last 3 days that require action from me.": "检查最近 3 天内需要我处理的待办会话。",
    "Checked command status": "已检查命令状态",
    "Checking command status": "正在检查命令状态",
    "Checking for updates...": "正在检查更新...",
    "Checking for updates…": "正在检查更新...",
    "Checking...": "正在检查...",
    "Checkpoint": "检查点",
    "Child Subagent": "下级子智能体",
    "Choose the product skin that fits how you work.": "选择适合您工作方式的产品界面风格。",
    "Choose winner": "选择优胜方案",
    "Choose Winner": "选择优胜方案",
    "Chrome Binary Path": "Chrome 可执行文件路径",
    "CitC Workspace Type": "CitC 工作区类型",
    "CL details unavailable": "CL 详情不可用",
    "Cleanup Script": "清理脚本",
    "Clear": "清除",
    "Clear all": "全部清除",
    "Clear Cache": "清理缓存",
    "Clear Cache and Reload": "清理缓存并重新加载",
    "Clear Chat History": "清空对话历史",
    "Clear Conversation": "清空会话",
    "Clear filter": "清除筛选",
    "Clear History": "清除历史",
    "Clear queue": "清空队列",
    "Clear search": "清除搜索",
    "Clear Search": "清除搜索",
    "Clear Terminal": "清空终端",
    "CLI Project": "CLI 项目",
    "Click to copy full command": "点击复制完整命令",
    "Click to copy URL": "点击复制链接",
    "Click to learn more about sources": "点击了解更多关于来源的信息",
    "Click to open docs": "点击打开文档",
    "Click to Open Docs": "点击打开文档",
    "Click to view more": "点击查看更多",
    "Clicked in Browser": "已在浏览器中点击",
    "Clicking in Browser": "正在浏览器中点击",
    "Client": "客户端",
    "Clone current workspace into a new independent workspace": "将当前工作区克隆为新的独立工作区",
    "Close": "关闭",
    "Close Logs Modal": "关闭日志弹窗",
    "Close panel": "关闭面板",
    "Close Settings": "关闭设置",
    "Close Sidebar": "关闭侧边栏",
    "Close skills panel": "关闭技能面板",
    "Close split view and go to forked conversation": "关闭分栏视图并前往派生会话",
    "Close Tab": "关闭标签页",
    "Close Terminal Tab": "关闭终端标签页",
    "Close Window": "关闭窗口",
    "Cmd+Enter Queues after the turn": "Cmd+Enter 轮次结束后进入排队",
    "Cmd+Enter Sends immediately": "Cmd+Enter 立即发送",
    "Code Change Summary": "代码变更摘要",
    "Code search": "代码搜索",
    "Code Search": "代码搜索",
    "Code search is not available.": "代码搜索不可用。",
    "Code snippet": "代码片段",
    "Collapse": "折叠",
    "Collapse (shift+click to collapse every level below)": "折叠（按住 Shift 点击可折叠下方所有层级）",
    "Collapse all": "全部折叠",
    "Collapse All": "全部折叠",
    "Collapse All Folders": "全部折叠文件夹",
    "Collapse queued messages": "折叠排队中的消息",
    "Collapse subagents": "折叠子智能体",
    "Collapse toast": "折叠通知提示",
    "Command execution": "命令执行",
    "Command Palette": "命令面板",
    "Command picker": "命令选择器",
    "Command Setup Script": "命令初始配置脚本",
    "Comment": "评论",
    "Comment on Selection": "针对所选内容添加批注",
    "Commented on:": "评论于：",
    "Comments": "评论",
    "Commit": "提交",
    "Commit succeeded": "提交成功",
    "Communication": "沟通表达",
    "Compact Mode": "紧凑模式",
    "Compacting": "正在压缩上下文",
    "companion website": "配套网页端",
    "Companion Website": "配套网页端",
    "Complete Onboarding Step": "完成新手入门步骤",
    "Complete verification": "完成验证",
    "Completed": "已完成",
    "Configuration": "配置",
    "Configure": "配置",
    "Configure automations": "配置自动化",
    "Configure Automations": "配置自动化",
    "Configure Branches": "配置分支",
    "Configure browser subagent": "配置浏览器子智能体",
    "Configure browser subagent .": "配置浏览器子智能体。",
    "Configure browser subagent.": "配置浏览器子智能体。",
    "Configure tab completion, suggestions, and navigation behavior.": "配置 Tab 代码补全、建议及导航行为。",
    "Configure Terminal Settings": "配置终端设置",
    "Configure the browser subagent": "配置浏览器子智能体",
    "Configure the browser subagent .": "配置浏览器子智能体。",
    "Configure the browser subagent.": "配置浏览器子智能体。",
    "Configure the browser subagent. It requires Google Chrome to be installed.": "配置浏览器子智能体。需要系统中已安装 Google Chrome 浏览器。",
    "Configure when follow-up messages are sent.": "配置后续追问消息的发送时机。",
    "Configure Worktree Branches": "配置工作树分支",
    "Confirm": "确认",
    "Confirm Browser Interaction": "确认浏览器交互",
    "Confirm Quit": "确认退出",
    "Confirm the command is safe to run": "确认该命令可安全运行",
    "Confirm Undo": "确认撤销",
    "Confirm Window Reload": "确认重新加载窗口",
    "Confirmation required to execute this step": "执行此步骤需要您的确认",
    "Conflict": "冲突",
    "Connected": "已连接",
    "Connecting to terminal...": "正在连接终端...",
    "Connection": "连接",
    "Connection Failed": "连接失败",
    "Connection Successful": "连接成功",
    "Console logs": "控制台日志",
    "Context": "上下文",
    "Context browser": "上下文浏览器",
    "Context Browser": "上下文浏览器",
    "Context Length Limit": "上下文长度上限",
    "Context usage": "上下文占用",
    "Context Window": "上下文窗口大小",
    "Continue": "继续",
    "Continue Response": "继续生成回复",
    "Continue with Advanced SSO": "通过高级 SSO 继续",
    "Continue with different account": "使用其他账号继续",
    "Continue with Google": "通过 Google 继续",
    "Continue with Google Cloud": "通过 Google Cloud 继续",
    "Continuous Execution": "连续执行模式",
    "Continuous Mode": "持续模式",
    "Contrast": "对比度",
    "Controls the actions the agent can take": "控制智能体可以执行的操作",
    "Controls the actions the agent can take.": "控制智能体可以执行的操作。",
    "Controls whether terminal commands require your approval before running.": "控制终端命令在执行前是否需要您的批准。",
    "Controls whether the agent can run custom JavaScript to automate complex browser actions.": "控制智能体是否可以运行自定义 JavaScript 来实现复杂的浏览器自动化操作。",
    "Conversation": "会话",
    "Conversation Archived": "会话已归档",
    "Conversation copied as Markdown to clipboard": "会话已作为 Markdown 复制到剪贴板",
    "Conversation History": "历史会话",
    "Conversation ID": "会话 ID",
    "Conversation Log": "会话日志",
    "Conversation name": "会话名称",
    "Conversation Name": "会话名称",
    "Conversation picker": "会话选择器",
    "Conversation Sharing": "会话共享",
    "Conversation Telemetry": "会话遥测信息",
    "Conversation unavailable": "会话不可用",
    "Conversations": "会话列表",
    "Copied": "已复制",
    "Copied error": "已复制错误信息",
    "Copied error to clipboard": "已复制错误信息到剪贴板",
    "Copied!": "已复制！",
    "Copy": "复制",
    "Copy as Markdown": "复制为 Markdown",
    "copy code": "复制代码",
    "Copy code": "复制代码",
    "Copy Code": "复制代码",
    "copy command": "复制命令",
    "Copy Command": "复制命令",
    "COPY COMMAND": "复制命令",
    "Copy config file path": "复制配置文件路径",
    "Copy Config File Path": "复制配置文件路径",
    "Copy Content": "复制内容",
    "Copy Conversation ID": "复制会话 ID",
    "Copy conversation markdown": "复制会话 Markdown",
    "Copy Conversation Markdown": "复制会话 Markdown",
    "Copy debug info": "复制调试信息",
    "Copy error": "复制错误信息",
    "Copy error messages": "复制错误消息",
    "Copy error to clipboard": "复制错误信息到剪贴板",
    "Copy File Name": "复制文件名",
    "Copy File Path": "复制文件路径",
    "Copy full URL to clipboard": "复制完整 URL 到剪贴板",
    "Copy Image": "复制图片",
    "Copy Last Response": "复制最后一条回复",
    "copy link": "复制链接",
    "Copy link": "复制链接",
    "Copy Link": "复制链接",
    "Copy output": "复制输出",
    "copy path": "复制路径",
    "Copy path": "复制路径",
    "Copy Path": "复制路径",
    "Copy project": "复制项目",
    "copy project name": "复制项目名称",
    "Copy project name": "复制项目名称",
    "Copy Project Name": "复制项目名称",
    "Copy project path": "复制项目路径",
    "Copy Project Path": "复制项目路径",
    "Copy raw string value": "复制原始字符串值",
    "Copy Sidecar ID": "复制 Sidecar ID",
    "Copy the folder elsewhere first if you might want it back.": "如果后续可能还需要该内容，请先将文件夹备份至其他位置。",
    "Copy the trajectory ID": "复制执行轨迹 ID",
    "Copy this subtree JSON": "复制该子树 JSON",
    "Copy to clipboard": "复制到剪贴板",
    "Copy trajectory ID": "复制轨迹 ID",
    "Copy value": "复制值",
    "Copy workspace": "复制工作区",
    "Core tools and knowledge required to develop for Android": "开发 Android 应用所需的核心工具与知识",
    "Correct code": "代码准确无误",
    "Correctness": "准确性",
    "Could not create project": "无法创建项目",
    "Create": "创建",
    "Create a Plugin with the Agent": "与智能体一起创建插件",
    "Create Automation": "创建自动化",
    "Create conversation": "新建会话",
    "Create Conversation": "新建会话",
    "Create fork in current workspace": "在当前工作区中创建分支副本",
    "Create fork in new workspace": "在全新工作区中创建分支副本",
    "Create fork in shared workspace": "在共享工作区中创建分支副本",
    "Create Group": "创建分组",
    "Create New": "新建",
    "Create new conversation": "新建会话",
    "Create New Conversation": "新建会话",
    "Create new project": "新建项目",
    "Create New Project": "新建项目",
    "Create project": "创建项目",
    "Create Project": "创建项目",
    "Created": "创建于",
    "Created a new branch on GitHub.": "已在 GitHub 上创建新分支。",
    "Created a new branch on Origin.": "已在远程源 (Origin) 上创建新分支。",
    "Created outline": "已创建大纲",
    "Creating": "正在创建",
    "Creating environment...": "正在创建环境...",
    "Creating Fork...": "正在创建分支派生...",
    "Creating terminal...": "正在创建终端...",
    "Creating the forked conversation...": "正在创建分叉会话...",
    "Ctrl+Enter Queues after the turn": "Ctrl+Enter 轮次结束后进入排队",
    "Ctrl+Enter Sends immediately": "Ctrl+Enter 立即发送",
    "Curated collection of agent skills for science tasks.": "精选用于科学计算与科研任务的智能体技能集合。",
    "Current Page": "当前页面",
    "Current Plan": "当前套餐",
    "Current workspace": "当前工作区",
    "Current Workspace": "当前工作区",
    "Cursor Blinking": "光标闪烁样式",
    "Custom": "自定义",
    "Custom Agents": "自定义智能体",
    "Custom agents are not available in Best of N mode.": "多候选对决模式下不支持使用自定义智能体。",
    "Custom for this project": "为此项目单独配置",
    "Custom Skills": "自定义技能",
    "Custom System Prompt": "自定义系统提示词",
    "Custom Title Bar": "自定义标题栏",
    "customization budget is available": "自定义扩展预算可用",
    "customization budget is available.": "自定义扩展预算可用。",
    "Customization Rules": "自定义规则",
    "Customization token budget exceeded. Large customizations will be truncated.": "已超出自定义扩展的 Token 预算。超长自定义项将被截断。",
    "Customizations": "自定义扩展",
    "Customize": "自定义",
    "Customize Global Skills": "自定义全局技能",
    "Cut": "剪切",
    "Cycle detected": "检测到循环",
    "Daily": "每天",
    "Daily Request Limit": "每日请求上限",
    "Danger Zone": "危险区域",
    "Dark": "深色",
    "Date Added": "添加日期",
    "Debug Console": "调试控制台",
    "Debug Mode": "调试模式",
    "Decline": "拒绝",
    "Decorations": "装饰标识",
    "Default": "默认",
    "Default Customizations": "默认自定义扩展",
    "Default Dark": "默认深色",
    "Default Execution Mode": "默认执行模式",
    "Default Light": "默认浅色",
    "Delete": "删除",
    "Delete agent": "删除智能体",
    "Delete Automation": "删除自动化",
    "Delete command": "删除命令",
    "Delete comment": "删除批注",
    "Delete Conversation": "删除会话",
    "Delete Group": "删除分组",
    "Delete Handler": "删除处理器",
    "Delete Hook": "删除钩子",
    "Delete Permanently": "永久删除",
    "Delete plugin": "删除插件",
    "Delete Project": "删除项目",
    "Delete server": "删除服务",
    "Delete side question": "删除旁路提问",
    "Delete Skill": "删除技能",
    "Delete Terminal": "删除终端",
    "Delete this project": "删除此项目",
    "Delete this project.": "删除此项目。",
    "Delete Workspace": "删除工作区",
    "Deleting": "正在删除",
    "Deny setting up browser": "拒绝设置浏览器",
    "Describe the bug you encountered...": "请详细描述您遇到的问题或缺陷…",
    "Description": "描述",
    "Deselect All": "取消全选",
    "Details": "详情",
    "Developer-only tools. These settings are stored locally in this browser and do not affect other users.": "仅限开发者的工具。这些设置仅保存在此浏览器本地，不影响其他用户。",
    "Device Name": "设备名称",
    "DevTools port is still closed. Please make sure Chrome is running with remote debugging enabled.": "DevTools 端口仍处于关闭状态。请确保 Chrome 正在运行且已启用远程调试。",
    "Did what I wanted": "符合预期诉求",
    "Diff Options": "差异选项",
    "Directories": "目录",
    "Directory": "目录",
    "Disable": "禁用",
    "Disable Plugin": "禁用插件",
    "Disable Recommended Skills": "禁用推荐技能",
    "Disabled": "已禁用",
    "Disables all safety barriers for maximal iteration velocity.": "禁用所有安全屏障，最大化迭代速度。",
    "Discard": "放弃修改",
    "Discard Changes": "放弃所有更改",
    "Discard unstaged changes": "放弃未暂存的更改",
    "Disconnected": "已断开连接",
    "Discover helpful skills & plugins": "发现实用技能与插件",
    "Discover Skills": "发现技能",
    "Dismiss": "关闭",
    "Dismiss announcement": "关闭公告",
    "Dismiss error": "关闭错误",
    "Dismiss Skills": "忽略技能提示",
    "Dismiss text selection notice": "关闭文本选择通知",
    "Dismiss Tip": "忽略提示",
    "Dismiss toast": "忽略通知提示",
    "Docs": "官方文档",
    "Document": "文档",
    "Document Answers": "文档解答",
    "Documentation": "官方文档",
    "Documents": "文档",
    "Don't show this for 2 days": "2 天内不再显示",
    "Done": "完成",
    "Download": "下载",
    "Download Diagnostics": "下载诊断日志",
    "Download SVG": "下载 SVG",
    "Download Updates Automatically": "自动下载更新包",
    "Downloading Update": "正在下载更新",
    "Downloading update...": "正在下载更新...",
    "Downloading update…": "正在下载更新...",
    "Downloading...": "正在下载...",
    "Draft": "草稿",
    "Drag to resize, double-click to reset": "拖动以调整大小，双击以重置",
    "Drag to select a region to comment": "拖拽选择区域以添加评论",
    "Dragged in Browser": "已在浏览器中拖拽",
    "Dragging in Browser": "正在浏览器中拖拽",
    "Edit": "编辑",
    "Edit Automation": "编辑自动化",
    "Edit comment": "编辑评论",
    "Edit Comment": "编辑评论",
    "Edit config": "编辑配置",
    "Edit conversation title": "编辑会话标题",
    "Edit Conversation Title": "编辑会话标题",
    "Edit Model": "编辑模型",
    "Edit task title": "编辑任务标题",
    "Edit title": "编辑标题",
    "Edit Title": "编辑标题",
    "Edited": "已编辑",
    "Editing": "正在编辑",
    "Elegant code": "代码优雅整洁",
    "Email": "电子邮箱",
    "Empty directory": "空目录",
    "Empty message": "空消息",
    "Empty pie chart": "饼图无数据",
    "Enable": "启用",
    "Enable Best-of-2": "启用双候选对决 (Best-of-2)",
    "Enable Browser Tool": "启用浏览器工具",
    "Enable Browser Tools": "启用浏览器工具",
    "Enable Chat": "启用对话",
    "Enable Demo Mode (Beta)": "启用演示模式 (Beta)",
    "Enable Overages": "启用超额使用",
    "Enable Personal Customizations": "启用个人自定义设置",
    "Enable Plugin": "启用插件",
    "Enable Recommended Skills": "启用推荐技能",
    "Enable Remote Control": "启用远程控制",
    "Enable Shell Integration": "启用 Shell 终端集成",
    "Enable Telemetry": "启用遥测诊断",
    "Enable Thinking Mode": "开启深度思考模式",
    "Enabled": "已启用",
    "Enabling...": "正在启用...",
    "End battle mode": "结束对决模式",
    "End Battle Mode": "结束对决模式",
    "Enlarged Mermaid diagram": "放大的 Mermaid 流程图",
    "Enter a prompt for the agent to run": "输入供智能体执行的提示词",
    "Enter a prompt for the agent to run...": "输入供智能体执行的提示词...",
    "Enter authorization code": "输入授权码",
    "Enter authorization code...": "输入授权码...",
    "Enter automation name": "输入自动化名称",
    "Enter automation name...": "输入自动化名称...",
    "Enter command...": "输入命令...",
    "Enter Queues after the turn": "Enter 轮次结束后进入排队",
    "Enter Sends immediately": "Enter 立即发送",
    "Enter target...": "输入目标...",
    "Enter tool name or server...": "输入工具名称或服务...",
    "Environment": "环境",
    "Environment Actions": "环境操作",
    "Environment Variables": "环境变量配置",
    "Equalize Split Panes": "均分分屏面板",
    "Error": "错误",
    "Error Details:": "错误详情：",
    "Error during tool execution": "工具执行期间出错",
    "Error editing file": "编辑文件出错",
    "Error editing notebook": "编辑笔记本出错",
    "Error ID:": "错误 ID：",
    "Error loading Browser recording": "加载浏览器录屏出错",
    "Error reading notebook": "读取笔记本出错",
    "Error rendering playback": "渲染回放出错",
    "Error viewing file": "查看文件出错",
    "Error while analyzing directory": "分析目录时出错",
    "Error while editing": "编辑时出错",
    "Error while editing notebook": "编辑笔记本时出错",
    "Error while reading notebook": "读取笔记本时出错",
    "Error while running command": "运行命令时出错",
    "Error while searching": "搜索时出错",
    "Error while searching filesystem": "搜索文件系统时出错",
    "Error while searching the web": "网页搜索时出错",
    "Error while semantic searching": "语义搜索时出错",
    "Error while viewing": "查看时出错",
    "Errored": "出错",
    "Every day": "每天",
    "Every hour": "每小时",
    "Every month": "每月",
    "Every week": "每周",
    "Excellent tool usage": "工具调用出色",
    "Exceptional work": "表现极其出色",
    "Execute URLs": "执行 URL",
    "Executed": "已执行",
    "Executing": "正在执行",
    "Execution": "执行策略",
    "Execution ID": "执行 ID",
    "Execution Metadata": "执行元数据",
    "Execution Mode": "执行模式",
    "Execution Progress": "执行进度",
    "Exit": "退出",
    "Expand": "展开",
    "Expand (shift+click to expand every level below)": "展开（按住 Shift 点击可展开下方所有层级）",
    "Expand all": "全部展开",
    "Expand All": "全部展开",
    "Expand All Folders": "全部展开文件夹",
    "Expand queued messages": "展开排队中的消息",
    "Expand subagents": "展开子智能体",
    "Expected behavior": "预期表现",
    "Experimental": "实验性功能",
    "Experimental Features": "实验性功能",
    "Expert at reviewing Flutter code for accessibility (a11y) issues. Invoke this agent to perform an a11y review of a codebase, pending changes, or PR.": "擅长审查 Flutter 代码中的无障碍 (a11y) 问题。调用此智能体对代码库、待定更改或 PR 进行无障碍审查。",
    "Explain and Fix in Current Conversation": "在当前会话中解释并修复",
    "Explored": "已浏览",
    "Explorer": "资源管理器",
    "Exploring": "正在探索",
    "Export": "导出",
    "Export artifact": "导出产物",
    "Export as PDF": "导出为 PDF",
    "Export Logs": "导出日志记录",
    "Extensions": "扩展插件",
    "Extracted DOM elements": "已提取 DOM 元素",
    "Extracting DOM elements": "正在提取 DOM 元素",
    "Failed": "失败",
    "Failed to add plugin.": "添加插件失败。",
    "Failed to add plugin. Please try again.": "添加插件失败。请重试。",
    "Failed to Amend": "修改提交失败",
    "Failed to archive workspace": "归档工作区失败",
    "Failed to build": "构建失败",
    "Failed to Commit": "提交失败",
    "Failed to continue": "继续操作失败",
    "Failed to copy:": "复制失败：",
    "Failed to create CitC clone workspace": "创建 CitC 克隆工作区失败",
    "Failed to create terminal": "创建终端失败",
    "Failed to create workspace.": "创建工作区失败。",
    "Failed to create worktree": "创建工作树失败",
    "Failed to delete conversation": "删除会话失败",
    "Failed to edit": "编辑失败",
    "Failed to execute": "执行失败",
    "Failed to fork conversation": "派生分支会话失败",
    "Failed to Generate Commit Message": "生成提交信息失败",
    "Failed to mark all as read": "无法全部标记为已读",
    "Failed to print document": "打印文档失败",
    "Failed to print document:": "打印文档失败：",
    "Failed to proceed": "继续执行失败",
    "Failed to Push": "推送失败",
    "Failed to read": "读取失败",
    "Failed to read file content": "读取文件内容失败",
    "Failed to rename conversation": "重命名会话失败",
    "Failed to revalidate slash commands:": "重新验证斜杠命令失败：",
    "Failed to save project": "保存项目失败",
    "Failed to start Best of N mode": "启动多候选对决模式失败",
    "Failed to start conversation": "启动会话失败",
    "Failed to stop agent": "停止智能体失败",
    "Failed to stop conversation": "停止会话失败",
    "Fallback Summary Used": "已使用回退摘要",
    "Faster response": "响应更快速",
    "Feature Request": "功能建议 (Feature)",
    "Features": "功能",
    "Feedback": "用户反馈",
    "Feedback Type": "反馈类型",
    "Fetched network request": "已获取网络请求",
    "Fetched network requests": "已获取网络请求",
    "Fetching network request": "正在获取网络请求",
    "Fetching network requests": "正在获取网络请求",
    "Fewer bugs": "更少缺陷",
    "File": "文件",
    "File attachment": "文件附件",
    "File changed": "已修改文件",
    "File Changed": "已修改文件",
    "File Comments": "文件评论",
    "File Diff Comments": "文件差异评论",
    "File edits": "文件编辑",
    "File explorer": "文件浏览器",
    "File Explorer": "文件资源管理器",
    "File location": "文件位置",
    "File not found": "文件未找到",
    "File picker": "文件选择器",
    "File Picker": "文件选择器",
    "File reads": "文件读取",
    "File Reads": "文件读取",
    "File Viewer": "文件查看器",
    "File Writes": "文件写入",
    "Files": "文件列表",
    "Files changed": "已修改文件",
    "Files Changed": "已修改文件",
    "Files modified by the agent in this conversation": "智能体在此会话中修改的文件",
    "Files modified by the agent in this conversation.": "智能体在此会话中修改的文件。",
    "Filter": "筛选",
    "Finalizing transcription...": "正在完成语音转写...",
    "Finalizing...": "正在完成...",
    "Find": "查找",
    "Find in conversation": "在会话中查找",
    "Find in Conversation": "在会话中查找",
    "Find in Pane": "在面板中查找",
    "Finish": "完成",
    "finished": "已完成",
    "Finished": "已完成",
    "Five Hour Limit Remaining": "5 小时剩余额度",
    "Focus Chat Input": "聚焦对话输入框",
    "Focus Input": "聚焦输入框",
    "Fold code block": "折叠代码块",
    "Folder": "文件夹",
    "Folder doesn't exist": "文件夹不存在",
    "Folders": "文件夹列表",
    "Follow-up Messages": "追问消息",
    "for conversations outside of projects.": "用于项目外会话。",
    "For help, visit": "如需帮助，请访问",
    "for quick navigation and control.": "用于快速导航和操作控制。",
    "Foreground": "前景色",
    "Forgot context": "遗忘上下文信息",
    "Fork conversation": "派生分支会话",
    "Fork Conversation": "派生分支会话",
    "Fork Environment Notice": "分支派生环境提示",
    "Fork warning": "分支警告",
    "Forked conversation": "分支派生会话",
    "Forked from": "派生自",
    "Found in This Workspace": "在当前工作区中找到",
    "Found references to": "找到相关引用：",
    "Frequency": "执行频率",
    "Frequency Penalty": "频率惩罚度",
    "Friday": "周五",
    "from AI Studio": "（来自 AI Studio）",
    "Full Error": "完整错误信息",
    "Full machine": "完整机器权限",
    "Full output written to": "完整输出已写入至",
    "Function Calling": "函数调用支持",
    "General": "通用",
    "General Feedback": "通用反馈",
    "Generate a link that lets any Googler load a read-only copy of a conversation. Sharing exports the conversation history to your public x20 folder, so it needs that folder to be readable by others.": "生成一个链接，允许任何 Googler 加载该会话的只读副本。分享会将对话历史导出到您的公共 x20 文件夹，因此需要该文件夹对他人可读。",
    "Generate personalized rules": "生成个性化规则",
    "Generate Share Link": "生成分享链接",
    "Generated image": "生成的图片",
    "Generated image preview": "生成图片预览",
    "Generated media": "生成的媒体内容",
    "Generating Link": "正在生成链接",
    "Generations": "生成记录",
    "Generic Tool": "通用工具",
    "Get Started": "开始体验",
    "Getting scripts...": "正在获取脚本...",
    "Global": "全局",
    "Global Rules": "全局规则",
    "global settings": "全局设置",
    "Go": "前往",
    "Go Back": "后退",
    "Go Back in Pane": "在面板中后退",
    "Go Forward": "前进",
    "Go Forward in Pane": "在面板中前进",
    "Go to General settings": "前往通用设置",
    "Go to Home": "返回首页",
    "Goal": "目标",
    "Goal Verification": "目标验证",
    "Goals": "目标",
    "Good questions": "提问精准得当",
    "good response": "优质回答",
    "Good response": "优质回答",
    "Good Response": "优质回复",
    "GOOD RESPONSE": "优质回答",
    "Got it": "知道了",
    "Grasped nuance": "精准把握细节",
    "Group Actions": "分组操作",
    "Group By": "分组依据",
    "Group By Project": "按项目分组",
    "Group By Workspace": "按工作区分组",
    "Group name": "分组名称",
    "Hacky/lazy code": "代码粗糙敷衍",
    "Hallucinated": "产生幻觉捏造事实",
    "Headless Mode": "无头模式",
    "Help": "帮助",
    "Help improve the product by sending anonymous usage data": "通过发送匿名使用数据帮助改进产品",
    "Helpful explanation": "解释清晰有帮助",
    "Hide": "隐藏",
    "Hide breakdown": "隐藏明细",
    "Hide details": "隐藏详情",
    "Hide Details": "隐藏详情",
    "Hide Error": "隐藏错误",
    "Hide tools": "隐藏工具",
    "High Contrast": "高对比度",
    "Highlight After Accept": "接受建议后高亮显示",
    "Highly independent": "高度自主独立",
    "History": "历史记录",
    "Hold": "按住",
    "Hooks": "钩子函数",
    "Hooks Management": "钩子管理",
    "Host": "主机地址",
    "Hourly": "每小时",
    "HTTP Proxy": "HTTP 代理",
    "HTTPS Proxy": "HTTPS 代理",
    "I prefer an immediate single response to prioritize productivity right now.": "我目前希望优先保证效率，直接获取单个即时回复。",
    "Idle": "空闲",
    "Idle Guard Warning": "空闲守卫警告",
    "If enabled, you can manage your conversations from the companion website.": "启用后，您可以从配套网站管理您的会话。",
    "Ignored": "忽略指令要求",
    "Ignored Files": "忽略的文件列表",
    "Image Answers": "图片解答",
    "Image attachment": "图片附件",
    "Image preview not available": "图片预览不可用",
    "Images": "图片",
    "Implementation Plan": "实施方案文档",
    "Import AI Studio Project": "导入 AI Studio 项目",
    "In a rush": "赶时间",
    "In Progress": "处理中",
    "Inactive": "未激活 / 空闲",
    "Include unstaged changes": "包含未暂存的更改",
    "Included Automatically in google3": "在 google3 中自动包含",
    "Incomplete / Gave up": "半途而废 / 未完成",
    "Info": "提示",
    "Inherit": "继承",
    "Inherit from System": "继承系统主题",
    "Inherit General": "继承通用设置",
    "Inherit global": "继承全局设置",
    "Inherit Global": "继承全局设置",
    "Inherit global settings": "继承全局设置",
    "Inherit Global Settings": "继承全局设置",
    "Inherited from global": "继承自全局",
    "Inherited from global settings": "继承自全局设置",
    "Inherited from Global Settings": "继承自全局设置",
    "Inherits default settings": "继承默认设置",
    "Inherits General settings": "继承“通用”设置",
    "Inherits General settings.": "继承“通用”设置。",
    "Inherits your \"General\" settings when working in this project": "在此项目中工作时，继承您的“通用”设置",
    "Inherits your “General” settings when working in this project": "在此项目中工作时，继承您的“通用”设置",
    "Inherits your \"General\" settings when working in this project.": "在此项目中工作时，继承您的“通用”设置。",
    "Inherits your “General” settings when working in this project.": "在此项目中工作时，继承您的“通用”设置。",
    "Inherits your default settings": "继承您的默认设置",
    "Inherits your general settings": "继承您的“通用”设置",
    "Inherits your General settings": "继承您的“通用”设置",
    "Inherits your General settings.": "继承您的“通用”设置。",
    "Inline Actions": "内联操作",
    "Inline Diff": "内联对比",
    "Inline Widget": "内联组件",
    "Input required": "需要输入",
    "Insert in terminal": "插入终端",
    "Insert in Terminal": "插入终端",
    "inside of project": "项目内",
    "Inside of Project": "项目内",
    "Inside of workspace": "工作区内",
    "Inside of Workspace": "工作区内",
    "Insiders": "Insiders 体验版",
    "Inspected commit": "已检查提交",
    "Install": "安装",
    "Install Antigravity IDE to run and edit your workspace scripts": "安装 Antigravity IDE 以运行和编辑您的工作区脚本",
    "Install Antigravity IDE to run and edit your workspace scripts.": "安装 Antigravity IDE 以运行和编辑您的工作区脚本。",
    "Install IDE": "安装 IDE",
    "Install IDE Extension": "安装 IDE 插件",
    "Install Update": "安装更新",
    "Installation": "安装",
    "Installed": "已安装",
    "Installed by You": "由您安装",
    "Installed Plugins": "已安装插件",
    "Installed Skills": "已安装技能",
    "Installing": "安装中",
    "Installing Update": "正在安装更新",
    "Instruction": "指令",
    "Integration skill and tools for Google Maps Platform APIs": "用于 Google Maps Platform API 的集成技能与工具",
    "Intent understanding": "意图理解问题",
    "Interface Scale": "界面比例",
    "Internal search": "内部搜索",
    "Interrupt the agent and send immediately": "打断智能体并立即发送",
    "Interrupt the agent and send immediately.": "打断智能体并立即发送。",
    "Invalid tool call": "无效的工具调用",
    "It requires": "需要安装",
    "It requires Google Chrome to be installed": "需要安装 Google Chrome 才能运行",
    "It requires Google Chrome to be installed.": "需要安装 Google Chrome 才能运行。",
    "It's a tie": "势均力敌（平局）",
    "JavaScript execution disabled in strict mode": "严格模式下已禁用 JavaScript 执行",
    "JavaScript Result": "JavaScript 执行结果",
    "JSON attachment": "JSON 附件",
    "just now": "刚刚",
    "Just now": "刚刚",
    "Keep Antigravity running in the background": "在后台保持 Antigravity 运行",
    "Keep Changes": "保留修改",
    "Keep computer awake": "保持电脑处于唤醒状态",
    "Keep Computer Awake": "保持电脑处于唤醒状态",
    "Keep In Menu Bar": "保持在菜单栏/托盘",
    "Keep your coding agent up to date with the latest web best practices.": "让您的编码智能体紧跟最新的 Web 最佳实践。",
    "Keeps working in this workspace. Nothing is copied.": "继续在当前工作区中工作。不复制任何内容。",
    "Keyboard shortcuts for quick navigation and control": "用于快速导航与控制的键盘快捷键",
    "Keyboard shortcuts for quick navigation and control.": "用于快速导航与控制的键盘快捷键。",
    "Kick off work on your computer and continue working with your agents from your phone or another device. Turn on Remote Control in app settings.": "在您的计算机上开启工作，并通过手机或其他设备继续与您的智能体协同。可在应用设置中开启远程控制。",
    "Kill Terminal": "终止终端",
    "Killed": "已终止",
    "Knowledge": "知识库",
    "Knowledge Generation": "知识生成",
    "Labs": "实验室",
    "Lacked initiative": "缺乏主动性",
    "Last 7 days": "过去 7 天",
    "Last Prompt": "最近提示词",
    "Last run": "上次运行",
    "Last Updated": "最近更新",
    "Laziness": "偷懒敷衍",
    "Learn more": "了解更多",
    "Learn More": "了解更多",
    "Learn more about": "了解更多关于",
    "Learn more about Default": "了解“默认”预设的详情",
    "Learn more by visiting our": "欲了解更多信息，请访问我们的",
    "Learn more.": "了解更多。",
    "Leave a comment": "留下评论",
    "Light": "浅色",
    "Line Height": "行高",
    "List resources:": "列出资源：",
    "Listed in Your Config": "在您的配置中列出",
    "Load Global Rules": "加载全局规则",
    "Load older messages": "加载更早的消息",
    "Load Project Rules": "加载项目规则",
    "Loading": "加载中",
    "Loading added plugins...": "正在加载已添加的插件...",
    "Loading Browser recording...": "正在加载浏览器录屏...",
    "Loading media...": "正在加载媒体...",
    "Loading Notebook View...": "正在加载笔记本视图...",
    "Loading subagent...": "正在加载子智能体...",
    "Loading trajectory...": "正在加载执行轨迹...",
    "Loading worktrees...": "正在加载工作树...",
    "Loading...": "加载中...",
    "Local": "本地",
    "Location": "位置",
    "Log": "日志",
    "Log in to use the agent": "登录以使用智能体",
    "Logged in as": "当前登录身份：",
    "Logs": "日志记录",
    "Main Agent": "主智能体",
    "Manage": "管理",
    "Manage Antigravity app settings.": "管理 Antigravity 应用设置。",
    "Manage application settings.": "管理应用程序设置。",
    "Manage Hooks": "管理钩子",
    "Manage remote sessions": "管理远程会话",
    "Manage Sidecars": "管理伴随服务",
    "Manage Skills": "管理技能",
    "Manage Subscription": "管理订阅",
    "Manage your plan, credentials, and general preferences.": "管理您的套餐方案、凭据及通用偏好。",
    "Manifest Changes": "清单更改",
    "Manual": "手动",
    "Manually Captured": "手动捕获",
    "Manually customize individual settings": "手动自定义各项设置",
    "Manually customize individual settings.": "手动自定义各项设置。",
    "Manually Rejected": "手动拒绝",
    "Mark 1 conversation as read": "将 1 个会话标记为已读",
    "Mark 1 conversation as read.": "将 1 个会话标记为已读。",
    "Mark all as read": "全部标记为已读",
    "Mark as read": "标记为已读",
    "Mark as Read": "标记为已读",
    "Mark as unread": "标记为未读",
    "Mark as Unread": "标记为未读",
    "mark read": "标记为已读",
    "Mark Read": "标记为已读",
    "MARK READ": "标记为已读",
    "mark unread": "标记为未读",
    "Mark Unread": "标记为未读",
    "MARK UNREAD": "标记为未读",
    "Marketing Emails": "营销与产品动态邮件",
    "Marketplace": "插件市场",
    "Marketplace Gallery URL": "插件市场画廊 URL",
    "Marketplace Item URL": "插件市场项目 URL",
    "Match case": "区分大小写",
    "Match whole word": "全字匹配",
    "Max Autonomy": "最大自主性",
    "Max Output Tokens": "最大输出 Token 数",
    "Maximize": "最大化",
    "Maximize Pane": "最大化面板",
    "Mcp Tools": "MCP 工具",
    "Media": "媒体",
    "Media Files": "媒体文件",
    "Memory": "内存",
    "Mention": "提及",
    "Mention Page": "引用页面",
    "Mentions": "提及",
    "Merge Conflict": "合并冲突",
    "Mermaid diagram": "Mermaid 流程图",
    "Message Delivery": "消息传递策略",
    "Message input": "消息输入",
    "Minimize": "最小化",
    "Minimize Pane": "最小化面板",
    "Minimize side question": "最小化旁路提问",
    "Misunderstood": "误解用户意图",
    "Model Summarization Failed": "模型摘要生成失败",
    "Modes": "模式",
    "Modified Files": "已修改文件",
    "Modified files:": "已修改的文件：",
    "Monday": "周一",
    "Monthly": "每月",
    "More accurate": "更准确",
    "More actions": "更多操作",
    "More Actions": "更多操作",
    "More comprehensive": "更全面详尽",
    "More creative": "更有创意",
    "More info": "更多信息",
    "More Info": "更多信息",
    "More options": "更多选项",
    "More Options": "更多选项",
    "Move Down": "下移",
    "Move to Group": "移动到分组",
    "Move to New Group": "移动到新分组",
    "Move Up": "上移",
    "Moved Mouse in Browser": "已在浏览器中移动鼠标",
    "Moving Mouse in Browser": "正在浏览器中移动鼠标",
    "Name": "名称",
    "Narrow": "窄",
    "Navigate to": "导航至",
    "Navigation": "导航",
    "Needs attention": "需要关注",
    "Needs Attention": "需要处理",
    "Network": "网络",
    "Never": "从不",
    "Never Proceed Automatically": "从不自动继续",
    "Never run": "从未运行",
    "New": "新建",
    "New Agent Script": "新建智能体脚本",
    "New Automation": "新建自动化",
    "New Chat": "新建对话",
    "New conversation": "新建会话",
    "New Conversation": "新建会话",
    "New conversation in project": "在项目中新建会话",
    "New Conversation in Project": "在项目中新建会话",
    "New conversation in workspace": "在工作区中新建会话",
    "New Conversation in Workspace": "在工作区中新建会话",
    "New Group": "新建分组",
    "New hook name": "新钩子名称",
    "New Project": "新建项目",
    "New tab": "新标签页",
    "New terminal": "新建终端",
    "New Terminal": "新建终端",
    "New Terminal Tab": "新建终端标签页",
    "New Window": "新建窗口",
    "New Workspace": "新建工作区",
    "New worktree": "新建工作树",
    "New Worktree": "新建工作树",
    "Next": "下一步",
    "Next Aux Pane Tab": "下一个辅助面板标签页",
    "Next Change": "下一处变更",
    "Next match": "下一个匹配",
    "Next Page": "下一页",
    "Next Pane Tab": "下一个面板标签页",
    "Next question": "下一个问题",
    "Next run": "下次运行",
    "Next side question": "下一个旁路提问",
    "Next Suggestion": "下一项建议",
    "Nickname": "昵称",
    "Nightly": "开发版 (Nightly)",
    "No active terminals": "暂无活跃终端",
    "No active terminals. Click + to create one.": "暂无活跃终端，点击 + 创建一个新终端。",
    "No agents running": "无正在运行的智能体",
    "No artifacts generated": "暂未生成任何产物",
    "No automations": "暂无自动化任务",
    "No automations configured": "尚未配置任何自动化任务",
    "No automations configured.": "尚未配置任何自动化任务。",
    "No automations.": "暂无自动化任务。",
    "No browser pages open": "当前未打开任何浏览器页面",
    "No changes to review": "暂无待审查的更改",
    "No content available for this resource": "此资源暂无可用内容",
    "No conversation selected": "未选择会话",
    "No conversations available": "暂无可用会话",
    "No conversations found": "未找到会话",
    "No conversations yet": "暂无会话",
    "No documents": "暂无文档",
    "No environments found": "未找到环境",
    "No file changes": "无文件更改",
    "No files changed": "未修改任何文件",
    "No files changed.": "未修改任何文件。",
    "No files or folders found": "未找到文件或文件夹",
    "No folder selected": "未选择文件夹",
    "No folders added yet": "暂未添加任何文件夹",
    "No folders added yet.": "暂未添加任何文件夹。",
    "No groups yet": "暂无分组",
    "No internet. Agent features may not work.": "无网络连接，智能体功能可能无法正常工作。",
    "No Javascript Result Output": "无 JavaScript 结果输出",
    "No matching flags": "无匹配的实验特性标记",
    "No matching results": "无匹配结果",
    "No more older messages": "没有更多历史消息了",
    "No previous worktrees": "暂无历史工作树",
    "no project": "无项目关联",
    "No Project": "无项目关联",
    "NO PROJECT": "无项目关联",
    "No project folders added yet": "暂未添加任何项目文件夹",
    "No project folders added yet.": "暂未添加任何项目文件夹。",
    "No project selected": "未选择项目",
    "No projects yet": "暂无项目",
    "No Proxy": "不使用代理",
    "No resources available": "暂无可用资源",
    "No results": "无结果",
    "No Results": "无结果",
    "No results found": "未找到结果",
    "No results found.": "未找到结果。",
    "No skills used": "未使用任何技能",
    "No skills used.": "未使用任何技能。",
    "No subagents": "无子智能体",
    "No Subtitle": "无副标题",
    "No updates available": "暂无可用更新",
    "No uploads": "无上传内容",
    "No workspaces open.": "当前未打开任何工作区。",
    "Non-technical": "非技术模式",
    "None": "无",
    "Not configured": "未配置",
    "Not Found": "未找到",
    "Not in Project": "未归属项目",
    "Not running": "未运行",
    "Not scheduled": "未设置定时计划",
    "Not signed in": "未登录",
    "Not Signed In": "未登录",
    "Not suitable for Best-of-N": "不适用于多选最优模式",
    "Number of responses": "回复方案数量",
    "of the customization budget is available": "的自定义扩展预算可用",
    "of the customization budget is available.": "的自定义扩展预算可用。",
    "On empty prompt, sends next in queue": "在输入框为空时，发送队列中的下一条消息",
    "Only unread": "仅未读",
    "Only Unread": "仅未读",
    "Open": "打开",
    "Open Agent on Reload": "重载时打开智能体",
    "Open Antigravity": "打开 Antigravity",
    "Open Command Palette": "打开命令面板",
    "Open Commit Graph": "打开提交历史图",
    "Open Conversation": "打开会话",
    "Open Conversation History": "打开历史会话",
    "Open Conversation Picker": "打开会话选择器",
    "Open Diff": "打开差异对比",
    "Open extracted DOM in editor": "在编辑器中打开提取的 DOM",
    "Open File": "打开文件",
    "Open File Search": "打开文件搜索",
    "Open Folder": "打开文件夹",
    "Open Folder (Interactive)": "打开文件夹（交互式）",
    "Open full view": "打开完整视图",
    "Open IDE": "打开 IDE",
    "Open in Antigravity IDE": "在 Antigravity IDE 中打开",
    "Open in Browser": "在浏览器中打开",
    "Open in Code Search": "在代码搜索中打开",
    "Open in File Explorer": "在文件资源管理器中打开",
    "Open in new tab": "在新标签页中打开",
    "Open in New Tab": "在新标签页中打开",
    "Open in new window": "在新窗口中打开",
    "Open in Notebook View": "在笔记本视图中打开",
    "Open in Tab": "在标签页中打开",
    "Open Launchpad": "打开启动台",
    "Open Log Directory": "打开日志保存目录",
    "Open Preferences": "打开首选项",
    "Open Search": "打开搜索",
    "Open search in external browser": "在外部浏览器中打开搜索",
    "Open Settings": "打开设置",
    "Open settings menu": "打开设置菜单",
    "Open side-by-side view": "打开并排视图",
    "Open Source Code": "打开源代码",
    "Open System Browser": "打开系统浏览器",
    "Open System Preferences": "打开系统偏好设置",
    "Open Terminal": "打开终端",
    "Open URL": "打开 URL",
    "Open with External Browser": "使用外部浏览器打开",
    "Open Workspace": "打开工作区",
    "Open Workspace Selector": "打开工作区选择器",
    "Opened browser": "已打开浏览器",
    "Opened URL in Browser": "已在浏览器中打开 URL",
    "Opening URL in Browser": "正在浏览器中打开 URL",
    "Opt-out": "退出体验",
    "Options": "选项",
    "or copy link": "或复制链接",
    "or copy link.": "或复制链接。",
    "Organization ID": "组织 ID",
    "Other Conversations": "其他会话",
    "Other reason": "其他原因",
    "Other sign-in options": "其他登录选项",
    "Output": "输出",
    "outside of project": "项目外",
    "Outside of Project": "项目外",
    "OUTSIDE OF PROJECT": "项目外",
    "outside of projects": "项目外",
    "outside of projects.": "项目外。",
    "Outside of workspace": "工作区外",
    "Outside of Workspace": "工作区外",
    "Overfixated": "过度钻牛角尖",
    "Override feature environment": "替换特性环境",
    "Override global settings": "覆盖全局设置",
    "Override Global Settings": "覆盖全局设置",
    "Overview": "概览",
    "Overwrite if exists": "若存在则覆盖",
    "Page contents": "页面内容",
    "Page title:": "页面标题：",
    "Panel": "面板",
    "Paste": "粘贴",
    "Paste auth code": "粘贴授权码",
    "Paste code here": "在此处粘贴代码",
    "Pattern": "模式",
    "Pause queue": "暂停队列",
    "PDF attachment": "PDF 附件",
    "Pending": "等待中",
    "Permanently delete": "永久删除",
    "Permanently delete this project": "永久删除此项目",
    "Permanently delete this project.": "永久删除此项目。",
    "Pick a winner": "评选优胜方案",
    "Pick a Winner": "评选优胜方案",
    "Pie chart must contain at least one positive data slice": "饼图必须包含至少一个正数值数据切片",
    "pin": "置顶",
    "Pin": "置顶",
    "PIN": "置顶",
    "Pin conversation": "置顶会话",
    "Pin Conversation": "置顶会话",
    "Pin this conversation": "置顶此会话",
    "Pin This Conversation": "置顶此会话",
    "Pinned Chats Only": "仅固定会话",
    "Pinned Conversations": "置顶会话",
    "Plan": "套餐方案",
    "Planning": "正在规划",
    "Planning Mode": "规划模式",
    "Playback available": "回放已就绪",
    "Please describe the issue in detail. The more actionable your feedback, the quicker our team can address your request. Some helpful information includes:": "请详细描述您遇到的问题。您的反馈越具体详实，我们的团队就能越快跟进解决。建议包含以下信息：",
    "Please list the steps to reproduce the issue": "请列出重现该问题的具体操作步骤…",
    "Please select a winner": "请选择一个优胜方案",
    "Please sign in using the Antigravity sidebar panel to view this page.": "请使用 Antigravity 侧边栏面板登录以查看此页面。",
    "Please verify your account, then sign in again to continue. Learn more by visiting our": "请先验证您的账号，然后重新登录以继续。欲了解更多信息，请访问我们的",
    "plugin": "插件",
    "Plugin details": "插件详情",
    "Plugin is disabled": "插件已禁用",
    "Plugin Manager": "插件管理器",
    "Plugins": "插件",
    "Port": "端口",
    "Post-Tool Execution Hook": "工具执行后钩子",
    "Pre-Tool Execution Hook": "工具执行前钩子",
    "Preferences": "首选项",
    "Presence Penalty": "存在惩罚度",
    "Press Alt+Enter to queue": "按 Alt+Enter 排队",
    "Press Enter to send": "按 Enter 发送",
    "Press Shift+Enter for new line": "按 Shift+Enter 换行",
    "Prevent Sleep": "阻止系统休眠",
    "Prevent the computer from sleeping while the app is running.": "在应用运行期间阻止计算机进入休眠状态。",
    "Preview unavailable": "预览不可用",
    "Previous": "上一步",
    "Previous Aux Pane Tab": "上一个辅助面板标签页",
    "Previous Change": "上一处变更",
    "Previous match": "上一个匹配",
    "Previous Page": "上一页",
    "Previous Pane Tab": "上一个面板标签页",
    "Previous question": "上一问题",
    "Previous side question": "上一个旁路提问",
    "Previous Suggestion": "上一项建议",
    "Previous toast": "上一条通知提示",
    "Previous Worktrees": "历史工作树 (Worktrees)",
    "Proactive solution": "主动提供解决方案",
    "Proactively connect to running Dart/Flutter apps and trigger hot reload or hot restart upon editing .dart files under lib/.": "主动连接到正在运行的 Dart/Flutter 应用，并在编辑 lib/ 下的 .dart 文件时触发热重载或热重启。",
    "Problems": "问题",
    "Proceed": "继续执行",
    "Proceed Anyway": "仍然继续",
    "Proceed with Plan": "继续执行方案",
    "Proceeded with": "已继续执行",
    "Processing": "处理中",
    "Product Skin": "产品界面风格",
    "Project": "项目",
    "Project + worktree": "项目 + 工作树",
    "Project + Worktree": "项目 + 工作树",
    "Project already exists": "项目已存在",
    "Project ID": "项目 ID",
    "Project Name": "项目名称",
    "Project options": "项目选项",
    "Project picker": "项目选择器",
    "Project Root": "项目根目录",
    "Project Rules": "项目规则",
    "Project Settings": "项目配置",
    "Projects": "项目列表",
    "Prompt": "提示词",
    "Prompt for approval before running browser scripts": "在运行浏览器脚本前提示以征得批准",
    "Prompt for approval before running browser scripts.": "在运行浏览器脚本前提示以征得批准。",
    "Prompt to execute on schedule...": "按计划执行的提示词...",
    "Prompt too simple": "提示词过于简单",
    "Provide feedback": "提供反馈",
    "Provide Feedback": "提供反馈",
    "Proxy": "代理",
    "Proxy Configuration": "代理网络配置",
    "Proxy Settings": "代理设置",
    "Push": "推送 (Push)",
    "Push succeeded": "推送成功",
    "Python Script": "Python 脚本",
    "Quality": "完成质量",
    "Questions": "问题",
    "Queue": "排队等待",
    "Queue Delivery": "排队消息发送",
    "Queue for Next Turn": "排队至下一轮",
    "Queue message": "排队消息",
    "Queue messages": "排队消息",
    "Queue until after the current turn": "排队等待，直至当前轮次结束",
    "Queue until after the current turn.": "排队等待，直至当前轮次结束。",
    "Queued message": "排队中的消息",
    "Queued message deleted": "已删除排队中的消息",
    "Queued Messages": "排队消息",
    "Queued Messages Behavior": "排队消息处理行为",
    "Queues after the turn": "轮次结束后进入排队",
    "quick start": "快速入门",
    "Quick Start": "快速入门",
    "Quit": "退出",
    "Quit Antigravity": "退出 Antigravity",
    "Quote": "引用",
    "Quote Ctrl+L": "引用 Ctrl+L",
    "Quote Selection": "引用选中文本",
    "Ran": "已运行",
    "Ran command": "已运行命令",
    "Rate Limit": "速率限制",
    "Rate Limits": "速率限制",
    "Read Browser Page in Browser": "已读取浏览器页面",
    "Read Files": "读取文件",
    "Read page": "读取页面",
    "Read resource:": "读取资源：",
    "Read URL": "读取 URL",
    "Read URL content?": "是否读取 URL 内容？",
    "Read URL rejected": "已拒绝读取 URL",
    "Read URLs": "读取 URL 列表",
    "Read-Only Paths": "只读路径列表",
    "Read-Write Paths": "读写路径列表",
    "Reading": "正在读取",
    "Reading Browser Page in Browser": "正在读取浏览器页面",
    "Reading page": "正在读取页面",
    "Ready": "就绪",
    "Reason for opting out": "退出原因",
    "Receive product updates, tips, and promotions from Google Antigravity via email.": "通过电子邮件接收来自 Google Antigravity 的产品更新、使用技巧与促销信息。",
    "Recent": "最近",
    "Recent Files": "最近使用的文件",
    "Recent Workspaces": "最近工作区",
    "Recommended": "推荐",
    "Reconnecting": "正在重新连接",
    "Record voice memo": "录制语音备忘录",
    "Recording": "录音中",
    "Redo": "重做",
    "Refresh": "刷新",
    "Refresh custom agents": "刷新自定义智能体",
    "Refresh customizations": "刷新自定义项",
    "Refresh gcert credentials": "刷新 gcert 凭据",
    "Refresh gcert Credentials": "刷新 gcert 凭据",
    "Refresh skills": "刷新技能",
    "Refresh Skills": "刷新技能",
    "Refresh skills paths": "刷新技能路径",
    "Refreshed Browser page": "已刷新浏览器页面",
    "Refreshing Browser page": "正在刷新浏览器页面",
    "Refreshing...": "正在刷新...",
    "Reject": "拒绝",
    "Reject all": "全部拒绝",
    "Reject Changes": "拒绝更改",
    "Reject Step": "拒绝此步骤",
    "Reject Suggestion": "拒绝建议",
    "Rejected": "已拒绝",
    "Relaxed": "宽松",
    "Release Notes": "发行说明",
    "Reliable automation, in-depth debugging, and performance analysis in Chrome using Chrome DevTools and Puppeteer": "在 Chrome 中使用 Chrome DevTools 和 Puppeteer 进行可靠的自动化、深度调试与性能分析",
    "Reload": "重新加载",
    "Reload app": "重新加载应用",
    "Reload Skills": "重新加载技能库",
    "Reload Window": "重新加载窗口",
    "Remaining": "剩余",
    "Remote Control": "远程控制",
    "Remote Control, or": "远程控制，或",
    "Remote Control, or ": "远程控制，或 ",
    "Remote Debugging Port": "远程调试端口",
    "Remote session": "远程会话",
    "Remote sessions": "远程会话列表",
    "Remove": "移除",
    "Remove from Group": "从分组中移除",
    "Remove from Split": "从分屏中移除",
    "Remove From Split": "从分屏中移除",
    "Removing...": "正在移除...",
    "Rename": "重命名",
    "Rename Conversation": "重命名会话",
    "Rename Group": "重命名分组",
    "Rename Terminal": "重命名终端",
    "Rename this conversation": "重命名此会话",
    "Rename This Conversation": "重命名此会话",
    "Rendering playback": "正在渲染回放",
    "Replace With New": "替换为新会话",
    "Report an Issue": "报告问题",
    "Report Issue": "报告问题",
    "Requested changes": "请求修改",
    "Require Confirmation for Commands": "执行命令时需要用户确认",
    "requires Google Chrome to be installed": "需要安装 Google Chrome 才能运行",
    "requires Google Chrome to be installed.": "需要安装 Google Chrome 才能运行。",
    "Reset": "重置",
    "Reset All Settings": "重置所有设置至默认值",
    "Reset to preset": "重置为预设",
    "Reset zoom": "重置缩放",
    "Resets in 2h 35m": "2 小时 35 分钟后重置",
    "Resets in 2h 35m.": "2 小时 35 分钟后重置。",
    "Resets in 4d 13h": "4 天 13 小时后重置",
    "Resets in 4d 13h.": "4 天 13 小时后重置。",
    "Resets in less than a minute": "不到 1 分钟后重置",
    "Resets in less than a minute.": "不到 1 分钟后重置。",
    "Resets soon": "即将重置",
    "Resets soon.": "即将重置。",
    "Resize side question panel": "调整旁路提问面板大小",
    "Resize terminal panes": "调整终端面板大小",
    "Resized Browser window": "已调整浏览器窗口大小",
    "Resizing Browser window": "正在调整浏览器窗口大小",
    "Response A": "回答 A",
    "Response A was better": "回答 A 表现更优",
    "Response B": "回答 B",
    "Response B was better": "回答 B 表现更优",
    "Restart Main Language Server": "重启主语言服务",
    "Restart Sidecar": "重启伴随服务",
    "Restart to apply update": "重启以应用更新",
    "Restart to apply updates": "重启以应用更新",
    "Restart to Update": "重启以更新",
    "Restore": "还原",
    "Restore Conversation": "恢复会话",
    "Restore Defaults": "恢复默认设置",
    "Restore Pane": "还原面板",
    "Restore split view": "恢复分栏视图",
    "Resume": "恢复",
    "Resume queue": "恢复队列",
    "Retrieved Browser Pages": "已获取浏览器页面列表",
    "Retrieved Console Logs from Browser": "已从浏览器获取控制台日志",
    "Retrieving Browser Pages": "正在获取浏览器页面列表",
    "Retrieving Console Logs from Browser": "正在从浏览器获取控制台日志",
    "Retry": "重试",
    "Retry Connection": "重试连接",
    "Reveal in File Explorer": "在文件资源管理器中显示",
    "Reveal in Finder": "在访达中显示",
    "Revert and redo turn, best of N:": "撤回并重做本轮（多候选对决 Best-of-N）：",
    "Revert Changes": "撤回修改",
    "Revert file changes": "还原文件更改",
    "Review Changes": "审查更改",
    "Revoke": "撤销",
    "Rewinds the conversation only. Files in this workspace stay as they are now.": "仅回退会话。此工作区中的文件将保持当前状态。",
    "Rule Files": "规则文件",
    "Rule Priority": "规则优先级",
    "Rules": "规则库",
    "Run": "运行",
    "Run and Debug": "运行与调试",
    "run as Flash": "均以 Flash 模型运行",
    "run as Flash.": "均以 Flash 模型运行。",
    "Run automation": "运行自动化",
    "Run Automation": "运行自动化",
    "Run command": "运行命令",
    "Run in a new worktree": "在新建工作树 (Worktree) 中运行",
    "Run in background": "在后台保持运行",
    "Run in Background": "在后台保持运行",
    "Run in Isolated Environment": "在隔离环境中运行",
    "Run in your current workspace": "在当前工作区中运行",
    "Run Now": "立即运行",
    "Running": "正在运行",
    "s run as Flash": "均以 Flash 模型运行",
    "s run as Flash.": "均以 Flash 模型运行。",
    "Same Project": "同一项目",
    "Saturday": "周六",
    "Save": "保存",
    "Save All": "全部保存",
    "Save Automation": "保存自动化",
    "Save Comment": "保存评论",
    "Save Image": "保存图片",
    "Save Video": "保存视频",
    "Saving...": "正在保存...",
    "Scan the code to open this device in": "扫描二维码在此设备中打开",
    "Scan the code to open this device in ": "扫描二维码在此设备中打开 ",
    "Scan the code to open this device in Remote Control, or": "扫描二维码在远程控制中打开此设备，或",
    "Scan the code to open this device in Remote Control, or ": "扫描二维码在远程控制中打开此设备，或 ",
    "Scan the code to open this device in Remote Control, or copy link.": "扫描二维码在远程控制中打开此设备，或复制链接。",
    "Schedule": "定时计划",
    "Scheduled": "已计划",
    "Screen Recording": "屏幕录制",
    "Screenshot": "截图",
    "Scroll to bottom": "滚动至底部",
    "Scroll to Bottom": "滚动到底部",
    "Scrolled down in Browser": "已在浏览器中向下滚动",
    "Scrolled in Browser": "已在浏览器中滚动页面",
    "Scrolled up in Browser": "已在浏览器中向上滚动",
    "Scrolling down in Browser": "正在浏览器中向下滚动",
    "Scrolling in Browser": "正在浏览器中滚动页面",
    "Scrolling up in Browser": "正在浏览器中向上滚动",
    "Search": "搜索",
    "Search across files...": "跨文件搜索...",
    "Search by name or Cascade ID...": "按名称或级联会话 ID 搜索...",
    "Search conversations": "搜索会话",
    "Search Conversations": "搜索会话",
    "Search conversations based on their contents": "基于内容搜索会话",
    "Search conversations based on their contents.": "基于内容搜索会话。",
    "Search conversations...": "搜索会话...",
    "Search file contents": "搜索文件内容",
    "Search file contents...": "搜索文件内容...",
    "Search files...": "搜索文件...",
    "Search for commands...": "搜索命令...",
    "Search for content to open": "搜索要打开的内容",
    "Search for conversations...": "搜索会话...",
    "Search for files in the project...": "在项目中搜索文件...",
    "Search is still indexing your conversations, so results may be incomplete": "搜索服务仍在为您的对话建立索引，结果可能不完整",
    "Search is still indexing your conversations, so results may be incomplete.": "搜索服务仍在为您的对话建立索引，结果可能不完整。",
    "Search past workspaces...": "搜索历史工作区...",
    "Search past worktrees...": "搜索历史工作树...",
    "Search Projects": "搜索项目",
    "Search projects...": "搜索项目...",
    "Search results": "搜索结果",
    "Search tabs, files, plugins, subagents, artifacts, tasks...": "搜索标签页、文件、插件、子智能体、产物文档、任务...",
    "Search tabs, files, subagents, artifacts, tasks...": "搜索标签页、文件、子智能体、产物、任务...",
    "Search workspaces...": "搜索工作区...",
    "Searched": "已搜索",
    "Searched files": "已搜索文件",
    "Searched for files": "已搜索文件",
    "Searching": "正在搜索",
    "Searching...": "正在搜索...",
    "Section header:": "章节标题：",
    "See all": "查看全部",
    "See All": "查看全部",
    "See less": "收起",
    "Select": "选择",
    "Select a winner to continue": "选择一个优胜方案以继续",
    "Select Agent": "选择智能体",
    "Select All": "全选",
    "Select an option": "选择一个选项",
    "Select branch": "选择分支",
    "Select category to search...": "选择要搜索的类别...",
    "Select Day": "选择日期",
    "Select Default Branch": "选择默认分支",
    "Select Default Profile": "选择默认配置文件",
    "Select Environment": "选择环境",
    "Select Hour": "选择时间",
    "Select light, dark, or inherit system settings.": "选择浅色、深色或跟随系统设置。",
    "Select modes": "选择模式",
    "Select Next Conversation": "选择下一会话",
    "Select Previous Conversation": "选择上一会话",
    "select project": "选择项目",
    "Select Project": "选择项目",
    "Select Project to associate": "选择要关联的项目",
    "Select text in the artifact to add a comment": "在产物中选择文本以添加评论",
    "Select winner": "选择优胜方案",
    "Select Winner": "选择优胜方案",
    "Select workspace": "选择工作区",
    "Select Workspace": "选择工作区",
    "Select workspace...": "选择工作区...",
    "Select Worktree": "选择工作树",
    "Select your license": "选择您的许可证",
    "Selected Option in Browser": "已在浏览器中选择选项",
    "Selected region": "选定区域",
    "Selecting Option in Browser": "正在浏览器中选择选项",
    "Selection": "选择",
    "Selection Actions": "选区操作",
    "Semantic searched": "已完成语义搜索",
    "Semantic searching": "正在执行语义搜索",
    "Send command input?": "是否发送命令输入？",
    "Send feedback": "发送反馈",
    "Send Feedback": "发送反馈",
    "Send feedback as": "以此身份发送反馈",
    "Send immediately": "立即发送",
    "Send Immediately": "立即发送",
    "Send message": "发送消息",
    "Send Message": "发送消息",
    "Send message immediately": "立即发送消息",
    "Send next message in queue": "发送队列中的下一条消息",
    "send now": "立即发送",
    "Send now": "立即发送",
    "Send Now": "立即发送",
    "SEND NOW": "立即发送",
    "Sending transcribed message...": "正在发送转写消息...",
    "Sends after agent": "智能体结束后发送",
    "Sends after agent finishes": "智能体结束后发送",
    "sends after agent finishes working": "智能体结束工作后发送",
    "Sends after agent finishes working": "智能体结束工作后发送",
    "Sends immediately": "立即发送",
    "Server": "服务器",
    "Session Summary": "会话摘要",
    "Set API Key": "设置 API 密钥",
    "Settings": "设置",
    "Setup may take over 5 minutes. Please keep this screen open during setup.": "设置可能需要 5 分钟以上，请在设置期间保持此屏幕打开。",
    "Setup Script": "项目初始化脚本",
    "Share": "分享",
    "Shares this repository, with a working copy of its own. Uncommitted changes stay behind.": "共享此代码仓库，并拥有自己的工作副本。未提交的更改将保留在原处。",
    "Sharing this conversation will export its history. Anyone with the link will be able to load and view it.": "分享此会话将导出其历史记录。任何拥有链接的人都可以加载和查看。",
    "Shift+Enter Queues after the turn": "Shift+Enter 轮次结束后进入排队",
    "Shift+Enter Sends immediately": "Shift+Enter 立即发送",
    "Show": "显示",
    "Show all": "显示全部",
    "Show All": "显示全部",
    "Show All Commands": "显示所有命令面板",
    "Show all resources": "显示全部资源",
    "Show details": "显示详情",
    "Show Details": "显示详情",
    "Show Diff": "显示差异对比",
    "Show Error": "显示错误",
    "Show fewer resources": "收起部分资源",
    "Show in Explorer": "在文件资源管理器中显示",
    "Show in File Explorer": "在文件资源管理器中显示",
    "Show in File Manager": "在文件管理器中显示",
    "Show in Finder": "在访达中显示",
    "Show JavaScript Result": "显示 JavaScript 结果",
    "Show Less": "收起",
    "Show Line Numbers": "显示行号",
    "Show more": "显示更多",
    "Show More": "显示更多",
    "Show more results": "显示更多结果",
    "Show Selection Actions": "显示选中内容操作",
    "Show settings anyway": "仍然显示设置",
    "Side by Side Diff": "并排对比",
    "Side Question:": "旁路提问：",
    "Sidebar grouped by project": "侧边栏已按项目分组",
    "Sidebar grouped by workspace": "侧边栏已按工作区分组",
    "Sidebar on Left": "侧边栏靠左",
    "Sidebar on Right": "侧边栏靠右",
    "Sidebar Position": "侧边栏位置",
    "Sidecar Logs": "伴随服务日志",
    "Sidecar Port": "伴随服务端口",
    "Sidecar Services": "伴随服务管理",
    "Sidecars": "伴随服务",
    "Sign in": "登录",
    "Sign In": "登录",
    "Sign in again": "重新登录",
    "Sign in with a different account": "使用其他账号登录",
    "Sign in with business account": "使用企业账号登录",
    "Sign Out": "退出登录",
    "Signed in as": "当前登录身份：",
    "Signing in...": "登录中...",
    "Signing Out...": "正在退出登录...",
    "Simplified interface without developer tooling.": "无开发者工具的简化界面。",
    "Simulated Key Press in Browser": "已在浏览器中模拟按键",
    "Simulating Key Press in Browser": "正在浏览器中模拟按键",
    "Skill Custom Paths": "技能自定义路径",
    "Skill Directory": "技能目录",
    "Skill Parameters": "技能参数",
    "Skill used": "已使用技能",
    "Skill Used": "已使用技能",
    "Skills": "技能库",
    "Skills & rules settings": "技能与规则设置",
    "Skills and Rules Settings": "技能与规则设置",
    "Skills Management": "技能管理",
    "Skills used": "已使用技能",
    "Skills Used": "已使用技能",
    "Skin": "界面风格",
    "Skip": "跳过",
    "Skip survey": "跳过问卷",
    "Skip Survey": "跳过问卷",
    "Skipped": "已跳过",
    "Skipping...": "正在跳过...",
    "Smooth Scrolling": "平滑滚动",
    "Some older conversations are not searchable. Clear up large conversations to remediate.": "部分较早的会话无法被搜索。清理体积较大的会话可解决此问题。",
    "Something went wrong": "出错了",
    "Something went wrong!": "出错了！",
    "Something went wrong.": "出错了。",
    "Sort": "排序",
    "Sort Conversations": "会话排序",
    "Source Control": "源代码管理",
    "Sources": "来源",
    "Split": "分屏",
    "Split Conversation Horizontally": "水平分屏会话",
    "Split Conversation Vertically": "垂直分屏会话",
    "Split Diff": "分屏差异",
    "Split Down": "向下拆分",
    "Split Left": "向左拆分",
    "Split Right": "向右拆分",
    "Split Terminal": "分屏终端",
    "Split Up": "向上拆分",
    "Stable": "稳定版",
    "Stage change": "暂存更改",
    "Staged": "已暂存",
    "Staged Changes": "暂存的更改",
    "Staged index changes and working tree changes": "暂存区索引更改与工作区更改",
    "Staged index changes and working tree changes.": "暂存区索引更改与工作区更改。",
    "Stale info": "信息陈旧过时",
    "Standalone Conversation": "独立会话",
    "Standalone Conversations": "独立会话",
    "Standalone terminals": "独立终端",
    "Standalone Terminals": "独立终端",
    "Start battle mode": "开启对决模式",
    "Start Battle Mode": "开启对决模式",
    "Start Sidecar": "启动伴随服务",
    "Start Voice Recording": "开始语音录制",
    "Status": "状态",
    "Status Bar": "状态栏",
    "Status Bar Visibility": "状态栏可见性",
    "steps to reproduce": "重现步骤",
    "Steps to reproduce": "重现步骤",
    "Steps to Reproduce": "重现步骤",
    "Steps To Reproduce": "重现步骤",
    "Steps to reproduce the issue": "重现问题的操作步骤",
    "Stop": "停止",
    "Stop All Subagents": "停止所有子智能体",
    "Stop automation": "停止自动化",
    "Stop Automation": "停止自动化",
    "Stop execution": "停止执行",
    "Stop Execution": "停止执行",
    "Stop Generating": "停止生成",
    "Stop Generation": "停止生成",
    "Stop recording": "停止录制",
    "Stop Recording": "停止录制",
    "Stop Recording and Send": "停止录制并发送",
    "Stop Sequences": "停止序列",
    "Stop Sidecar": "停止伴随服务",
    "Stop subagent": "停止子智能体",
    "Stop Subagent": "停止子智能体",
    "Stop Task": "停止任务",
    "Stop Voice Recording": "停止语音录制",
    "Stopped": "已停止",
    "Stopped after": "停止于",
    "Storage": "存储空间",
    "Streaming": "流式输出",
    "Streaming Generation": "正在流式生成",
    "Strict": "严格",
    "Strict Mode": "严格模式",
    "Strong": "高对比度",
    "Subagent": "子智能体",
    "Subagent Conversation": "子智能体会话",
    "Subagent ended": "子智能体已结束",
    "Subagents": "子智能体",
    "Submit": "提交",
    "Submit Appeal": "提交申诉",
    "Submit comment": "提交评论",
    "Submit feedback": "提交反馈",
    "Submitted": "已提交",
    "Submitting...": "正在提交...",
    "Subscription": "订阅套餐",
    "Subtitles": "副标题",
    "Success": "成功",
    "Success, Continuing...": "认证成功，正在继续...",
    "Successfully imported project:": "已成功导入项目：",
    "Suggestions": "建议",
    "Sunday": "周日",
    "Suspend": "暂停",
    "Switch Account": "切换账户",
    "Switch IDE Workspace": "切换 IDE 工作区",
    "System": "跟随系统",
    "System Instructions": "系统指令",
    "System Message": "系统消息",
    "System Prompt": "系统提示词",
    "Tab Speed": "标签切换速度",
    "Tab to Import": "按 Tab 导入",
    "Tab to Jump": "按 Tab 跳转",
    "Table of contents": "目录大纲",
    "Table options": "表格选项",
    "Taking longer than usual to load": "加载耗时比平时更长",
    "Taking Screenshot": "正在截图",
    "Target text in PDF...": "PDF 中的目标文本...",
    "Task Log": "任务日志",
    "Team of subagents to do long running work": "由多个子智能体协作完成长周期任务",
    "Telemetry & Analytics": "遥测与分析",
    "Tell us more about your choice": "详细说明您的选择",
    "Tell us more about your choice (optional)": "详细说明您的选择（可选）",
    "Temperature": "采样温度",
    "Terminal": "终端",
    "Terminal Command Auto Execution": "终端命令自动执行",
    "Terminal commands": "终端命令",
    "Terminal Commands": "终端命令权限",
    "Terminal commands the agent can execute in this workspace.": "智能体可在此工作区中执行的终端命令。",
    "Terminal: Add to Chat": "终端：添加到对话",
    "Terminals": "终端列表",
    "Terms of Service": "服务条款",
    "Test failed": "测试失败",
    "Testing": "正在测试",
    "Text attachment": "文本附件",
    "Thank you for your feedback": "感谢您的反馈",
    "Thank you for your feedback!": "感谢您的反馈！",
    "Thanks for helping make Gemini better! This is a critical part of evaluating and improving our models.": "感谢您帮助我们让 Gemini 变得更好！这是评估与改进模型的关键环节。",
    "Thanks for your feedback!": "感谢您的反馈！",
    "The agent has encountered an internal error.": "智能体遇到了内部错误。",
    "The agent works with autonomy-enhancing features and does not ask questions or request new permissions.": "智能体将启用自主增强特性运行，期间不会向您提问或请求新权限。",
    "The browser subagent can be invoked by typing /browser in the conversation input box.": "可在会话输入框中输入 /browser 来调用浏览器子智能体。",
    "The conversation was compacted to fit within the context window.": "会话已被压缩以适应上下文窗口。",
    "The conversation was compacted while generating this response.": "在生成此回复期间，会话上下文已执行压缩。",
    "The current trigger rate is too high.": "当前触发频率过高。",
    "the customization budget is available": "自定义扩展预算可用",
    "the customization budget is available.": "自定义扩展预算可用。",
    "The full developer experience.": "完整开发者体验。",
    "The Google3 project is deprecated": "Google3 项目已弃用",
    "The server returned no conversation to fork into": "服务器未返回可供分支的对话",
    "The server returned no conversation to fork into.": "服务器未返回可供分支的对话。",
    "There was an error with your authentication. To log in, click": "您的身份验证出错。要登录，请点击",
    "There was an unexpected issue setting up your account.": "设置您的账户时出现意外问题。",
    "Thinking": "深度思考中",
    "Thinking Budget": "思考预算",
    "Thinking Budget (Tokens)": "思考预算 (Token 数)",
    "Thinking for": "正在思考",
    "Thinking Process": "思考流程",
    "This action cannot be undone.": "此操作不可撤销。",
    "This cannot be undone.": "此操作无法撤销。",
    "This chat is archived.": "此会话已归档。",
    "This conversation grew too large, so the history before this point may be missing or incomplete.": "此会话体积过大，因此该节点之前的历史记录可能缺失或不完整。",
    "This Google Cloud project is not supported. Input a different project, or sign in with another account.": "不支持此 Google Cloud 项目。请输入其他项目，或使用其他账号登录。",
    "This is very dangerous and we do not recommend doing this": "这非常危险，我们不建议这样做",
    "This is very dangerous and we do not recommend doing this.": "这非常危险，我们不建议这样做。",
    "This plugin provides a specialized suite of skills for data engineers and database practitioners working on Google Cloud. It acts as an expert assistant, allowing you to easily interact with your database, analyze your data, and optimize your database workload.": "此插件为在 Google Cloud 上工作的数据工程师和数据库从业者提供专业技能套件。它充当专家助手，让您轻松与数据库交互、分析数据并优化数据库工作负载。",
    "This prompt is straightforward and does not need alternative comparisons.": "此提示词非常简单直接，无需多方案对比。",
    "This request is not well-suited for parallel Best-of-N generation.": "此请求不适合使用并行多候选对决 (Best-of-N) 生成。",
    "This skill came from the marketplace, so you can add it again whenever you need it.": "此技能来自应用市场，您可以随时按需再次添加。",
    "This subagent was killed and can no longer be messaged.": "该子智能体已被终止，无法再发送消息。",
    "Thorough research": "调研深入全面",
    "Thorough testing": "测试全面彻底",
    "Thought": "思考",
    "Thought Process": "思考过程",
    "Thursday": "周四",
    "Tie": "平局",
    "Time to First Token (TTFT)": "首 Token 响应时间 (TTFT)",
    "Timed": "已计时",
    "Timed out": "已超时",
    "Timed out waiting for the update to be installed.": "等待安装更新超时。",
    "Timed out waiting for the updated instance to load.": "等待更新后的实例加载超时。",
    "Timeout": "超时",
    "Timer expired": "定时器已到期",
    "timer has expired": "定时器已到期",
    "Timer has expired": "定时器已到期",
    "Tip: Complex tasks get better results with multiple responses.": "提示：复杂任务通过多方案对比可获得更佳结果。",
    "to add to Agent": "以添加到智能体",
    "to be installed": "才能运行",
    "to be installed.": "才能运行。",
    "to have the agent generate a plan.": "以让智能体生成计划。",
    "to upload": "以上传",
    "To use browser tools, you need to enable remote debugging:": "要使用浏览器工具，您需要启用远程调试：",
    "To use the agent, please login": "请先登录以使用智能体",
    "today": "今天",
    "Today": "今天",
    "Toggle": "切换",
    "Toggle Artifacts": "切换产物面板显示",
    "Toggle Auxiliary Pane": "切换辅助面板",
    "Toggle Developer Tools": "切换开发者工具",
    "Toggle Environment Selector": "切换环境选择器",
    "Toggle File Viewer": "切换文件查看器",
    "Toggle Full Screen": "切换全屏",
    "Toggle Fullscreen": "切换全屏",
    "Toggle Overview Panel": "切换概览面板",
    "Toggle Project Selector": "切换项目选择器",
    "Toggle Sidebar": "切换侧边栏显示",
    "Toggle Terminal": "切换终端显示",
    "Toggle Voice Recording": "切换语音录音",
    "Token Usage": "Token 用量",
    "Tokens": "Token 统计",
    "Tokens Used": "已用 Token",
    "Too many surveys": "问卷调查过多",
    "Took Screenshot": "已截图",
    "Tool arguments": "工具参数",
    "Tool Call Generation": "正在生成工具调用",
    "Tool Execution": "工具执行中",
    "Tool Output": "工具输出",
    "Top P Sampling": "Top P 采样值",
    "Trigger multiple response variants from the same prompt.": "针对同一提示词触发生成多个候选回复方案。",
    "Troubleshoot": "故障排查",
    "Try again": "重试",
    "Try Again": "重试",
    "Try out early-stage features before they ship. These may change or be removed at any time.": "在正式发布前尝试早期功能。这些功能可能随时更改或移除。",
    "Try Remote Control": "体验远程控制",
    "Tuesday": "周二",
    "Turbo": "极速",
    "Turbo mode": "极速模式",
    "Type / and select plan to have the agent generate a plan.": "输入 / 并选择 plan 以让智能体生成计划。",
    "Type to search for code across your workspace.": "输入内容以在工作区中搜索代码。",
    "Typed into Browser": "已在浏览器中输入文本",
    "Typing into Browser": "正在浏览器中输入文本",
    "UI Extensions": "UI 扩展",
    "Unauthenticated": "未认证",
    "Unavailable": "不可用",
    "Uncommitted": "未提交",
    "Under-researched": "调研不够深入",
    "Undercommunicated": "沟通说明不足",
    "Understanding Intent": "意图理解",
    "Undo": "撤销",
    "Undo restores your entire workspace to its state at this point.": "撤销会将整个工作区恢复到此节点的状态。",
    "Undo To Here": "撤销到此处",
    "Undo to this point": "撤销到此节点",
    "Unfold code block": "展开代码块",
    "Unified Diff": "统一差异",
    "Uninstalling...": "正在卸载...",
    "Unknown": "未知",
    "Unknown edit": "未知编辑",
    "Unknown Environment": "未知环境",
    "Unknown file edit": "未知文件编辑",
    "Unknown Workspace": "未知工作区",
    "Unnamed": "未命名",
    "Unnamed resource": "未命名资源",
    "Unnamed rule": "未命名规则",
    "unpin": "取消置顶",
    "Unpin": "取消置顶",
    "UNPIN": "取消置顶",
    "Unpin conversation": "取消置顶会话",
    "Unpin Conversation": "取消置顶会话",
    "Unpin this conversation": "取消置顶此会话",
    "Unpin This Conversation": "取消置顶此会话",
    "Unread": "未读",
    "Unstage change": "取消暂存更改",
    "Unstaged Changes": "未暂存的更改",
    "Untitled": "无标题",
    "Untitled Conversation": "无标题会话",
    "Untracked (Unstaged)": "未跟踪 (未暂存)",
    "Update Anyway": "仍然更新",
    "Update Available": "发现可用更新",
    "Update Channel": "更新通道",
    "Updated": "更新于",
    "Updated sidebar grouping": "已更新侧边栏分组",
    "Upgrade": "立即升级",
    "Upload to Agent": "上传至智能体",
    "Uploads": "上传内容",
    "Use advanced SSO config": "使用高级 SSO 配置",
    "Use business account": "使用企业账号",
    "Use Existing": "使用现有项",
    "Use full Git clones for Best of N": "Best of N 使用完整 Git 克隆",
    "Use full VCS clones for Best of N": "Best of N 使用完整 VCS 克隆",
    "Use Google Cloud project instead": "改用 Google Cloud 项目",
    "Use regular expression": "使用正则表达式",
    "Used context well": "善用上下文信息",
    "Used tool": "已使用工具",
    "User cancelled agent execution.": "用户已取消智能体执行。",
    "User Global Rules": "用户全局规则",
    "User Intent": "用户意图",
    "User message": "用户消息",
    "User Prompt Hook": "用户提示词钩子",
    "User uploaded image": "用户上传的图片",
    "Using the Google Antigravity Python SDK to build AI agents": "使用 Google Antigravity Python SDK 构建 AI 智能体",
    "Using this option will attempt to revert all changes in this turn and redo the turn using N parallel trajectories. This will discard any changes made in this turn in order to redo it.": "使用此选项将尝试撤回本轮中的所有更改，并使用 N 条并行轨迹重新执行本轮。为完成重做，本轮已产生的所有更改将被丢弃。",
    "Validate": "验证",
    "Validation failed. Please verify requirements and try again.": "验证失败，请检查要求后重试。",
    "Variables": "变量",
    "Verbose Agent Chat": "详细智能体对话输出",
    "Verify": "验证",
    "Verify API Connection": "验证 API 连接",
    "Version": "版本信息",
    "Video attachment": "视频附件",
    "View": "视图",
    "View child subagents": "查看下级子智能体",
    "View comments": "查看评论",
    "View Debug": "查看调试信息",
    "View Diff": "查看差异 (Diff)",
    "View documentation": "查看文档",
    "View Inline Diff": "行内对比",
    "View Log File": "查看日志文件",
    "View network request": "查看网络请求",
    "View network requests": "查看网络请求",
    "View Page": "查看页面",
    "View plans": "查看套餐方案",
    "View Release Notes": "查看发行说明",
    "View Split Diff": "分屏对比",
    "View Unified Diff": "统一对比",
    "view usage": "查看用量明细",
    "View usage": "查看用量明细",
    "View Usage": "查看用量明细",
    "View Usage Details": "查看用量详情",
    "Viewed": "已查看",
    "Vision Support": "视觉多模态支持",
    "Waiting": "等待中",
    "Waiting for user input": "正在等待用户输入",
    "Walkthrough": "完成总结文档",
    "Warning": "警告",
    "We apologize for the inconvenience. Please try again later.": "给您带来不便，我们深表歉意。请稍后重试。",
    "Web Preview": "网页预览",
    "Wednesday": "周三",
    "Weekdays": "工作日",
    "Weekends": "周末",
    "Weekly": "每周",
    "Weekly Limit Remaining": "每周剩余额度",
    "Welcome back!": "欢迎回来！",
    "Welcome to": "欢迎使用",
    "What counts as a document": "哪些内容计为文档",
    "What did you like about this response?": "您喜欢这条回复的哪些方面？",
    "When debug mode is on, you can see additional information about each steps in the conversation.": "开启调试模式后，您可以查看会话中每个步骤的详细诊断信息。",
    "When enabled, Agent is given awareness of lint errors created by its edits and may fix them without explicit user prompting.": "启用后，智能体将感知其编辑产生的 lint 错误，并可在无需用户明确提示的情况下修复它们。",
    "When enabled, the agent will include default customizations, including default skills.": "启用后，智能体将包含默认的自定义设置，包括默认技能。",
    "When toggled on, Antigravity collects usage data to help Google enhance performance and features.": "开启后，Antigravity 将收集使用数据以帮助 Google 提升性能与产品功能。",
    "when working in this project": "在此项目中工作时",
    "When working in this project": "在此项目中工作时",
    "when working in this project.": "在此项目中工作时。",
    "When working in this project.": "在此项目中工作时。",
    "Why are you opting out of auto-triggered Best-of-N?": "您为什么退出自动触发的多候选对决 (Best-of-N)？",
    "Why are you opting out?": "您为什么选择退出？",
    "Why did you choose this winner?": "您为什么选择此优胜方案？",
    "Why did you prefer this response?": "您为什么更青睐此回答？",
    "Wide": "宽",
    "Window": "窗口",
    "Window Controls": "窗口控制按钮",
    "Winner": "优胜方案",
    "Winner survey": "优胜方案评选调查",
    "Winner Survey": "优胜方案评选调查",
    "Word Wrap": "自动换行",
    "Work with local agents from another device.": "从其他设备与本地智能体协同工作。",
    "Working": "正在运行",
    "Working Changes": "工作区变更",
    "Working Directory:": "工作目录：",
    "Working...": "正在运行...",
    "Workspace": "工作区",
    "Workspace + Worktree": "工作区 + 工作树",
    "Workspace Actions": "工作区操作",
    "Workspace archived successfully": "工作区已成功归档",
    "Workspace CL Status": "工作区 CL 状态",
    "Workspace File Explorer": "工作区文件资源管理器",
    "Workspace Name": "工作区名称",
    "Workspace name can only contain letters, numbers, underscores, and dashes": "工作区名称只能包含字母、数字、下划线和横线",
    "Workspace Rules": "工作区规则",
    "Workspace Settings": "工作区专属设置",
    "Workspace setup warning": "工作区设置警告",
    "Workspace URI query parameter": "工作区 URI 查询参数",
    "Workspaces": "工作区列表",
    "Workspaces are not available for this project": "此项目不支持工作区",
    "Worktree": "工作树",
    "Worktrees are a git feature. This folder is shared as is.": "工作树 (Worktrees) 是一项 Git 特性。此文件夹将按原样共享。",
    "Worktrees are available for Git repositories": "Git 仓库支持使用工作树 (Worktrees)",
    "Worktrees are not available for this project": "此项目不支持工作树 (Worktrees)",
    "Write a comment...": "撰写评论...",
    "Write Files": "写入文件",
    "yesterday": "昨天",
    "Yesterday": "昨天",
    "You are on the latest version": "您当前已是最新版本",
    "You can upgrade to a Google AI Ultra plan to receive higher rate limits.": "您可以升级至 Google AI Ultra 以获取更高的请求配额与速率上限。",
    "You cannot modify Remote Control settings from Remote Control. Please modify these settings on your local application.": "您无法在远程控制端修改远程控制设置。请在本地客户端应用中修改这些设置。",
    "You cannot sign out from Remote Control. Please sign out on your local application.": "您无法在远程控制端退出登录。请在本地客户端应用中退出登录。",
    "You've reached the maximum number of turns for this battle. End battle mode to continue.": "您已达到本次对决的最大轮次上限。请结束对决模式以继续。",
    "Your Plan": "当前方案",
    "Your Plan: Google AI Pro": "当前方案：Google AI Pro",
    "No commits to push": "无待推送的提交",
    "No commits to pull": "无待拉取的提交",
    "Hide Whitespace Changes": "隐藏空白字符更改",
    "Show Whitespace Changes": "显示空白字符更改",
    "Ignore Whitespace Changes": "忽略空白字符更改",
    "Ignore Whitespace": "忽略空白字符",
    "Send message Enter": "发送消息 Enter",
    "Send message (Enter)": "发送消息 (Enter)",
    "Send message Return": "发送消息 Return",
    "Send message (Return)": "发送消息 (Return)",
    "Send message Ctrl+Enter": "发送消息 Ctrl+Enter",
    "Send message (Ctrl+Enter)": "发送消息 (Ctrl+Enter)",
    "Send message Cmd+Enter": "发送消息 Cmd+Enter",
    "Send message (Cmd+Enter)": "发送消息 (Cmd+Enter)",
    "Send Message Enter": "发送消息 Enter",
    "Send Message (Enter)": "发送消息 (Enter)",
    "Send Message Return": "发送消息 Return",
    "Send Message (Return)": "发送消息 (Return)",
    "Send Message Ctrl+Enter": "发送消息 Ctrl+Enter",
    "Send Message (Ctrl+Enter)": "发送消息 (Ctrl+Enter)",
    "Send Message Cmd+Enter": "发送消息 Cmd+Enter",
    "Send Message (Cmd+Enter)": "发送消息 (Cmd+Enter)",
    "All changes since the branch point": "自原分支分叉点以来的全部更改",
    "True changes vs the parent workspace": "相对于父工作区的实际更改",
    "Playback speed (< / >)": "播放倍速 (< / >)",
    "2x playback speed": "2x 倍速播放",
    "Play (k)": "播放 (k)",
    "Pause (k)": "暂停 (k)",
    "Back 5s (←)": "后退 5 秒 (←)",
    "Forward 5s (→)": "快进 5 秒 (→)",
    "Mute (m)": "静音 (m)",
    "Unmute (m)": "取消静音 (m)",
    "Fullscreen (f)": "全屏 (f)",
    "Exit fullscreen (f)": "退出全屏 (f)",
    "Zoom in (+)": "放大 (+)",
    "Zoom out (-)": "缩小 (-)",
    "Reset zoom (0)": "重置缩放 (0)",
    "Close (Esc)": "关闭 (Esc)",
    "Previous (←)": "上一个 (←)",
    "Next (→)": "下一个 (→)",
    "Download video": "下载视频",
    "Download image": "下载图片",
    "Copy image": "复制图片",
    "Failed to load media": "加载媒体失败",
    "Failed to load image": "加载图片失败",
    "Enlarged media": "放大查看媒体",
    "Media actions": "媒体操作",
    "Seek": "拖动进度",
    "Volume": "音量",
    "Zoom": "缩放",
    "Zoom in": "放大",
    "Zoom out": "缩小",
    "Unable to resolve audio source URL": "无法解析音频源 URL",
    "Unable to resolve PDF source URL": "无法解析 PDF 源 URL",
    "Missing Folder": "缺失文件夹",
    "Missing Folders": "缺失文件夹",
    "does not exist.": "不存在。",
    "do not exist.": "不存在。",
    "Fix with Agent": "使用智能体修复",
    "Ask the agent to diagnose and fix this server": "让智能体诊断并修复此服务",
    "Sign-in required": "需要登录",
    "MCP Restart Error:": "MCP 重启错误：",
    "Needs re-auth": "需要重新授权",
    "Accounts": "账号",
    "Signed-in accounts": "已登录账号",
    "Paste code": "粘贴授权码",
    "Authorization Required": "需要授权",
    "Folder is empty": "文件夹为空",
    "Folder has more than 1000 files": "文件夹包含超过 1000 个文件",
    "Folder is larger than 20MB": "文件夹大小超过 20MB",
    "Zipping ": "正在压缩 ",
    "Add folder path": "添加文件夹路径",
    "Open folder": "打开文件夹",
    "Add Resource": "添加资源",
    "Remove resource": "移除资源",
    "Back to resource menu": "返回资源菜单",
    "Filter resources...": "筛选资源...",
    "Upload Files": "上传文件",
    "No matching resources found.": "未找到匹配的资源。",
    "Type absolute path or navigate folders...": "输入绝对路径或浏览文件夹...",
    "Enter directory path...": "输入目录路径...",
    "Custom Order": "自定义顺序",
    "Sort By": "排序方式",
    "Mark This Conversation as Read": "将此会话标为已读",
    "Mark This Conversation as Unread": "将此会话标为未读",
    "Mark All as Read": "全部标为已读",
    "Couldn't mark conversations as read": "无法将会话标为已读",
    "Cancel Sending Message": "取消发送消息",
    "Fork conversation in this folder": "在此文件夹中分叉会话",
    "Keeps working in this folder. Nothing is copied.": "继续在此文件夹中工作，不复制任何文件。",
    "All Workspaces": "所有工作区",
    "Show temporary and forked workspaces": "显示临时与分叉工作区",
    "What best describes you?": "哪一项最符合您的身份？",
    "We'll tailor the experience to you.": "我们将为您量身定制使用体验。",
    "The full developer experience with code and tooling.": "包含代码与开发工具的完整开发者体验。",
    "General work": "通用办公",
    "Research, writing, and everyday tasks, without code.": "面向研究、写作与日常办公任务，无需编写代码。",
    "Get Anything Done with ": "借助以下工具搞定一切：",
    "Get Anything Done with Antigravity": "借助 Antigravity 搞定一切",
    "Build new features": "构建新功能",
    "Hand off a feature and come back to working code.": "交付功能需求，回来即可收获可用代码。",
    "Debug and fix": "调试与修复",
    "Automatically reproduce bugs, trace causes, test fixes.": "自动复现 Bug、追踪根因并测试修复方案。",
    "Research anything": "探索任何问题",
    "Ask about your code or any topic, get clear answers.": "询问代码或任何主题，获取清晰解答。",
    "Write and edit docs": "撰写与编辑文档",
    "Draft documents, emails, and notes that sound like you.": "起草贴合您个人风格的文档、邮件与笔记。",
    "Last Used": "上次使用",
    "Uploading to Google Drive…": "正在上传至 Google Drive…",
    "Uploaded to Google Drive": "已上传至 Google Drive",
    "Failed to upload HTML artifact to Drive": "上传 HTML 产物至 Google Drive 失败",
    "Artifact updated by agent": "智能体已更新产物",
    "Dismiss artifact update notice": "忽略产物更新通知",
    "Dismiss service announcement": "关闭服务公告",
    "Opens in the in-app preview pane. Some sites don't support iframe embedding and may not load.": "在应用内预览窗格中打开。部分网站不支持 iframe 嵌入，可能无法加载。",
    "Open in preview": "在预览窗格中打开",
    "Debug bundle uploaded!": "调试诊断包已上传！",
    "Can't open the Drive link?": "无法打开云端硬盘链接？",
    "Download the bundle manually and share it instead:": "请改为手动下载诊断包并分享：",
    "Uploads logs, settings, and conversation summaries to your Drive.": "将日志、设置与会话摘要上传至您的 Google Drive。",
    "We recommend attaching logs. Attaching logs will help the Antigravity team act on and prioritize your feedback.": "建议随附日志。附上日志有助于 Antigravity 团队快速定位并优先处理您的反馈。",
    "Trajectory Debug View": "执行轨迹调试视图",
    "Trajectory Stats": "轨迹统计信息",
    "Failed to load trajectory": "加载执行轨迹失败",
    "No cascade ID provided": "未提供会话流 (Cascade) ID",
    "Step Timing": "步骤耗时",
    "Sender Agent": "发送方智能体",
    "Step Preview": "步骤预览",
    "Excluded Step": "已排除的步骤",
    "This step is visible in the standard conversation view, but was excluded from the messages sent to the model.": "此步骤在标准会话视图中可见，但已从发送给模型的消息上下文中排除。",
    "Select a step in the timeline to inspect": "在时间线中选择一个步骤以查看详情",
    "Active Context Start": "活跃上下文起点",
    "Collapse idle": "折叠空闲时段",
    "By kind": "按类别",
    "By phase": "按阶段",
    "Emphasize": "高亮强调",
    "No steps with timestamps to place on a timeline.": "没有带时间戳的步骤可供在时间线上展示。",
    "← Parent": "← 父级",
    "Side-by-Side": "左右并排",
    "Side-by-side layout": "左右并排布局",
    "Stacked": "上下堆叠",
    "Stacked layout": "上下堆叠布局",
    "Debug view layout": "调试视图布局",
    "Double-click to reset panel sizes": "双击以重置面板大小",
    "Fit the whole trajectory": "适应完整轨迹视图",
    "Arguments Schema": "参数结构 (Schema)",
    "Artifact Name": "产物名称",
    "Unused Capacity": "未用容量",
    "Tool Defs": "工具定义",
    "No execution metadata available for this step.": "此步骤无可用的执行元数据。",
    "No Invocation Metadata": "无调用元数据",
    "No Invocation Associated": "未关联调用",
    "This step is not associated with an invocation.": "此步骤未关联任何模型调用。",
    "No Prompt or Tools Data": "无提示词或工具数据",
    "Prompt and tools metadata for this invocation has been cleared to save space. Full details are only preserved for the latest invocation.": "为节省空间，本次调用的提示词与工具元数据已被清理。完整详情仅保留在最新一次调用中。",
    "Time spent by the language model generating and streaming the tool call.": "语言模型生成并流式输出该工具调用所花费的时间。",
    "Time spent waiting in queue for previous tools to complete or move to background before execution began.": "开始执行前在队列中等待前置工具完成或转入后台所花费的时间。",
    "Non-model response token counts are estimations. The model API does not return per-message token counts.": "非模型回复的 Token 数量为估算值。模型 API 不会返回单条消息的精确 Token 计数。",
    "Back to Automations": "返回自动化列表",
    "This page is going away soon": "此页面即将下线",
    "Search conversations with": "可通过左上角的",
    "in the top left.": "图标搜索会话。",
    "View archived in the sidebar": "可在侧边栏查看已归档会话",
    "menu)": "菜单)",
    "Drop to add to group": "拖放以添加至分组",
    "Open Remote Control": "打开远程控制",
    "Remote Sessions": "远程会话",
    "Remote Session": "远程会话",
    "Connecting...": "正在连接...",
    "Reconnecting...": "正在重新连接...",
    "Switch Instance": "切换实例",
    "Instances": "实例列表",
    "Reload Host": "重新加载主机",
    "\"Allow remote debugging for this browser instance\"": "“为此浏览器实例允许远程调试”",
    "1 task running": "1 个运行中的任务",
    "A high-risk mode that disables all safety barriers. The agent operates with full system access, auto-executes all terminal commands, and reads or writes to all local files without review prompts.": "一种禁用所有安全屏障的高风险模式。智能体将以完全系统权限运行，自动执行所有终端命令，读写所有本地文件且不弹出审查提示。",
    "Access a file outside workspace": "访问工作区外部的文件",
    "Access grants": "授权访问列表",
    "Access to the browser agent tools is blocked by your organization's admin controls policy.": "您的组织管理员控制策略已阻止访问浏览器智能体工具。",
    "Active MCP Servers": "运行中的 MCP 服务",
    "Activity bar background color for the active item. The activity bar is showing on the far left or right and allows to switch between views of the side bar.": "活动栏中处于活动状态项的背景颜色。活动栏显示在最左侧或最右侧，用于在侧边栏的视图之间进行切换。",
    "Activity bar background color. The activity bar is showing on the far left or right and allows to switch between views of the side bar.": "活动栏背景颜色。活动栏显示在最左侧或最右侧，用于在侧边栏的视图之间进行切换。",
    "Activity bar border color for the active item. The activity bar is showing on the far left or right and allows to switch between views of the side bar.": "活动栏活动项的边框颜色。活动栏显示在最左侧或最右侧，用于在侧边栏的视图之间进行切换。",
    "Activity bar border color separating to the side bar. The activity bar is showing on the far left or right and allows to switch between views of the side bar.": "活动栏与侧边栏之间的分隔边框颜色。活动栏显示在最左侧或最右侧，用于在侧边栏的视图之间进行切换。",
    "Activity bar focus border color for the active item. The activity bar is showing on the far left or right and allows to switch between views of the side bar.": "活动栏活动项获得焦点时的边框颜色。活动栏显示在最左侧或最右侧，用于在侧边栏的视图之间进行切换。",
    "Activity bar item foreground color when it is active. The activity bar is showing on the far left or right and allows to switch between views of the side bar.": "活动栏项处于活动状态时的前景文本颜色。活动栏显示在最左侧或最右侧，用于在侧边栏的视图之间进行切换。",
    "Activity bar item foreground color when it is inactive. The activity bar is showing on the far left or right and allows to switch between views of the side bar.": "活动栏项处于非活动状态时的前景文本颜色。活动栏显示在最左侧或最右侧，用于在侧边栏的视图之间进行切换。",
    "Activity notification badge background color. The activity bar is showing on the far left or right and allows to switch between views of the side bar.": "活动栏通知角标的背景颜色。活动栏显示在最左侧或最右侧，用于在侧边栏的视图之间进行切换。",
    "Activity notification badge foreground color. The activity bar is showing on the far left or right and allows to switch between views of the side bar.": "活动栏通知角标的前景文本颜色。活动栏显示在最左侧或最右侧，用于在侧边栏的视图之间进行切换。",
    "Actuation Permissions": "操作执行权限",
    "Add Allowed Path": "添加允许路径",
    "Add MCP": "添加 MCP",
    "Add MCP Server": "添加 MCP 服务",
    "Add MCP Servers": "添加 MCP 服务",
    "Add MCP server": "添加 MCP 服务",
    "Add an MCP server above": "在上方添加一个 MCP 服务",
    "Add an MCP server above or add a custom one via the MCP Config.": "在上方添加 MCP 服务，或通过 MCP 配置文件添加自定义服务。",
    "Add to allowlist": "添加到白名单",
    "Administrator access (UAC)": "管理员权限 (UAC)",
    "Advanced File Access": "高级文件访问策略",
    "Agent Non-Workspace File Access": "智能体工作区外文件访问",
    "Agent Security Settings": "智能体安全设置",
    "Agent always asks for review before proceeding.": "在继续执行前，智能体始终请求审查确认。",
    "Agent always asks for review.": "智能体始终请求审查确认。",
    "Agent can scroll on browser pages to access more content.": "智能体可在浏览器页面上滚动以访问更多内容。",
    "Agent never asks for review. This maximizes the autonomy of the Agent, but also has the highest risk of the Agent operating over unsafe or injected Artifact content.": "智能体从不请求审查。这最大化了智能体的自主性，但智能体在不安全或注入的产物内容上操作的风险最高。",
    "Agent permissions preset selector": "智能体权限预设选择器",
    "Agent security mode": "智能体安全模式",
    "Agent settings and permissions for conversations outside of projects.": "项目外会话的智能体设置与权限。",
    "Agent will always ask to review in strict mode.": "在严格模式下，智能体将始终请求审查确认。",
    "Agents have full access to your machine and external resources.": "智能体拥有对您机器和外部资源的完全访问权限。",
    "Agents run in a secure sandbox that restricts access to external resources outside of your trusted folders.": "智能体运行在安全沙箱中，限制对您信任文件夹之外的外部资源的访问。",
    "All terminal commands require review. The agent can read or write to any file in the machine.": "所有终端命令均需审查。智能体可读写本机上的任意文件。",
    "Allow Cookie Access": "允许访问 Cookie",
    "Allow Form Input": "允许表单数据输入",
    "Allow List Terminal Commands": "允许自动执行的终端命令白名单",
    "Allow Once": "允许一次",
    "Allow Page Navigation": "允许页面跳转导航",
    "Allow Path": "允许访问路径",
    "Allow Screenshots": "允许截取屏幕截图",
    "Allow commands outside workspace sandbox": "允许在工作区沙箱外执行命令",
    "Allow full browser script execution without prompting.": "允许执行完整的浏览器脚本而无需弹窗提示。",
    "Allow once": "允许一次",
    "Allow options": "允许选项",
    "Allow/deny agent browser actuation access to specific URLs.": "允许/禁止智能体对特定 URL 进行浏览器操作交互。",
    "Allow/deny agent command execution outside the sandbox.": "允许/禁止智能体在沙箱外执行命令。",
    "Allow/deny agent read access to specific URLs or domains.": "允许/禁止智能体对特定 URL 或域名的读取访问。",
    "Allow/deny agent read access to specific files or directories.": "允许/禁止智能体对特定文件或目录的读取权限。",
    "Allow/deny agent write access to specific files or directories.": "允许/禁止智能体对特定文件或目录的写入权限。",
    "Allow/deny specific terminal commands.": "允许/禁止特定的终端命令执行。",
    "Allowed Terminal Commands": "允许的终端命令",
    "Allows the agent to access files outside of your current workspace.": "允许智能体访问您当前工作区以外的文件。",
    "Always Allow": "始终允许",
    "Always Ask": "始终询问",
    "Artifact Review Policy": "产物审查策略",
    "Artifacts are created when the agent performs more complex, longer running tasks while in Planning mode.": "当智能体在规划模式下执行更复杂、耗时较长的任务时，将创建产物文档。",
    "Artifacts are files the agent creates during a conversation to help perform longer running tasks and allow the user to provide high-level feedback. Click to open in editor.": "产物是智能体在会话期间创建的文件，用于协助执行长任务并允许用户提供高层级审查反馈。点击可在编辑器中打开。",
    "Ask Before Proceeding": "继续前始终询问",
    "Ask anything, @ to mention, / for actions": "输入任何问题，输入 @ 提及，输入 / 执行操作",
    "Ask every time": "每次都询问",
    "Ask first": "先询问",
    "Ask for permission for sensitive operations.": "对敏感操作请求授权许可。",
    "Autonomous mode active: the agent works independently, and does not ask questions or request new permissions.": "自主模式已激活：智能体将独立工作，不询问问题也不请求新权限。",
    "Background Task Output": "后台任务输出",
    "Background Tasks": "后台任务",
    "Browser Actuation Permissions": "浏览器交互控制权限",
    "Browser Javascript Execution Policy": "浏览器 JavaScript 执行策略",
    "Choose a predefined security preset for the agent. This controls terminal auto-execution policy, and file access policy.": "为智能体选择预定义的安全预设，用于控制终端自动执行与文件访问策略。",
    "Commands Outside Sandbox": "沙箱外命令执行",
    "Commands the agent can run outside the sandbox in this workspace.": "智能体可在此工作区的沙箱之外运行的命令。",
    "Configure agent execution, queued message delivery, and permissions.": "配置智能体执行策略、排队消息发送规则及权限。",
    "Configure allowed and denied URLs for browser actuation.": "配置允许与禁止进行浏览器操作的 URL 地址。",
    "Configure allowed and denied URLs for reading.": "配置网络请求允许与禁止访问的 URL 地址。",
    "Configure allowed and denied paths for file reads and writes.": "配置文件读写的允许与禁止路径。",
    "Configure allowed commands outside the sandbox.": "配置沙箱外允许执行的命令。",
    "Configure allowed terminal commands.": "配置允许自动执行的终端命令规则。",
    "Configure default behaviors, skills, and MCP servers.": "配置默认行为策略、技能库及 MCP 服务。",
    "Configure global allowed and denied resource permissions.": "配置全局的允许和禁止资源权限。",
    "Configure workspace-specific permissions, resources, and customizations.": "配置工作区专属的权限、资源和自定义设置。",
    "Configures how the agent tries to access files outside of its working folders.": "配置智能体如何尝试访问其工作目录之外的文件。",
    "Confirm the command is safe to run outside of the sandbox with full network and disk access.": "确认该命令可以安全地在沙箱外以完整网络和磁盘权限运行。",
    "Dark preview": "深色预览",
    "Delete MCP Server": "删除 MCP 服务",
    "Delete Task": "删除任务",
    "Deny List Terminal Commands": "终端命令黑名单",
    "Deny Path": "禁止访问路径",
    "Document Access": "文档访问权限",
    "Enable All MCP Tools": "启用所有 MCP 工具",
    "Enable Sandbox Mode (Preview)": "启用沙箱模式（预览）",
    "Enable Terminal Sandbox": "启用终端沙箱",
    "File Access Rules": "文件访问规则",
    "File Permissions": "文件权限",
    "File access": "文件访问",
    "Full access": "完全访问",
    "Grant administrator access for": "授予管理员权限于",
    "Grant permission": "授予权限",
    "In autonomous mode, the agent works with autonomy-enhancing features, and does not ask questions or request new permissions.": "在自主模式下，智能体启用增强自主性功能，不询问问题也不请求新权限。",
    "Installed MCP Servers": "已安装的 MCP 服务",
    "Keep computer awake while tasks are running": "在任务执行期间保持电脑处于唤醒状态",
    "Keep the app accessible from the menu bar and running in the background when all windows are closed.": "在关闭所有窗口后，保持应用在菜单栏/托盘中可访问并在后台继续运行。",
    "Light preview": "浅色预览",
    "Local Permissions": "本地权限",
    "MCP Config": "MCP 配置",
    "MCP Error": "MCP 错误",
    "MCP Server Status": "MCP 服务状态",
    "MCP Servers": "MCP 服务",
    "MCP Tool Call Review": "MCP 工具调用审查",
    "MCP Tool:": "MCP 工具：",
    "MCP Tools": "MCP 工具",
    "Manage project folders, agent settings and permissions": "管理项目文件夹、智能体设置与权限",
    "Manage project folders, agent settings and permissions.": "管理项目文件夹、智能体设置与权限。",
    "Manage project folders, agent settings, and permissions": "管理项目文件夹、智能体设置与权限",
    "Manage project folders, agent settings, and permissions.": "管理项目文件夹、智能体设置与权限。",
    "Model Context Protocol Servers": "模型上下文协议 (MCP) 服务",
    "Modify permissions for file, terminal, and MCP tools": "修改文件、终端及 MCP 工具的访问权限",
    "Modify permissions for file, terminal, and MCP tools.": "修改文件、终端及 MCP 工具的访问权限。",
    "Network Access Rules": "网络访问规则",
    "Network Permissions": "网络权限",
    "No MCP Servers": "暂无 MCP 服务",
    "No MCP servers installed": "未安装 MCP 服务",
    "No background tasks": "暂无后台任务",
    "No tasks running": "暂无运行中的任务",
    "Open MCP Config": "打开 MCP 配置",
    "Open Preview": "打开预览",
    "Open allowlist": "打开白名单",
    "Open in Preview Pane": "在预览面板中打开",
    "Organization Allowed Domains (Read-Only)": "组织允许的域名 (只读)",
    "Outside of folders file access policy": "工作目录外文件访问策略",
    "Permission Preset": "权限预设",
    "Permission Settings": "权限设置",
    "Permissions": "权限",
    "Pick a suggestion below to get started, or ask me anything.": "选择下方的建议开始，或直接向我提问。",
    "Policy": "策略",
    "Preview": "预览",
    "Privacy Policy": "隐私政策",
    "Refresh MCP servers": "刷新 MCP 服务",
    "Request Review": "请求审查",
    "Requires manual review for all terminal commands and file accesses outside of the working folders.": "对所有终端命令和工作目录之外的文件访问均需手动审查。",
    "Restricts agent tools to a secure, isolated local sandbox.": "将智能体工具限制在安全隔离的本地沙箱中。",
    "Review": "审查",
    "Review Policy": "审查策略",
    "Run (unsandboxed)": "运行 (沙箱外)",
    "Sandbox Allow Network": "沙箱允许网络访问",
    "Sandboxed": "沙箱模式",
    "Scheduled Tasks": "定时任务",
    "Security": "安全",
    "Security Preset": "安全预设",
    "Share Conversation (Preview)": "共享会话 (预览版)",
    "Specifies Agent's behavior when asking for review on artifacts, which are documents it creates to enable a richer conversation experience.": "指定智能体在创建产物文档时请求用户审查与反馈的行为策略。",
    "Strict Security": "严格安全",
    "Subagent Tasks": "子智能体任务列表",
    "Tab Gitignore Access": "Tab 访问 Gitignore 文件",
    "Task Breakdown": "任务分解",
    "Task not found": "任务未找到",
    "Terminal & Tooling Permissions": "终端与工具权限",
    "Terminal commands always require review and the agent cannot access files outside of its given workspaces.": "终端命令始终需要审查，且智能体无法访问其指定工作区以外的文件。",
    "The breakdown below shows token usage from customizations like skills, rules, and MCP. If the budget is exceeded, large customizations will be truncated automatically.": "下方的明细展示了来自技能、规则及 MCP 等自定义扩展的 Token 占用情况。如果超出预算，大型自定义扩展将被自动截断。",
    "The browser subagent has been disabled by your administrator.": "浏览器子智能体已被您的管理员禁用。",
    "There may be agents or background tasks running.": "当前可能仍有正在运行中的智能体或后台任务。",
    "This command ran in the sandbox.": "此命令在沙箱中运行。",
    "Tool Permissions": "工具权限",
    "Use Add MCP to browse the store, or add a custom server via the MCP config.": "使用“添加 MCP”浏览应用商店，或通过 MCP 配置文件添加自定义服务。",
    "Vetted (Preview)": "已审查 (预览)",
    "When enabled, sandboxed commands are allowed to make network requests.": "启用后，沙箱命令将被允许发起网络请求。",
    "When enabled, the agent will be able to access past conversations to inform its responses.": "启用后，智能体将能够访问过去的会话来辅助其回复。",
    "Whether the agent asks you to review its documents": "智能体在创建产物文档时是否请求您审查",
    "Whether the agent asks you to review its documents.": "智能体在创建产物文档时是否请求您审查。",
    "Workspace Command Access": "工作区命令访问权限",
    "Workspace File Access": "工作区文件访问权限",
    "Workspace Web Access": "工作区网络访问权限",
    "You currently don't have any MCP Servers installed.": "您当前尚未安装任何 MCP 服务。",
    "You currently don't have any MCP Servers installed. Add an MCP server above or add a custom one via the MCP Config.": "您当前尚未安装任何 MCP 服务。可在上方添加 MCP 服务，或通过 MCP 配置文件添加自定义服务。",
    "to browse the store, or add a custom server via the MCP config": "浏览应用商店，或通过 MCP 配置文件添加自定义服务",
    "to browse the store, or add a custom server via the MCP config.": "浏览应用商店，或通过 MCP 配置文件添加自定义服务。",
    "Configure MCP Server": "配置 MCP 服务",
    "Enter the required configuration values to install this MCP server.": "输入安装此 MCP 服务所需的配置参数。",
    "Could not determine MCP config file path. Please check your home directory settings.": "无法确定 MCP 配置文件路径，请检查您的用户主目录设置。",
    "Could not read MCP config file": "无法读取 MCP 配置文件",
    "Could not determine MCP config file path": "无法确定 MCP 配置文件路径",
    "Failed to load MCP servers": "加载 MCP 服务失败",
    "Failed to fetch available MCP servers:": "获取可用 MCP 服务失败：",
    "Search MCP servers by name": "按名称搜索 MCP 服务",
    "MCP Install Error:": "MCP 安装错误：",
    "Loading MCP servers...": "正在加载 MCP 服务...",
    "Search for MCP servers to add to your configuration": "搜索 MCP 服务以添加到您的配置中",
    "? This will remove it from your MCP configuration.": "？这将从您的 MCP 配置中将其移除。",
    "No method available to open MCP config file": "没有可用于打开 MCP 配置文件的关联程序",
    "Failed to open MCP config file": "打开 MCP 配置文件失败",
    "Your administrator has disabled MCP servers for this workspace.": "您的管理员已禁用此工作区的 MCP 服务。",
    "No MCP servers yet. Use Add to browse the store.": "暂无 MCP 服务。使用“添加”浏览应用商店。",
    "MCP Configuration Error:": "MCP 配置错误：",
    "Unnamed MCP server": "未命名 MCP 服务",
    "Unnamed MCP Server": "未命名 MCP 服务",
    "Install this plugin to see the commands it adds, along with its skills, agents and MCP servers.": "安装此插件以查看其添加的命令，以及其包含的技能、智能体和 MCP 服务。",
    "Error while running MCP tool": "运行 MCP 工具时出错",
    "Used MCP tool": "已使用 MCP 工具",
    "MCP tool": "MCP 工具",
    "Execute an MCP tool call": "执行 MCP 工具调用",
    "Plugins are packaged collections of skills and MCPs to help the Agent": "插件是技能与 MCP 的打包集合，用于辅助智能体",
    "Plugins are packaged collections of skills and MCPs to help the Agent in ": "插件是技能与 MCP 的打包集合，用于在此环境中辅助智能体 ",
    "MCP Servers Disabled": "MCP 服务已禁用",
    "Use Add MCP to browse the store.": "使用“添加 MCP”浏览应用商店。",
    " Organization MCP Allowlist (Read-Only)": " 组织 MCP 允许名单（只读）",
    "These MCP allowlist rules are enforced by your organization": "这些 MCP 允许名单规则由您的组织强制执行",
    "using this MCP tool": "使用此 MCP 工具",
    "Error fetching MCP prompt": "获取 MCP 提示词出错",
    "Inherit Global Permissions": "继承全局权限",
    "Inherit global permissions": "继承全局权限",
    "Global Permissions": "全局权限",
    "Global permissions": "全局权限",
    "Project Permissions": "项目权限",
    "Project permissions": "项目权限",
    "Inherited from Global Permissions": "继承自全局权限",
    "Inherited from global permissions": "继承自全局权限",
    "Override Global Permissions": "覆盖全局权限",
    "Override global permissions": "覆盖全局权限",
    "Project-specific permissions": "项目专属权限",
    "allow": "允许",
    "ask": "询问",
    "deny": "拒绝",
    "Allow": "允许",
    "Ask": "询问",
    "Deny": "拒绝",
    "Proceed in Sandbox": "在沙箱中执行",
    "proceed in sandbox": "在沙箱中执行",
    "Require Review": "需要复核",
    "require review": "需要复核",
    "Vetted": "已审查",
    "Always allow": "始终允许",
    "Always Deny": "始终拒绝",
    "Always deny": "始终拒绝",
    "Always ask": "始终询问",
    "⚠️ Warning: \"Always Proceed\" is enabled without sandbox protection. This is very dangerous and we do not recommend doing this.": "⚠️ 警告：“总是直接继续”在无沙箱保护的情况下已启用。这非常危险，我们不建议这样做。",
    "Warning: \"Always Proceed\" is enabled without sandbox protection. This is very dangerous and we do not recommend doing this.": "警告：“总是直接继续”在无沙箱保护的情况下已启用。这非常危险，我们不建议这样做。",
    "Warning: \"Always Proceed\" is enabled without sandbox protection.": "警告：“总是直接继续”在无沙箱保护的情况下已启用。",
    "⚠️ Warning: \"Always Proceed\" is enabled without sandbox protection.": "⚠️ 警告：“总是直接继续”在无沙箱保护的情况下已启用。",
    "is enabled without sandbox protection.": "在无沙箱保护的情况下已启用。",
    "is enabled without sandbox protection": "在无沙箱保护的情况下已启用",
    "without sandbox protection": "无沙箱保护",
    "without sandbox protection.": "无沙箱保护。",
    "Inherits your Global Permissions": "继承您的全局权限",
    "Inherits your Global Permissions.": "继承您的全局权限。",
    "Inherits your global permissions": "继承您的全局权限",
    "Inherits your global permissions.": "继承您的全局权限。",
    "Inherits your Global Permissions when working in this project": "在此项目中工作时，继承您的全局权限",
    "Inherits your Global Permissions when working in this project.": "在此项目中工作时，继承您的全局权限。",
    "Inherits your global permissions when working in this project": "在此项目中工作时，继承您的全局权限",
    "Inherits your global permissions when working in this project.": "在此项目中工作时，继承您的全局权限。",
    "Also includes Global Permissions": "也包含全局权限",
    "Also includes Global Permissions.": "也包含全局权限。",
    "Also includes global permissions": "也包含全局权限",
    "Also includes global permissions.": "也包含全局权限。",
    "Also includes Global Permissions when working in this project": "在此项目中工作时也包含全局权限",
    "Also includes Global Permissions when working in this project.": "在此项目中工作时也包含全局权限。",
    "Also includes global permissions when working in this project": "在此项目中工作时也包含全局权限",
    "Also includes global permissions when working in this project.": "在此项目中工作时也包含全局权限。",
    "Also includes Global Permissions when working in this project. Learn more.": "在此项目中工作时也包含全局权限。了解更多。",
    "Search tasks...": "搜索任务...",
    "Search tasks": "搜索任务",
    "No scheduled tasks configured.": "尚未配置任何定时任务。",
    "No scheduled tasks configured": "尚未配置任何定时任务",
    "No scheduled tasks.": "暂无定时任务。",
    "No scheduled tasks": "暂无定时任务",
    "New Scheduled Task": "新建定时任务",
    "Edit Scheduled Task": "编辑定时任务",
    "Delete Scheduled Task": "删除定时任务",
    "Scheduled Task": "定时任务",
    "Enter scheduled task name...": "输入定时任务名称...",
    "Enter scheduled task name": "输入定时任务名称",
    "All scheduled tasks run as Flash.": "所有定时任务均以 Flash 模型运行。",
    "All scheduled tasks run as Flash": "所有定时任务均以 Flash 模型运行",
    "scheduled tasks run as Flash.": "定时任务均以 Flash 模型运行。",
    "scheduled tasks run as Flash": "定时任务均以 Flash 模型运行",
    "Add Scheduled Task": "添加定时任务",
    "Save Scheduled Task": "保存定时任务",
    "Run task now": "立即运行任务",
    "Pause Task": "暂停任务",
    "Resume Task": "恢复任务",
    "In review": "审查中",
    "Manage Permissions": "管理权限",
    "Open in Preview Tab": "在预览标签页中打开",
    "Execute JavaScript Policy": "执行 JavaScript 策略",
    "scheduled task": "定时任务",
    "scheduled tasks": "定时任务",
    "The agent never asks for confirmation before executing terminal commands (except those in the Deny list). This provides the agent with the maximum ability to operate over long periods without intervention, but also has the highest risk of the agent executing an unsafe terminal command.": "智能体在执行终端命令前从不请求确认（“拒绝列表”中的命令除外）。这为智能体提供了在无需人工干预的情况下长时间运行的最大能力，但智能体执行不安全终端命令的风险也最高。",
    "The agent always asks for confirmation before executing terminal commands (except those in the Allow list).": "智能体在执行终端命令前始终请求确认（“允许列表”中的命令除外）。",
    "Terminal command automatically proceeds if the command runs inside the sandbox. Otherwise, it requests review.": "如果终端命令在沙箱内运行，则自动继续执行；否则，请求人工复核。",
    "The agent never asks for review. This maximizes the autonomy of the agent, but also has the highest risk of the agent operating over unsafe or injected artifact content.": "智能体从不请求审查。这最大化了智能体的自主性，但智能体处理不安全或被注入产物内容的风险也最高。",
    "The agent always asks for review.": "智能体始终请求审查。",
    "The agent always asks for review": "智能体始终请求审查",
    "Allow full browser script execution.": "允许执行完整的浏览器脚本。",
    "Allow full browser script execution": "允许执行完整的浏览器脚本",
    "Enforce settings that prevent the agent from autonomously running targeted exploits and require human review for all agent actions. Visit antigravity.google/docs/strict-mode for details.": "强制执行安全设置，防止智能体自主运行针对性攻击，并要求对所有智能体操作进行人工审查。详情请访问 antigravity.google/docs/strict-mode。",
    "Plan Review Policy": "计划审查策略",
    "Useful for typical development with an emphasis on security. It prioritizes safety over speed by requiring manual approval for all terminal commands and files outside the project directory.": "适用于注重安全性的常规开发场景。优先保障安全，所有终端命令以及项目目录外的文件访问均需手动审批。",
    "Useful for tasks that require file access across your full machine. The agent has full read and write access to all local files, but all proposed terminal commands require manual review and approval before running.": "适用于需要跨整机访问文件的任务。智能体拥有所有本地文件的完整读写权限，但所有终端命令在运行前仍需手动审查与批准。",
    "Allow the agent to automatically view and edit files outside the current workspace. Use with caution: this gives the agent access to additional potentially-relevant information, but also allows the agent to access credential files, secrets, and other files outside of the workspace that could be targeted in prompt injection attacks or other exploits by malicious actors.": "允许智能体自动查看和编辑当前工作区以外的文件。请谨慎使用：这会让智能体访问更多潜在相关信息，但同时也允许其访问工作区外的凭据、密钥及其他敏感文件。",
    "Allow Tab to view and edit the files in .gitignore. Use with caution if your .gitignore lists files containing credentials, secrets, or other sensitive information.": "允许 Tab 查看和编辑 .gitignore 中列出的文件。如果您的 .gitignore 包含凭据、密钥或其他敏感信息文件，请谨慎开启。",
    "Run terminal commands with sandbox restrictions.": "在沙箱限制下运行终端命令。",
    "These allowed domain rules are set by your organization's administrator and cannot be removed.": "这些允许的域名规则由您所在组织的管理员设置，无法移除。",
    "Allowed Domains": "允许的域名",
    "Denied Sites": "已拒绝的站点",
    "The agent was prevented from accessing some sites": "智能体已被阻止访问部分站点",
    "Site Allowlist": "站点白名单",
    "The Agent attempted to interact with some sites that are not allowlisted": "智能体尝试与部分未列入白名单的站点进行交互",
    "Add them to allow future interactions": "将它们加入白名单以允许后续交互",
    "Added to allowlist": "已添加到白名单",
    "Allow in Conversation": "在当前会话中允许",
    "Edit permission target": "编辑权限目标",
    "Yes, allow": "是，允许",
    "GitHub Personal Access Token": "GitHub 个人访问令牌 (PAT)",
    "Validated with GitHub and stored, together with your username, in": "已通过 GitHub 验证，并与您的用户名一起安全存储在",
    ". It is not visible in the agent's sandbox and is shared across all your projects.": "中。它在智能体沙箱内不可见，并在您的所有项目间共享。",
    "Create a token": "创建令牌",
    "Hide token": "隐藏令牌",
    "Show token": "显示令牌",
    "Agent can": "智能体可以",
    "Remove policy": "移除策略",
    "Agent can run": "智能体可运行",
    "Workflow files": "工作流文件",
    "at ref": "于分支/引用 (ref)",
    "Workflow refs": "工作流引用 (refs)",
    "Repositories": "代码仓库",
    "Delete repository policy": "删除仓库策略",
    "Contents": "仓库内容",
    "Read access to code, refs, commits, and other repository contents.": "对代码、分支引用、提交记录及其他仓库内容的读取权限。",
    "Read access": "读取权限",
    "Toggle this on to enable read access on contents.": "开启后允许读取仓库内容。",
    "Issues": "议题 (Issues)",
    "Allow creating issues and grant access to specific issues.": "允许创建 Issue 并授予对特定 Issue 的访问权限。",
    "Issue creation": "创建 Issue",
    "Toggle this on to allow creating new issues.": "开启后允许创建新的 Issue。",
    "Access rules": "访问规则",
    "Issue numbers": "Issue 编号",
    "Issue actions": "Issue 操作权限",
    "+ Add issue policy": "+ 添加 Issue 策略",
    "Pull requests": "拉取请求 (PR)",
    "Allow opening pull requests and grant access to specific PRs.": "允许发起拉取请求 (PR) 并授予对特定 PR 的访问权限。",
    "Pull request creation": "创建拉取请求",
    "Toggle this on to allow creating new pull requests.": "开启后允许创建新的拉取请求 (PR)。",
    "Pull request numbers": "PR 编号",
    "Pull request actions": "PR 操作权限",
    "+ Add pull request policy": "+ 添加拉取请求策略",
    "Remote branches": "远程分支",
    "Grant create, update, or delete access to specific branches.": "授予对特定分支的创建、更新或删除权限。",
    "Branch names": "分支名称",
    "Branch actions": "分支操作权限",
    "+ Add branch policy": "+ 添加分支策略",
    "Workflow runs": "工作流运行 (Workflow Runs)",
    "Grant read access to workflow runs and allow dispatching workflows on specific files and refs.": "授予对工作流运行记录的读取权限，并允许在特定文件和分支引用上触发工作流。",
    "Run visibility": "运行记录可见性",
    "+ Add workflow run policy": "+ 添加工作流运行策略",
    "Organizations": "组织机构 (Organizations)",
    "Delete organization policy": "删除组织策略",
    "+ Add Repository policy": "+ 添加代码仓库策略",
    "GitHub Policies": "GitHub 访问策略",
    "Enable fine-grained GitHub permissions and define the org, repository, and resource-level access the agent is allowed to use.": "启用细粒度 GitHub 权限，并定义允许智能体使用的组织、仓库及资源级访问权限。",
    "+ Add Organization policy": "+ 添加组织策略",
    "GitHub Permissions": "GitHub 权限",
    "Manage fine-grained permissions for GitHub.": "管理 GitHub 的细粒度访问权限。",
    "Allow Gemini to notify you when the agent needs your attention or completes a task.": "允许 Gemini 在智能体需要您关注或完成任务时发送系统通知。",
    "Allow Gemini to notify you when the agent needs your attention or completes a task": "允许 Gemini 在智能体需要您关注或完成任务时发送系统通知",
    "Choose whether to be notified when the agent needs your attention or completes a task.": "选择是否在智能体需要您关注或完成任务时接收通知。",
    "Choose whether to be notified when the agent needs your attention or completes a task": "选择是否在智能体需要您关注或完成任务时接收通知",
    "This project overrides your global permission settings.": "此项目已覆盖您的全局权限设置。",
    "This workspace overrides your global permission settings.": "此工作区已覆盖您的全局权限设置。",
    "Failed to save project settings: ": "保存项目设置失败：",
    "Failed to save settings: ": "保存设置失败：",
    "Permission Details": "权限详情",
    "A comma-separated list like repo-a, repo-b, or * for all.": "以逗号分隔的列表（如 repo-a, repo-b），或填 * 代表全部。",
    "Grant the selected actions on the listed issue numbers — a comma-separated list like 1, 2, 3, or * for all.": "对列出的议题 (Issue) 编号授予所选操作权限——以逗号分隔的列表（如 1, 2, 3），或填 * 代表全部。",
    "Grant the selected actions on the listed pull request numbers — a comma-separated list like 1, 2, 3, or * for all.": "对列出的拉取请求 (PR) 编号授予所选操作权限——以逗号分隔的列表（如 1, 2, 3），或填 * 代表全部。",
    "Grant the selected actions on the listed branch names — a comma-separated list like main, dev, prod (glob patterns like fix-* allowed), or * for all.": "对列出的分支名称授予所选操作权限——以逗号分隔的列表（如 main, dev, prod，支持 fix-* 等通配符），或填 * 代表全部。",
    "Allow reading workflow runs (list, view, watch) across the whole repository.": "允许在整个代码仓库范围内读取工作流运行记录（列出、查看、监控）。",
    "Each rule lets the agent run the listed workflow files on the listed refs — each a comma-separated list like ci.yml, deploy.yml and main, dev (glob patterns like fix-* allowed), or * for all. Both fields must be set for a rule to grant anything.": "每条规则允许智能体在指定的分支引用上运行指定的工作流文件——均使用逗号分隔列表，如 ci.yml, deploy.yml 与 main, dev（支持 fix-* 等通配符），或填 * 代表全部。两个字段必须同时填写方能生效。",
    "A comma-separated list like org-a, org-b, or * for all.": "以逗号分隔的列表（如 org-a, org-b），或填 * 代表全部。",
    "Agent permissions preset selector, current: Request Review": "智能体权限预设选择器，当前：请求审查",
    "Agent permissions preset selector, current: Default": "智能体权限预设选择器，当前：默认",
    "Agent permissions preset selector, current: Turbo": "智能体权限预设选择器，当前：极速",
    "Agent permissions preset selector, current: Autonomous": "智能体权限预设选择器，当前：自主模式",
    ". Learn more about skills at": "。了解更多关于技能的信息，请访问",
    "**STOP AND VERIFY**: Before running any command or tool that results in irreversible data loss, you MUST obtain explicit user consent. When in doubt, ask. It is better to wait for confirmation than to accidentally delete production data or critical project assets. Use this for: - SQL: DROP TABLE/VIEW/SCHEMA/DATABASE, TRUNCATE, or broad DELETE (missing WHERE or using 1=1). - Cloud Storage: gsutil rm or gcloud storage rm targeting production data or critical buckets. - Infrastructure: gcloud projects delete, deleting Spanner/BigQuery/Dataproc resources, deleting secrets, or KMS key destruction.": "【停止并核实】：在运行任何会导致不可逆数据丢失的命令或工具前，必须获得用户的明确同意。如有疑问请先询问，涵盖 SQL（DROP/TRUNCATE/无条件 DELETE）、Cloud Storage 生产数据删除以及 GCP 项目、Spanner、BigQuery、Dataproc 资源或密钥销毁操作。",
    "A collection of skills for architecting and implementing production-ready code using Google Maps Platform APIs and SDKs for any map, place, address, geocoding, routing/ETA (including eco-friendly routing), nearby search, 3D / Street View / static map, marker clustering, custom styling, drawing, geofencing, heatmap, or environmental (air-quality / pollen / solar / weather) feature — across Web, Android, iOS, and Web Services APIs. For prototyping, use the public Maps Demo Key — no billing setup and no Cloud project required, covering a growing set of the most popular Google Maps Platform APIs. For production, the skill prompts you to create and restrict your own key. All non-trivial code is grounded in freshly retrieved docs via the Google Maps Platform Code Assist service (no reliance on training-data memory).": "使用 Google Maps Platform API 与 SDK 构建生产级位置感知代码的技能集合，涵盖地图、地点、地址解析、路线规划/ETA、周边搜索、3D/街景/静态地图、聚合标记、自定义样式、地理围栏、热力图及环境数据（空气质量/花粉/日照/天气），支持使用公开演示密钥快速构建原型。",
    "A Gemini-powered security agent decides if commands should be auto-approved.": "由 Gemini 驱动的安全智能体决定是否自动批准命令。",
    "Access protein metadata, function, taxonomy, and sequences across UniProtKB, UniParc, and UniRef. Use when searching for proteins, mapping identifiers, or retrieving functional annotations and publications. Don't use for sequence alignment, protein folding, or sequence similarity search (use specialized skills for those tasks).": "访问跨 UniProtKB、UniParc 和 UniRef 的蛋白质元数据、功能、分类学信息与序列。适用于搜索蛋白质、映射标识符或检索功能注释与相关文献。",
    "Active Skills": "已启用技能",
    "Add `flutter_localizations` and `intl` dependencies, enable \"generate true\" in `pubspec.yaml`, and create an `l10n.yaml` configuration file. Use when initializing localization support for a new Flutter project.": "添加 `flutter_localizations` 与 `intl` 依赖项，在 `pubspec.yaml` 中启用 `generate: true` 并创建 `l10n.yaml` 配置文件。适用于为新 Flutter 项目初始化多语言本地化支持。",
    "Add flutter_localizations and intl dependencies, enable \"generate true\" in pubspec.yaml, and create an l10n.yaml configuration file. Use when initializing localization support for a new Flutter project.": "添加 flutter_localizations 与 intl 依赖项，在 pubspec.yaml 中启用 generate: true 并创建 l10n.yaml 配置文件。适用于为新 Flutter 项目初始化多语言本地化支持。",
    "Add Handler": "添加处理器",
    "Add New Handler to": "添加新处理器至",
    "Adds interactive widget previews to the project using the previews.dart system. Use when creating new UI components or updating existing screens to ensure consistent design and interactive testing.": "使用 previews.dart 系统向项目添加交互式组件预览 (Widget Previews)。适用于创建新 UI 组件或更新现有页面，以确保设计一致性与交互式测试。",
    "Advanced Command Access": "高级命令访问权限",
    "Advanced Web Access": "高级网页访问权限",
    "Agent data is not available": "智能体数据不可用",
    "Agent Market Search Results": "智能体市场搜索结果",
    "Agent settings and permissions can be further customized below.": "智能体设置与权限可在下方进一步自定义。",
    "AI coding agents are known to have certain security limitations. Users should be aware of potential risks, including data exfiltration and possible code execution. Avoid processing highly sensitive data and verify all the actions taken by the agent.": "AI 编码智能体已知存在一定的安全局限性。用户应注意潜在风险，包括数据外泄和潜在的代码执行。请避免处理高度敏感的数据，并核实智能体执行的所有操作。",
    "AI coding agents are known to have certain security risks, including autonomous code execution, data exfiltration, prompt injection and supply chain risks. Ensure that you monitor and verify all actions taken by the agent.": "AI 编码智能体已知存在一定的安全风险，包括自主代码执行、数据外泄、提示词注入以及供应链风险。请确保监控并核实智能体执行的所有操作。",
    "Allow the agent to run without restrictions.": "允许智能体无限制运行。",
    "Analyzes genetic variant effects on gene expression (RNA-seq), chromatin accessibility (DNASE), histone marks (ChIP), and transcription factors using the AlphaGenome API. Use when the user asks about non-coding variant effects, pathogenicity, clinical significance, disease associations, functional effects, gene expression changes, splicing disruption, or regulatory effects in promoters and enhancers. Also use for resolving biological terms to tissue/cell-type ontologies (UBERON/CL) or analyzing variants in chr:pos:ref>alt format.": "使用 AlphaGenome API 分析遗传变异对基因表达 (RNA-seq)、染色质可及性 (DNASE)、组蛋白修饰 (ChIP) 和转录因子的影响。适用于分析非编码区变异效应、致病性、剪接破坏及启动子/增强子调控效应。",
    "Ancient text restoration, attribution, dating, contextualization, and embedding via Aeneas (Latin) / Ithaca (Ancient Greek). Use when asked to \"restore\", \"attribute\", \"date\", \"contextualize\", \"find parallels\", \"where was it written\", \"when was it written\", \"embed\", or \"analyze\" an ancient text, inscription, or epigraphic document, or when the user mentions \"Aeneas\", or \"Ithaca\".": "通过 Aeneas（拉丁语）/ Ithaca（古希腊语）对古代文献、铭文或碑刻进行文本复原、归属判定、年代测定、语境化分析与向量嵌入。",
    "Antigravity does not collect any of your prompts, content, or model responses but does collect general usage patterns such as feature adoption and active user counts (“product analytics”). Telemetry data will be handled in accordance with the Google Privacy Policy.": "Antigravity 不会收集您的任何提示词、内容或模型回复，但会收集功能采用率和活跃用户数等常规使用模式（“产品分析”）。遥测数据将依据《Google 隐私权政策》进行处理。",
    "Architects a Flutter application using the recommended layered approach (UI, Logic, Data). Use when structuring a new project or refactoring for scalability.": "采用推荐的分层架构（UI 层、逻辑层、数据层）设计 Flutter 应用。适用于搭建新项目结构或针对可扩展性进行架构重构。",
    "Assesses the security posture of Google Cloud Storage (GCS) buckets and projects. Grounds every finding in gathered telemetry, evaluates buckets against Google security best practices (public access, IAM over-granting, CMEK, VPC Service Controls, audit logging), and correlates signals to flag toxic combinations of individually low-risk settings, with actionable remediation. Use whenever a user asks for a security scan, audit, review, vulnerability check, or compliance assessment (including SAIF) — or simply asks whether their buckets, project, or data are secure, exposed, public, or misconfigured, who can access their data, or wants storage hardened or locked down, e.g. before a launch. Don't use for diagnosing a specific access failure or 403, managing or configuring storage, investigating a live outage, or non-GCS resources (Compute Engine, GKE, etc.).": "评估 Google Cloud Storage (GCS) 存储桶与项目的安全态势。基于采集的遥测数据对照 Google 安全最佳实践（公共访问、IAM 过度授权、CMEK、VPC Service Controls、审计日志）进行评估，并提供可执行的修复方案。",
    "Assists in provisioning instances/tables, designing performant schemas, and querying data in Bigtable. Use when designing Bigtable row keys, configuring column families, writing SQL queries or client library code (Java, Go, Python) for Bigtable, or diagnosing performance/hotspotting issues. Also use when provisioning Bigtable clusters using gcloud or cbt CLIs. Don't use for generic Cloud SQL administration.": "协助在 Bigtable 中配置实例与表、设计高性能模式 (Schema) 并查询数据。适用于设计 Bigtable 行键、配置列族、编写 SQL 或客户端代码（Java、Go、Python）以及诊断性能热点问题。",
    "Audits Firebase (Firestore, Cloud Storage) security rules for vulnerabilities, privilege escalation, role bypasses, create vs update inconsistencies, resource exhaustion, type safety, size limits, and hasOnly ownership checks. Use when auditing/reviewing rules, running red-team rule assessments, or scoring against auditor checklists. Don't use for Firebase CLI (login, deploy), Auth, Crashlytics, Remote Config, or database queries.": "审计 Firebase（Firestore、Cloud Storage）安全规则中的漏洞、权限提升、角色绕过、创建与更新不一致、资源耗尽、类型安全、大小限制及所有权检查问题。",
    "Auto (Preview)": "自动 (预览版)",
    "Automated data quality and transformation capabilities for Dataform/dbt/BigQuery pipelines. Processes data sourced from BigQuery or Cloud Storage (GCS), applying best practices for data ingestion, movement, schema mapping, and comprehensive data cleaning.": "面向 Dataform/dbt/BigQuery 流水线的自动化数据质量检查与转换能力。支持处理来自 BigQuery 或 Cloud Storage (GCS) 的数据，应用数据摄取、迁移、模式映射与全面数据清洗的最佳实践。",
    "Automates declarative resource creation and provisioning for data pipelines, supporting BigQuery, Dataform, Dataproc, BigQuery Data Transfer Service (DTS), and other resources. It manages environment-specific configurations (dev, staging, prod) through a deployment.yaml file. Use when: - Modifying or creating deployment.yaml for deployment settings. - Resolving environment-specific variables (e.g., Project IDs, Regions) for deployment. - Provisioning supported infrastructure like BigQuery datasets/tables, Dataform resources, or DTS resources via deployment.yaml. Do not use when: - Resources already exist. - Managing resources not supported by `gcloud beta orchestration-pipelines resource-types list`. - Managing general cloud infrastructure (VMs, networks, Kubernetes, IAM policies), which are better suited for Terraform. - Infrastructure spans multiple cloud providers (AWS, Azure, etc.). - Already uses Terraform for the target resources.": "通过 deployment.yaml 文件自动化数据流水线的声明式资源创建与配置（支持 BigQuery、Dataform、Dataproc、BigQuery DTS 等），并管理开发、预发和生产等多环境专属配置。",
    "Automates declarative resource creation and provisioning for data pipelines, supporting BigQuery, Dataform, Dataproc, BigQuery Data Transfer Service (DTS), and other resources. It manages environment-specific configurations (dev, staging, prod) through a deployment.yaml file. Use when: - Modifying or creating deployment.yaml for deployment settings. - Resolving environment-specific variables (e.g., Project IDs, Regions) for deployment. - Provisioning supported infrastructure like BigQuery datasets/tables, Dataform resources, or DTS resources via deployment.yaml. Do not use when: - Resources already exist. - Managing resources not supported by gcloud beta orchestration-pipelines resource-types list. - Managing general cloud infrastructure (VMs, networks, Kubernetes, IAM policies), which are better suited for Terraform. - Infrastructure spans multiple cloud providers (AWS, Azure, etc.). - Already uses Terraform for the target resources.": "通过 deployment.yaml 文件自动化数据流水线的声明式资源创建与配置（支持 BigQuery、Dataform、Dataproc、BigQuery DTS 等），并管理开发、预发和生产等多环境专属配置。",
    "Automatically decide whether the command should run.": "自动决定是否允许运行该命令。",
    "Automatically migrate legacy workflows to modern skills across global and workspace configurations. Scans for existing workflows, creates target SKILL.md files, and safely archives old workflow files.": "在全局和工作区配置中自动将旧版工作流 (Workflows) 迁移为现代技能 (Skills)。自动扫描现有工作流、创建目标 SKILL.md 文件并安全归档旧工作流文件。",
    "automation. Automations do not inherit Global Permissions.": "自动化任务。自动化任务不会继承全局权限。",
    "Automations do not inherit Global Permissions": "自动化任务不会继承全局权限",
    "Automations do not inherit Global Permissions.": "自动化任务不会继承全局权限。",
    "Blocked by organization policy": "已被组织策略拦截",
    "Browse, filter, and download life sciences, biology, and medical preprints from bioRxiv and medRxiv. Supports fetching paper metadata by DOI, and browsing by date range with category and keyword filters. Keyword filtering is local, so date ranges MUST be narrow (1-4 weeks) with a category to prevent timeouts.": "浏览、筛选和下载来自 bioRxiv 与 medRxiv 的生命科学、生物学和医学预印本论文。支持按 DOI 获取论文元数据，或按窄日期范围（1~4 周）结合学科分类与关键词筛选检索。",
    "Build and prototype location-aware applications with Google Maps Platform": "使用 Google Maps Platform 构建和设计位置感知型应用原型",
    "Build and prototype location-aware applications with Google Maps Platform.": "使用 Google Maps Platform 构建和设计位置感知型应用原型。",
    "Build and prototype location-aware applications with Google Maps Platform. Integrate interactive maps, search and inspect Places details, calculate optimal routes": "使用 Google Maps Platform 构建和设计位置感知型应用原型。集成交互式地图、搜索与查看地点详情，并计算最佳路线",
    "Build and prototype location-aware applications with Google Maps Platform. Integrate interactive maps, search and inspect Places details, calculate optimal routes.": "使用 Google Maps Platform 构建和设计位置感知型应用原型。集成交互式地图、搜索与查看地点详情，并计算最佳路线。",
    "Build and publish Chrome Extensions using Manifest V3 best practices. Use this skill whenever the user asks to create, modify, debug, or understand Chrome browser extensions, add-ons, or anything involving the Chrome Extensions API. Trigger on mentions of: 'Chrome extension', 'browser extension', 'manifest.json', 'content script', 'service worker' (in browser context), 'popup' (in browser extension context), 'side panel', 'chrome.* API', 'declarativeNetRequest', 'omnibox', 'context menu' (in extension context), 'userScripts', 'user script', 'script manager', or any request to build functionality that integrates with the Chrome browser UI. Also trigger for publishing to the Chrome Web Store: 'publish extension', preparing an extension for publishing, responding to a review rejection, writing permission justifications, or drafting a privacy policy.": "基于 Manifest V3 最佳实践构建并发布 Chrome 浏览器扩展程序。当用户需要创建、修改、调试或了解 Chrome 扩展、插件、manifest.json、content script、service worker、side panel、chrome.* API 或发布至 Chrome 应用商店时触发此技能。",
    "Build applications with the Gemini Interactions API and Live API, including text generation, multi-turn chat, streaming, function calling, managed agents, and real-time audio/video": "使用 Gemini Interactions API 和 Live API 构建应用，包括文本生成、多轮对话、流式传输、函数调用、托管智能体以及实时音视频",
    "Build applications with the Gemini Interactions API and Live API, including text generation, multi-turn chat, streaming, function calling, managed agents, and real-time audio/video.": "使用 Gemini Interactions API 和 Live API 构建应用，涵盖文本生成、多轮对话、流式传输、函数调用、托管智能体以及实时音视频。",
    "Build modern data apps, dashboards, and interactive reports using either React + Vite or Streamlit. Includes optional Gemini Data Analytics chat integration for an AI powered \"chat with your data\" experience. Relevant when any of the following conditions are true: 1. User explicitly requests to build a data dashboard, data application, or visualization UI, and the UI pulls data from a GCP database (defaulting to BigQuery unless otherwise specified). 2. You need to generate a frontend web application to interact with, query, and visualize data from GCP data sources. 3. User wants to build a \"chat with your data\" experience or integrate the Gemini Data Analytics chat API into a web interface. Do NOT use when any of the following conditions are true: 1. The request is for building backend-only services. 2. The request is for simple CLI scripts or command-line applications. 3. The web application is not data-centric or does not involve visualizing/querying data from GCP sources.": "使用 React + Vite 或 Streamlit 构建现代数据应用、仪表盘和交互式报表，并支持集成可选的 Gemini 数据分析对话功能，实现“与数据对话”的 AI 体验。",
    "Build with Antigravity Plugins": "Build with Antigravity 插件目录",
    "Build with Google": "使用 Google 构建",
    "Build with Google Plugins": "Build with Google 插件目录",
    "Build, package, run, and debug UI extensions for Antigravity: interactive web panels that render in the side pane, served by a Node.js sidecar using the built-in Sidecar SDK": "构建、打包、运行与调试 Antigravity 的 UI 扩展：在侧边栏面板中渲染交互式 Web 面板，由使用内置 Sidecar SDK 的 Node.js sidecar 提供服务",
    "Build, package, run, and debug UI extensions for Antigravity: interactive web panels that render in the side pane, served by a Node.js sidecar using the built-in Sidecar SDK.": "构建、打包、运行与调试 Antigravity 的 UI 扩展：在侧边栏面板中渲染交互式 Web 面板，由使用内置 Sidecar SDK 的 Node.js sidecar 提供服务。",
    "Building UI Extensions": "构建 UI 扩展",
    "Builds and deploys Firebase SQL Connect (aka Firebase Data Connect) backends with PostgreSQL securely. Use when designing schemas with tables and relations, writing authorized queries and mutations, configuring real-time data updates, or generating type-safe SDKs. Use when you need a relational database with Firebase, or when the user mentions SQL Connect or Data Connect.": "安全地构建和部署基于 PostgreSQL 的 Firebase SQL Connect（即 Firebase Data Connect）后端。适用于设计表与关系模式、编写授权查询与变更、配置实时数据更新或生成类型安全的 SDK。",
    "Bundles will let you download a whole group of user-defined plugins at once, instead of installing them one at a time. They are not here yet.": "组合包功能将支持一次性下载整组自定义插件，而无需逐个安装。该功能即将上线，敬请期待。",
    "Checks whether the uv Python package manager is installed and installs it if missing. Ensures uv is on PATH. Use when another skill requires uv as a prerequisite.": "检查 uv Python 包管理器是否已安装，若缺失则自动安装并确保其位于 PATH 环境变量中。当其他技能需要 uv 作为前置条件时使用。",
    "Click to disable tool": "点击禁用工具",
    "Click to enable tool": "点击启用工具",
    "Collect coverage using the coverage packge and create an LCOV report": "使用 coverage 包收集测试覆盖率数据并生成 LCOV 覆盖率报告。",
    "Command is required": "命令为必填项",
    "Commands the agent can run outside the sandbox.": "智能体可在沙箱外运行的命令。",
    "Comprehensive guide and reference for the Antigravity Customization System. Use to explain how customizations work, their loading priority, discovery mechanisms, and to guide the creation of skills, rules, plugins, hooks, and MCP servers.": "Antigravity 自定义扩展系统的全面指南与参考手册。用于解释自定义扩展的工作原理、加载优先级与发现机制，并指导创建技能 (Skills)、规则 (Rules)、插件 (Plugins)、钩子 (Hooks) 与 MCP 服务。",
    "Comprehensive guide for Firebase Crashlytics, including provisioning and SDK usage. Use this skill when the user needs help setting up Crashlytics, adding crash reporting, or using the Crashlytics SDK in their application.": "Firebase Crashlytics 全面指南，包含服务配置与 SDK 使用说明。当用户需要配置 Crashlytics、添加崩溃报告或在应用中使用 Crashlytics SDK 时使用此技能。",
    "Configure `MaterialApp.router` using a package like `go_router` for advanced URL-based navigation. Use when developing web applications or mobile apps that require specific deep linking and browser history support.": "使用 `go_router` 等路由包配置 `MaterialApp.router` 以实现高级 URL 导航。适用于开发需要深度链接 (Deep Linking) 与浏览器历史记录支持的 Web 或移动应用。",
    "Configure GitHub access policies.": "配置 GitHub 访问策略。",
    "Configure hooks that run on agent lifecycle events.": "配置在智能体生命周期事件触发时运行的钩子 (Hooks)。",
    "Configure MaterialApp.router using a package like go_router for advanced URL-based navigation. Use when developing web applications or mobile apps that require specific deep linking and browser history support.": "使用 go_router 等路由包配置 MaterialApp.router 以实现高级 URL 导航。适用于开发需要深度链接 (Deep Linking) 与浏览器历史记录支持的 Web 或移动应用。",
    "Configured servers": "已配置的服务器",
    "Configures Flutter Driver for app interaction and converts MCP actions into permanent integration tests. Use when adding integration testing to a project, exploring UI components via MCP, or automating user flows with the integration_test package.": "配置 Flutter Driver 进行应用交互，并将 MCP 操作转换为持久化的集成测试。适用于为项目添加集成测试、通过 MCP 探索 UI 组件或使用 integration_test 包自动化用户流程。",
    "Connecting to language server...": "正在连接语言服务器...",
    "Constructs deep-links and URLs for the AlphaGenome Atlas website. Supports generating single-variant exploration links (1-based chr:pos:ref>alt), genomic locus views (1-based closed chr:start-end), candidate summary tables, and AlphaGenome reference vs. alternate predictions. Use whenever visualizing, exploring, charting, or linking genetic variants and genomic loci on the AlphaGenome Atlas, or when asked to inspect, view, or link predictions for a genomic variant.": "构建 AlphaGenome Atlas 网站的深度链接与 URL。支持生成单变异位点探索链接、基因组位点视图、候选汇总表以及参考与变异预测对比链接。",
    "Contact your administrator to enable browser use": "请联系您的管理员以启用浏览器功能",
    "Contact your administrator to enable browser use.": "请联系您的管理员以启用浏览器功能。",
    "Copied to clipboard": "已复制到剪贴板",
    "Copy command": "复制命令",
    "Core tools and knowledge required to develop for Android.": "开发 Android 应用所需的核心工具与知识。",
    "Could not determine agent config file path": "无法确定智能体配置文件路径",
    "Could not determine plugin config file path": "无法确定插件配置文件路径",
    "Create model classes with `fromJson` and `toJson` methods using `dart:convert`. Use when manually mapping JSON keys to class properties for simple data structures.": "使用 `dart:convert` 创建包含 `fromJson` 和 `toJson` 方法的模型类。适用于针对简单数据结构手动将 JSON 键映射到类属性。",
    "Create model classes with fromJson and toJson methods using dart:convert. Use when manually mapping JSON keys to class properties for simple data structures.": "使用 dart:convert 创建包含 fromJson 和 toJson 方法的模型类。适用于针对简单数据结构手动将 JSON 键映射到类属性。",
    "Create plugin": "创建插件",
    "Creates Cloud Storage (Google Cloud Storage, or GCS) buckets. Analyzes the workload (sensitive data, media hosting, ingestion, web hosting, archiving, backup, logging, analytics, AI/ML, or general-purpose), validates project-level security settings, and designs a secure-by-default, cost-effective configuration (location, storage class, uniform bucket-level access, public access prevention, soft delete, lifecycle) before creating it. Use whenever a user wants to create, make, set up, provision, or spin up a bucket, or needs object storage for an app, service, pipeline, or dataset — even a \"simple\" or \"default\" bucket, or when bucket creation is one step in a larger workflow. Outputs or executes the creation via gcloud, the JSON/REST API, Terraform, or SDK client libraries (C++, Java, Python, Go). Don't use for anything other than creating new buckets — for uploads, downloads, access changes, or reconfiguring existing buckets, use google-cloud-storage-basics.": "创建 Google Cloud Storage (GCS) 存储桶。在创建前分析工作负载类型、验证项目级安全设置，并设计默认安全且高性价比的配置方案（区域、存储类别、统一存储桶级访问、防公共访问、软删除与生命周期）。",
    "CRITICAL RULE: You MUST use this skill whenever the task involves any machine learning tasks or data analysis. Use this skill if the user's prompt or requirements mention any of the following: * Clustering * Classification * Regression * Time series forecasting * Statistical testing * Model comparison * ML * Data analysis SQL/BigQuery ML HANDOFF: If the user requires a SQL solution, use this skill to dictate the ANALYSIS STEPS (e.g., markdown analysis cells, visualization logic), but defer to `bigquery` for all SQL syntax.": "【核心规则】：当任务涉及任何机器学习或数据分析（包括聚类、分类、回归、时间序列预测、统计检验、模型对比、ML 或数据分析）时，必须使用此技能。",
    "CRITICAL RULE: You MUST use this skill whenever the task involves any machine learning tasks or data analysis. Use this skill if the user's prompt or requirements mention any of the following: * Clustering * Classification * Regression * Time series forecasting * Statistical testing * Model comparison * ML * Data analysis SQL/BigQuery ML HANDOFF: If the user requires a SQL solution, use this skill to dictate the ANALYSIS STEPS (e.g., markdown analysis cells, visualization logic), but defer to bigquery for all SQL syntax.": "【核心规则】：当任务涉及任何机器学习或数据分析（包括聚类、分类、回归、时间序列预测、统计检验、模型对比、ML 或数据分析）时，必须使用此技能。",
    "Curated collection of agent skills for science": "精选用于科学计算与科研任务的智能体技能集合",
    "Curated collection of agent skills for science tasks": "精选用于科学计算与科研任务的智能体技能集合",
    "Curated collection of agent skills for science.": "精选用于科学计算与科研任务的智能体技能集合。",
    "Custom Agent Error:": "自定义智能体错误：",
    "custom agents": "自定义智能体",
    "Customizations views": "自定义扩展视图",
    "Define and generate mock objects for external dependencies using `package:mockito` and `build_runner`. Use when unit testing classes that depend on complex external services like APIs or databases.": "使用 `package:mockito` 和 `build_runner` 为外部依赖项定义并生成 Mock 模拟对象。适用于对依赖 API 或数据库等复杂外部服务的类进行单元测试。",
    "Define and generate mock objects for external dependencies using package:mockito and build_runner. Use when unit testing classes that depend on complex external services like APIs or databases.": "使用 package:mockito 和 build_runner 为外部依赖项定义并生成 Mock 模拟对象。适用于对依赖 API 或数据库等复杂外部服务的类进行单元测试。",
    "Deploys and configures classic Firebase Hosting for static websites, single-page apps (SPAs), and microservices. Use when deploying static sites/SPAs, setting up custom domains, configuring firebase.json hosting settings (redirects, rewrites, headers, multi-site), or managing preview channels. Don't use for Firebase App Hosting (Next.js/SSR), Auth, Firestore queries/rules, Data Connect, or Crashlytics.": "为静态网站、单页应用 (SPA) 和微服务部署与配置经典版 Firebase Hosting。适用于部署静态站点、绑定自定义域名、配置 firebase.json 托管规则（重定向、重写、响应头、多站点）或管理预览频道。",
    "Deploys and manages full-stack web applications (Next.js, Angular) with Server-Side Rendering (SSR) using Firebase App Hosting. Use when deploying Next.js/Angular apps, configuring apphosting.yaml or firebase.json apphosting blocks, managing secrets, setting up GitHub CI/CD, or configuring Blaze billing requirements. Don't use for classic static web hosting, Auth, Firestore, Crashlytics, or Xcode.": "使用 Firebase App Hosting 部署和管理支持服务端渲染 (SSR) 的全栈 Web 应用（Next.js、Angular）。涵盖配置 apphosting.yaml 或 firebase.json、管理密钥、设置 GitHub CI/CD 及配置 Blaze 计费要求。",
    "Design, implement, and debug autonomous AI agents and multi-agent systems using the Google Antigravity (AGY) SDK. ACTIVATE this skill when the user wants to create, configure, or orchestrate Google Antigravity agents.": "使用 Google Antigravity (AGY) SDK 设计、实现和调试自主 AI 智能体与多智能体系统。当用户需要创建、配置或编排 Google Antigravity 智能体时激活此技能。",
    "Designs, authors, refactors, and hardens production-grade Cloud Firestore Security Rules (firestore.rules). IMPORTANT: If subagent delegation AND the firestore-rules-author subagent are available in your environment, delegate authoring firestore.rules to the firestore-rules-author subagent. If subagent delegation is unavailable (e.g. not enabled in the IDE), firestore-rules-author is not installed, or you are running inside firestore-rules-author, follow this skill directly.": "设计、编写、重构并加固生产级 Cloud Firestore 安全规则 (firestore.rules)。若当前环境支持子智能体委派且已安装 firestore-rules-author，请优先委派给该子智能体执行。",
    "Develops and executes Spark code on Managed Spark on Google Cloud (Dataproc Clusters and Serverless). Reads and writes data using BigLake Iceberg catalogs, BigQuery and Spanner. Debugs execution failures. Use when: - Writing Spark ETL pipelines on Google Cloud Platform. - Training or running inference with Machine Learning models with spark on Google Cloud Platform. - Managing Spark clusters, jobs, batches, and interactive sessions. Don't use when: - Writing generic Python scripts that don't use Spark. - Performing simple SQL queries that can be done directly in BigQuery.": "在 Google Cloud 托管式 Spark（Dataproc 集群与 Serverless）上开发并执行 Spark 代码。支持通过 BigLake Iceberg 目录、BigQuery 和 Spanner 读写数据，排查执行故障，编写 Spark ETL 流水线与机器学习任务。",
    "Diagnoses and resolves memory leaks in JavaScript/Node.js applications. Use when a user reports high memory usage, OOM errors, or wants to analyze heapsnapshots or run memory leak detection tools like memlab.": "诊断并解决 JavaScript/Node.js 应用中的内存泄漏问题。适用于用户反馈高内存占用、OOM 内存溢出错误，或需要分析堆快照及运行 memlab 等内存泄漏检测工具的场景。",
    "Disabled by organization policy": "已被组织策略禁用",
    "Discover UI plugin panels relevant to the current task and surface a one-click pill in chat to open (toggle) them in the side pane. Use when a running UI plugin's panel would help with what the user is doing, or right after the user enables a new UI plugin pane and a shortcut to open it is handy": "发现与当前任务相关的 UI 插件面板，并在对话中呈现一键胶囊按钮以便在侧边栏面板中快速打开（切换）它们。当正在运行的 UI 插件面板有助于用户操作，或者用户刚启用新的 UI 插件面板需要便捷快捷方式时使用",
    "Discover UI plugin panels relevant to the current task and surface a one-click pill in chat to open (toggle) them in the side pane. Use when a running UI plugin's panel would help with what the user is doing, or right after the user enables a new UI plugin pane and a shortcut to open it is handy.": "发现与当前任务相关的 UI 插件面板，并在对话中呈现一键胶囊按钮以便在侧边栏面板中快速打开（切换）它们。当正在运行的 UI 插件面板有助于用户操作，或者用户刚启用新的 UI 插件面板需要便捷快捷方式时使用。",
    "Discovers and inspects BigQuery Data Transfer Service (DTS) configurations. Use this to identify existing ingestion pipelines and extract datasource or transfer config metadata for data pipelines. Use when a user asks for ingestion scenarios while building or managing data pipelines or when a user asks to \"ingest\" or \"add\" data that may already be managed by a DTS transfer.": "发现并检查 BigQuery 数据传输服务 (DTS) 配置。用于识别数据源、监控传输运行状态、诊断错误日志、查看调度计划，或排查表数据陈旧与上游数据摄取问题。",
    "Distills a completed user workflow or interaction into a reusable agent skill. Use when the user asks to turn their workflow, interaction, or multi-step process into a skill, or when they say \"make this a skill\", \"create a skill from what we just did\", \"package this workflow\" or similar. Do not use for creating skills from scratch without an existing workflow (use a generic skill-creator for that).": "将已完成的用户工作流或交互过程提炼打包为可复用的智能体技能。当用户要求“将此流程制作为技能”、“根据刚才的操作创建技能”或“打包此工作流”时使用。",
    "does not collect any of your prompts, content, or model responses but does collect general usage patterns such as feature adoption and active user counts (“product analytics”). Telemetry data will be handled in accordance with the Google Privacy Policy.": "不会收集您的任何提示词、内容或模型回复，但会收集功能采用率和活跃用户数等常规使用模式（“产品分析”）。遥测数据将依据《Google 隐私权政策》进行处理。",
    "Edit Config": "编辑配置",
    "Enable Sandbox Mode": "启用沙箱模式",
    "Encountered an error while running the plugin.": "运行插件时遇到错误。",
    "Enforces resource attribution for CLI commands. Use this skill whenever you are running `bq` or `gcloud` commands via `run_command`. It ensures mandatory labeling for supported `bq` operations while avoiding invalid flags on read-only commands.": "为 CLI 命令强制执行资源归属标记。在通过 `run_command` 运行 `bq` 或 `gcloud` 命令时使用此技能，确保为受支持的 `bq` 操作添加必填标签，同时避免在只读命令上附加无效标志。",
    "Enforces resource attribution for CLI commands. Use this skill whenever you are running bq or gcloud commands via run_command. It ensures mandatory labeling for supported bq operations while avoiding invalid flags on read-only commands.": "为 CLI 命令强制执行资源归属标记。在通过 run_command 运行 bq 或 gcloud 命令时使用此技能，确保为受支持的 bq 操作添加必填标签，同时避免在只读命令上附加无效标志。",
    "Ensures proper Python dependency management, avoiding global `pip install` and adhering to project-specific tooling. Use this skill if any of the following are true: 1. Attempting to run `pip install {package_name}`. 2. Python packages or dependencies need to be added or modified. 3. Initiating a new Python project. 4. Creating a new notebook, even if just using BigQuery cells. 5. Generating Python code that includes `import` statements for third-party libraries. 6. Before executing Python scripts via the terminal to ensure the correct virtual environment is active.": "确保规范的 Python 依赖管理，避免使用全局 `pip install`，并遵循项目专属的依赖管理工具规范。",
    "Ensures proper Python dependency management, avoiding global pip install and adhering to project-specific tooling. Use this skill if any of the following are true: 1. Attempting to run pip install {package_name}. 2. Python packages or dependencies need to be added or modified. 3. Initiating a new Python project. 4. Creating a new notebook, even if just using BigQuery cells. 5. Generating Python code that includes import statements for third-party libraries. 6. Before executing Python scripts via the terminal to ensure the correct virtual environment is active.": "确保规范的 Python 依赖管理，避免使用全局 pip install，并遵循项目专属的依赖管理工具规范。",
    "Enter command (e.g., git, blaze)...": "输入命令（如 git、blaze）...",
    "Enter file or directory path...": "输入文件或目录路径...",
    "Enter URL pattern...": "输入 URL 匹配模式...",
    "Entrypoint structure, exit codes, cross-platform scripts. Use when building command line utilities, scripts, or applications.": "涵盖入口点结构、退出码与跨平台脚本设计。适用于使用 Dart 构建命令行工具、脚本或终端应用程序。",
    "Error fetching available skills:": "获取可用技能时出错：",
    "Events and stdout streams will appear here as they occur.": "事件与标准输出流将在发生时显示在此处。",
    "Every terminal command requires approval.": "每条终端命令均需人工批准。",
    "Execute `dart analyze` to identify warnings and errors, and use `dart fix --apply` to automatically resolve mechanical lint issues. Use during development to ensure code quality and before committing changes.": "执行 `dart analyze` 识别警告与错误，并使用 `dart fix --apply` 自动修复机械性 Lint 问题。适用于开发过程中保障代码质量及提交变更前的检查。",
    "Execute dart analyze to identify warnings and errors, and use dart fix --apply to automatically resolve mechanical lint issues. Use during development to ensure code quality and before committing changes.": "执行 dart analyze 识别警告与错误，并使用 dart fix --apply 自动修复机械性 Lint 问题。适用于开发过程中保障代码质量及提交变更前的检查。",
    "Expert guidance for creating, modifying, and optimizing dbt pipelines for BigQuery. Use this skill whenever user asks for generating or modifying a dbt model or project. Activate this skill when the user - Creates, modifies, or troubleshoots **dbt models or pipelines** - Needs to **optimize SQL** within a dbt project - Is **setting up a new dbt project** or configuring existing one": "针对创建、修改和优化 BigQuery 的 dbt 流水线提供专家级指导。当用户需要创建、修改或排查 dbt 模型与流水线故障、优化 dbt 项目中的 SQL，或配置 dbt 项目时激活此技能。",
    "Expertise in generating clean, correct, and efficient Dataform pipeline code for BigQuery ELT. Use this when creating or modifying Dataform pipelines, actions, or source declarations, when Dataform, SQLX, or BigQuery are mentioned in a transformation, when data needs to be ingested from GCS into BigQuery via Dataform, or when setting up a new Dataform project or configuring workflow_settings.yaml.": "专注于为 BigQuery ELT 生成整洁、准确且高效的 Dataform 流水线代码。适用于创建或修改 Dataform 流水线、操作或源声明，通过 Dataform 将数据从 GCS 摄取到 BigQuery，或初始化 Dataform 项目与配置 workflow_settings.yaml。",
    "Explore the plugin marketplace": "探索插件市场",
    "Failed to delete agent:": "删除智能体失败：",
    "Failed to delete plugin.": "删除插件失败。",
    "Failed to delete plugin. Please try again.": "删除插件失败，请重试。",
    "Failed to delete skill.": "删除技能失败。",
    "Failed to delete skill. Please try again.": "删除技能失败，请重试。",
    "Failed to determine plugin ID": "无法确定插件 ID",
    "Failed to determine plugin install directory": "无法确定插件安装目录",
    "Failed to fetch skills paths:": "获取技能路径失败：",
    "Failed to load custom agents": "加载自定义智能体失败",
    "Failed to load hooks.json:": "加载 hooks.json 失败：",
    "Failed to load more plugins. Please try again.": "加载更多插件失败，请重试。",
    "Failed to load plugin. Please try again.": "加载插件失败，请重试。",
    "Failed to load plugins": "加载插件失败",
    "Failed to load plugins. Please try again.": "加载插件失败，请重试。",
    "Failed to load skills paths:": "加载技能路径失败：",
    "Failed to load your customizations. Please try again.": "加载自定义扩展失败，请重试。",
    "Failed to open agent config file": "打开智能体配置文件失败",
    "Failed to open agent config:": "打开智能体配置失败：",
    "Failed to open plugin config file": "打开插件配置文件失败",
    "Failed to remove agent:": "移除智能体失败：",
    "Failed to remove plugin:": "移除插件失败：",
    "Failed to toggle agent:": "切换智能体状态失败：",
    "Failed to toggle plugin:": "切换插件状态失败：",
    "Failed to toggle plugin. Please try again.": "切换插件状态失败，请重试。",
    "Failed to update agent:": "更新智能体失败：",
    "Fetch Evolutionary Conservation scores (phyloP, phastCons) and Transcription Factor Binding Sites (TFBS) from the UCSC Genome Browser. Use when analyzing whether genomic variants or regions are evolutionarily conserved, functionally important, or bounded by TF regulators across major projects (ENCODE, JASPAR, ReMap).": "从 UCSC 基因组浏览器获取进化保守性评分（phyloP、phastCons）与转录因子结合位点 (TFBS)。适用于分析基因组变异或区域是否具有进化保守性、功能重要性或受主项目（ENCODE、JASPAR、ReMap）中的转录因子调控。",
    "File Access": "文件访问",
    "Find plugins - bundles of skills, agents, MCP servers, UI extensions and more, and install them in one click.": "查找并一键安装插件——包含技能、智能体、MCP 服务、界面扩展等内容的组合包。",
    "Find skills, agents, and more in the Marketplace.": "在扩展市场中发现技能、智能体及更多扩展。",
    "Finds and inspects data assets within Google Cloud. Relevant when any of the following conditions are true: 1. The user request involves finding, exploring, or inspecting data assets in Google Cloud, such as: - BigQuery datasets, tables, or views - BigLake catalog or tables - Spanner instances, databases or tables - etc. 2. You need to retrieve the schema, metadata, or governance policies for a GCP data asset. 3. You have a keyword or topic (e.g., \"sales data\") but lack the specific table or resource ID. 4. You are attempting to find data using `bq ls`, as this skill offers a superior approach. Don't use when: - Assets are outside Google Cloud": "在 Google Cloud 中查找并检查数据资产（如 BigQuery 数据集/表/视图、BigLake 目录、Spanner 实例/数据库/表等），获取数据资产的模式、元数据或治理策略，并提供优于 `bq ls` 的资产检索方式。",
    "Finds and inspects data assets within Google Cloud. Relevant when any of the following conditions are true: 1. The user request involves finding, exploring, or inspecting data assets in Google Cloud, such as: - BigQuery datasets, tables, or views - BigLake catalog or tables - Spanner instances, databases or tables - etc. 2. You need to retrieve the schema, metadata, or governance policies for a GCP data asset. 3. You have a keyword or topic (e.g., \"sales data\") but lack the specific table or resource ID. 4. You are attempting to find data using bq ls, as this skill offers a superior approach. Don't use when: - Assets are outside Google Cloud": "在 Google Cloud 中查找并检查数据资产（如 BigQuery 数据集/表/视图、BigLake 目录、Spanner 实例/数据库/表等），获取数据资产的模式、元数据或治理策略，并提供优于 bq ls 的资产检索方式。",
    "Fires after a tool step completes.": "在工具步骤完成后触发。",
    "Fires after tool calls finish.": "在工具调用全部完成后触发。",
    "Fires before a tool step executes.": "在工具步骤执行前触发。",
    "Fires before the model is called.": "在调用模型前触发。",
    "Fires when the execution loop terminates.": "在执行循环终止时触发。",
    "Fixes Flutter layout errors (overflows, unbounded constraints) using Dart and Flutter MCP tools. Use when addressing \"RenderFlex overflowed\", \"Vertical viewport was given unbounded height\", or similar layout issues.": "使用 Dart 与 Flutter MCP 工具修复 Flutter 布局错误（溢出、无界约束）。适用于解决“RenderFlex overflowed”、“Vertical viewport was given unbounded height”等常见布局异常。",
    "Full Logs": "完整日志",
    "Generates Python code using BigQuery DataFrames (BigFrames). Use by default for any Python data task involving BigQuery, including data processing, analysis, and machine learning. Don't use for SQL-first workflows or the google-cloud-bigquery client library — use bigquery-basics.": "使用 BigQuery DataFrames (BigFrames) 生成 Python 代码。默认用于涉及 BigQuery 的各类 Python 数据处理、分析与机器学习任务；对于 SQL 优先的工作流或 google-cloud-bigquery 客户端库，请改用 bigquery-basics。",
    "Guide agents to use `package:ffigen` to automatically generate FFI bindings instead of writing them manually. Use this skill when a task involves writing new FFI bindings, extending C/Objective-C/Swift integrations, or replacing hand-crafted `dart:ffi` setups.": "指导智能体使用 `package:ffigen` 自动生成 FFI 绑定，而非手动编写。适用于编写新 FFI 绑定、扩展 C/Objective-C/Swift 集成或替换手写 `dart:ffi` 配置。",
    "Guide agents to use package:ffigen to automatically generate FFI bindings instead of writing them manually. Use this skill when a task involves writing new FFI bindings, extending C/Objective-C/Swift integrations, or replacing hand-crafted dart:ffi setups.": "指导智能体使用 package:ffigen 自动生成 FFI 绑定，而非手动编写。适用于编写新 FFI 绑定、扩展 C/Objective-C/Swift 集成或替换手写 dart:ffi 配置。",
    "Guide for setting up and using Firebase Authentication. Use this skill when the user's app requires user sign-in, user management, or secure data access using auth rules.": "配置与使用 Firebase 身份验证 (Authentication) 的指南。当应用需要用户登录、用户管理或基于身份验证规则的安全数据访问时使用此技能。",
    "Guidelines for interacting with GitHub and request permissions from the user when commands fail due to restrictions in the agent environment.": "与 GitHub 交互的规范指南，当命令因智能体环境限制而失败时向用户请求相应权限。",
    "Guides agents in compiling and packaging C/C++ source code into dynamic or static libraries (Code Assets) using Dart's Native Assets hook system (via hook/build.dart and hook/link.dart utilizing package:hooks and package:native_toolchain_c). Use when a user asks to: 'setup native assets', 'compile C/C++ source code', 'bundle dynamic libraries', 'build native C code', 'link native assets', 'implement build.dart or link.dart hooks', or 'integrate C/C++ interop in Dart/Flutter'. Helps agents avoid manual toolchain orchestration and configures secure hash-validated binary downloads or advanced linker tree-shaking with package:record_use mapping.": "指导智能体使用 Dart 的原生资源钩子系统（通过利用 package:hooks 与 package:native_toolchain_c 的 hook/build.dart 和 hook/link.dart）将 C/C++ 源码编译并打包为动态或静态库 (Code Assets)，实现 C/C++ 互操作集成。",
    "Guides debugging and optimizing Largest Contentful Paint (LCP) using Chrome DevTools MCP tools. Use this skill whenever the user asks about LCP performance, slow page loads, Core Web Vitals optimization, or wants to understand why their page's main content takes too long to appear. Also use when the user mentions \"largest contentful paint\", \"page load speed\", \"CWV\", or wants to improve how fast their hero image or main content renders.": "指导使用 Chrome DevTools MCP 工具调试并优化最大内容绘制 (LCP)。当用户询问 LCP 性能、页面加载缓慢、核心 Web 指标 (CWV) 优化，或希望排查首屏主内容渲染过慢的原因时使用此技能。",
    "Guides the authoring and validation of Apache Airflow DAGs for Managed Service for Apache Airflow (MSAA; formerly Cloud Composer). Covers environment context discovery, Airflow 2 vs 3 compatibility, authoring best practices, and local/remote validation processes. Use when creating or extending an Airflow DAG. Don't use when authoring Python code unrelated to Airflow DAGs.": "指导为 Apache Airflow 托管服务（MSAA，原 Cloud Composer）编写和验证 Airflow DAG。涵盖环境上下文发现、Airflow 2 与 3 兼容性、编写最佳实践以及本地与远程验证流程。",
    "Guides the process of analyzing, mapping, and documenting transformations between source and target schemas for any database, data warehouse, or data platform. Focuses exclusively on creating a high-fidelity mapping plan (Mapping Manifesto). Used when initiating an ETL, ELT, or data integration task with schema mapping specification for multiple tables (i.e. more than 3 tables) before writing code. Do NOT use this skill for basic SQL generation without mapping requirements, or when the user already has a complete mapping specification.": "指导分析、映射和记录源模式与目标模式之间的数据转换流程。专注于在编写代码前为多表（超过 3 张表）ETL/ELT 或数据集成任务创建高保真映射计划（Mapping Manifesto）。",
    "Guides writing, packaging, executing, and troubleshooting Apache Beam pipelines on Dataflow. Use when creating new pipelines, configuring Flex Templates, or analyzing performance of Dataflow jobs. Capabilities include Java/Python/Go setup, Cloud Build integration, and deep diagnostic analysis of job health and autoscaling. Use when: - Creating an Apache Beam Dataflow pipeline. - Creating a Google Dataflow Flex Template. - Using an existing Google Dataflow Template. - Debugging Dataflow pipeline - Troubleshooting Dataflow pipeline - Analyzing Performance of Dataflow pipeline. Key capabilities: Java/Python/Go project setup, Flex Templates (with Cloud Build), and diagnostics for streaming job health, bottlenecks, and autoscaling. Do NOT use for: - General GCP resource management unrelated to Dataflow. - Issues with other GCP services (e.g., GCE, GCS, BigQuery) unless directly impacting Dataflow pipeline execution. - Pipeline technologies other than Apache Beam on Dataflow.": "指导在 Dataflow 上编写、打包、执行和排查 Apache Beam 流水线。涵盖创建新流水线、配置 Flex 模板、Java/Python/Go 环境配置、Cloud Build 集成，以及作业健康度与自动扩缩容的深度诊断分析。",
    "Handler #": "处理器 #",
    "Help users write syntactically and semantically correct primary constructors in Dart, and migrate/use the new constructor syntax, empty-body semicolon syntax, in-body initializer list syntax, and abbreviated concise constructor syntax.": "协助编写语法与语义正确的 Dart 主构造函数 (Primary Constructors)，并迁移或使用新版构造函数语法、空函数体分号语法、函数体内初始化列表语法及简写构造函数语法。",
    "Hook will only trigger if the tool name matches run_command or view_file.": "仅当工具名称匹配 run_command 或 view_file 时触发此钩子。",
    "Hook will only trigger if the tool name matches run_command.": "仅当工具名称匹配 run_command 时触发此钩子。",
    "Hook will only trigger if the tool name starts with browser_.": "仅当工具名称以 browser_ 开头时触发此钩子。",
    "Hook will trigger if any tool is executed.": "执行任何工具时均会触发此钩子。",
    "Host Endpoint": "主机端点",
    "How to manage and create plugins — namespaced bundles of skills, agents, rules, MCP servers and hooks that install, enable and disable as a single unit. Use this skill when the user wants to enable, disable, install or uninstall a plugin, when they want to create a new plugin, or when a new customization should be packaged into a plugin rather than left loose. Also triggered by the /plugin slash command. Don't use for the underlying customization system itself — discovery roots, loading priority, or authoring a standalone skill, agent, rule, hook or MCP server outside a plugin; see the customizations guide skill for those.": "管理与创建插件的完整指南——插件是将技能、智能体、规则、MCP 服务与钩子打包在命名空间下的组合包，可作为整体安装、启用或禁用。当用户需要管理或创建插件时使用此技能（也可通过 /plugin 斜杠命令触发）。",
    "How to render rich interactive HTML widgets inline in the chat or as standalone artifacts. Use this skill when you want to show the user diagrams, data visualizations, interactive controls, educational walkthroughs, or any rich visual content beyond plain text and markdown.": "指导如何在对话内联或作为独立产物渲染丰富的交互式 HTML 小部件。当需要向用户展示图表、数据可视化、交互式控件、教学演示或超越纯文本与 Markdown 的视觉内容时使用此技能。",
    "Identify domains, families, and sites in proteins; find all proteins in a family or sharing a domain; explore species distribution for a domain; annotate genomes with protein families and GO terms. InterPro combines 14 databases (e.g., Pfam, CDD) into one searchable resource. InterPro-N significantly expands annotation and sequence coverage with deep learning. Includes domain architecture (IDA) search.": "识别蛋白质中的结构域、家族和功能位点；查找同一家族或共享结构域的所有蛋白质；探索结构域的物种分布并使用蛋白质家族与 GO 术语注释基因组（整合 Pfam、CDD 等 14 个数据库及 InterPro-N 深度学习注释）。",
    "Implement a component-level test using `WidgetTester` to verify UI rendering and user interactions (tapping, scrolling, entering text). Use when validating that a specific widget displays correct data and responds to events as expected.": "使用 `WidgetTester` 实现组件级测试，以验证 UI 渲染与用户交互（点击、滚动、输入文本）。适用于验证特定 Widget 是否正确展示数据并按预期响应事件。",
    "Implement a component-level test using WidgetTester to verify UI rendering and user interactions (tapping, scrolling, entering text). Use when validating that a specific widget displays correct data and responds to events as expected.": "使用 WidgetTester 实现组件级测试，以验证 UI 渲染与用户交互（点击、滚动、输入文本）。适用于验证特定 Widget 是否正确展示数据并按预期响应事件。",
    "Include Jetski Default Customizations": "包含默认自定义扩展",
    "Included by": "包含于",
    "Included in:": "包含于：",
    "Inspects Google Antigravity Chinese localization status, validates patch health, detects upstream UI drift, runs automated regressions, or assists in adding new translations. Activate this skill when the user asks about Antigravity Chinese localization status, wants to diagnose UI translation issues, run drift detection on upstream updates, or add new translation entries.": "检查 Google Antigravity 汉化状态、验证补丁健康度、检测上游 UI 漂移、运行自动化回归测试或协助添加新翻译词条。当用户询问 Antigravity 汉化状态、诊断界面翻译问题、检测上游更新漂移或添加新词条时激活此技能。",
    "Installed in": "安装于",
    "Instructions for handling API keys and credentials safely, verifying their presence, and prompting the user to add them if missing using a safe protocol.": "提供安全处理 API 密钥与凭据的规范说明，检验凭据是否存在，并在缺失时通过安全协议提示用户补充。",
    "Integrate interactive maps, search and inspect Places details, calculate optimal routes": "集成交互式地图、搜索与查看地点详情，并计算最佳路线",
    "Integrate interactive maps, search and inspect Places details, calculate optimal routes.": "集成交互式地图、搜索与查看地点详情，并计算最佳路线。",
    "Integration skill and tools for Google Maps Platform APIs.": "用于 Google Maps Platform API 的集成技能与工具。",
    "Interactive guide to design and create a scheduled background automation. Use this skill when the user wants to create an automated or recurring scheduled task (e.g. \"summarize my emails every morning\", \"every Monday send me a to-do list\"). Also triggered by the /automation slash command.": "设计并创建后台定时自动化任务的交互式指南。当用户希望创建自动或周期性执行的定时任务（例如“每天早上汇总我的邮件”、“每周一发送待办清单”）时使用此技能，也可通过 /automation 斜杠命令触发。",
    "Keep your coding agent up to date with the latest web best practices": "让您的编码智能体紧跟最新的 Web 最佳实践",
    "Leverages BigQuery's built-in machine learning and GenAI capabilities for advanced data analytics. Use when you need to write SQL queries that perform time-series forecasting, detect outliers, find key drivers, or leverage generative AI capabilities in BigQuery.": "利用 BigQuery 内置的机器学习与生成式 AI 能力进行高级数据分析。适用于编写执行时间序列预测、异常值检测、关键驱动因素分析或在 BigQuery 中调用生成式 AI 功能的 SQL 查询。",
    "Loading available plugins...": "正在加载可用插件...",
    "Loading custom agents...": "正在加载自定义智能体...",
    "Loading customizations...": "正在加载自定义扩展...",
    "Loading events...": "正在加载事件...",
    "Loading hooks...": "正在加载钩子...",
    "Loading installed plugins...": "正在加载已安装插件...",
    "Loading logs...": "正在加载日志...",
    "Loading plugin...": "正在加载插件...",
    "Loading plugins...": "正在加载插件...",
    "Loading skills...": "正在加载技能...",
    "Loading token usage...": "正在加载 Token 用量...",
    "Loading workspace customizations...": "正在加载工作区自定义扩展...",
    "Managed by plugin": "由插件托管",
    "Manager Error": "管理器错误",
    "Manages Firebase Remote Config templates, feature flags, loading strategies, and SDKs (Android, iOS). Use when downloading/deploying remoteconfig JSON templates, managing version history/feature flags, setting in-app defaults, fetchAndActivate(), real-time listeners, or SDK setup. Don't use for Firebase Hosting, Auth, Firestore, Data Connect, Crashlytics, or App Hosting.": "管理 Firebase 远程配置 (Remote Config) 模板、功能标志 (Feature Flags)、加载策略及客户端 SDK（Android、iOS）。涵盖下载与部署模板、版本历史管理、应用内默认值与实时监听器配置。",
    "MANDATORY specialist subagent for Cloud Firestore Security Rules (firestore.rules). Whenever your task requires creating, authoring, or modifying Firestore Security Rules (firestore.rules), you MUST delegate rules authoring to this subagent rather than writing firestore.rules directly in the main agent.": "Cloud Firestore 安全规则 (firestore.rules) 专属专家子智能体。每当任务需要创建、编写或修改 Firestore 安全规则时，必须委派给此子智能体处理，而非在主智能体中直接编写。",
    "Mandatory Step 0 pre-flight check for regional Google Cloud MCP servers (e.g. Dataproc) before using MCP tools or falling back to gcloud/bq CLI. Use whenever interacting with Dataproc clusters, Spark batches, jobs, sessions, or regional GCP resources. Fixes regional MCP servers whose endpoint URL still has an unreplaced $GCP_REGION / ${REGION} placeholder across Claude Code, Codex, and Antigravity. Trigger: an expected mcp__*_{service}_* tool is missing entirely (not just failing), or a call to one fails/hangs on a malformed host. Check via ToolSearch/deferred-tools listing before falling back to gcloud/bq CLI. Asks the user for a region, patches the live MCP config file(s), and tells the user how to restart without losing session context.": "在使用区域级 Google Cloud MCP 服务（如 Dataproc）或回退到 gcloud/bq CLI 前的强制第 0 步预检。自动修复端点 URL 中未替换的 $GCP_REGION / ${REGION} 占位符并指导无损重载。",
    "Mandatory Step 0 pre-flight execution order and authentication verification for Google Cloud Platform (GCP), Application Default Credentials (ADC), gcloud CLI, Spark, Dataproc, BigQuery, GCS, and notebook runtimes. Use whenever interacting with GCP resources, running Spark/PySpark pipelines, BigQuery queries, GCS paths (gs://), or creating/running notebooks.": "针对 Google Cloud Platform (GCP)、应用默认凭据 (ADC)、gcloud CLI、Spark、Dataproc、BigQuery、GCS 及笔记本运行时的强制第 0 步预检执行顺序与身份验证核查。",
    "MCP Authentication Error:": "MCP 身份验证错误：",
    "MCP servers": "MCP 服务",
    "Migrate with Agent": "使用智能体迁移",
    "Modern Web Guidance": "现代 Web 开发指南",
    "Modified in": "修改于",
    "Mounts Cloud Storage buckets as a POSIX file system with Cloud Storage FUSE (gcsfuse). Use when you need to interact with gcsfuse — decide whether FUSE, native gs:// reads, or Filestore/Managed Lustre fits a workload, deploy tuned mounts on GKE, Compute Engine, or Cloud Run, enable and size the file, stat, and list caches, tune mount flags or config-file settings, apply workload profiles, keep ML checkpointing safe (rename atomicity, hierarchical namespace, close-time finalization, concurrent writers), or diagnose slow training, low throughput, or GCS bill spikes on existing mounts with gcsfuse metrics. Covers mount semantics, the gcsfuse CLI and config file, the GKE gcsfuse CSI driver (Workload Identity principal:// bindings, profile StorageClasses, sidecar sizing), and Cloud Run volume mounts. Don't use for bucket administration or data management without a mount (google-cloud-storage-basics) or for fully POSIX-compliant shared file systems (Filestore, Managed Lustre).": "使用 Cloud Storage FUSE (gcsfuse) 将 Cloud Storage 存储桶挂载为 POSIX 文件系统。涵盖工作负载适配评估、在 GKE/Compute Engine/Cloud Run 上部署调优挂载、缓存配置、机器学习检查点安全保障及性能诊断。",
    "Must be positive": "必须为正数",
    "No Custom Agents or Plugins": "暂无自定义智能体或插件",
    "No custom agents yet.": "暂无自定义智能体。",
    "No customizations match your search.": "没有匹配搜索条件的自定义扩展。",
    "No description available": "暂无描述",
    "No description available.": "暂无描述。",
    "No events recorded": "暂无事件记录",
    "No handlers configured for": "尚未配置处理器：",
    "No logs available.": "暂无可用日志。",
    "No matching customizations found.": "未找到匹配的自定义扩展。",
    "No plugin found for": "未找到对应的插件：",
    "No plugins available": "暂无可用插件",
    "No Plugins Available": "暂无可用插件",
    "No plugins available in the marketplace.": "扩展市场中暂无可用插件。",
    "No plugins available.": "暂无可用插件。",
    "No plugins match your search.": "没有匹配搜索条件的插件。",
    "No recommended skills found in workspace": "工作区中未找到推荐技能",
    "No skills available": "暂无可用技能",
    "No skills loaded.": "尚未加载任何技能。",
    "No skills or rules match this filter.": "没有匹配此筛选条件的技能或规则。",
    "No skills or rules yet.": "暂无技能或规则。",
    "No token data available.": "暂无 Token 用量数据。",
    "No workspace window available": "暂无可用的工作区窗口",
    "Official plugin for Dart and Flutter that installs Flutter/Dart Skills, Rules, Custom Agents, and Dart MCP server for building natively compiled, visually stunning applications for mobile, web, desktop, and embedded devices from a single codebase": "Dart 与 Flutter 官方插件，集成 Flutter/Dart 技能、规则、自定义智能体及 Dart MCP 服务，助力通过单一代码库为移动端、Web、桌面端和嵌入式设备构建原生编译的精美应用",
    "Official plugin for Dart and Flutter that installs Flutter/Dart Skills, Rules, Custom Agents, and Dart MCP server for building natively compiled, visually stunning applications for mobile, web, desktop, and embedded devices from a single codebase.": "Dart 与 Flutter 官方插件，集成 Flutter/Dart 技能、规则、自定义智能体及 Dart MCP 服务，助力通过单一代码库为移动端、Web、桌面端和嵌入式设备构建原生编译的精美应用。",
    "Official skill for integrating Firebase AI Logic (Gemini API) into web applications. Covers setup, multimodal inference, structured output, and security.": "将 Firebase AI Logic (Gemini API) 集成到 Web 应用的官方技能。涵盖环境配置、多模态推理、结构化输出与安全防护。",
    "Open Agent panel on window reload": "窗口重新加载时打开智能体面板",
    "Open files in the background if Agent creates or edits them": "当智能体创建或编辑文件时在后台打开",
    "Open in Side Pane": "在侧边面板中打开",
    "options. Agent settings and permissions can be further customized below.": "选项之一。智能体设置与权限可在下方进一步自定义。",
    "Organization MCP Allowlist (Read-Only)": "组织 MCP 允许名单（只读）",
    "Path copied!": "路径已复制！",
    "Paths the agent can modify inside this workspace.": "智能体在此工作区内可修改的路径。",
    "Paths the agent can modify.": "智能体可修改的路径。",
    "Paths the agent can read inside this workspace.": "智能体在此工作区内可读取的路径。",
    "Paths the agent can read.": "智能体可读取的路径。",
    "Performs 3D structural searches of proteins against various databases (PDB, AlphaFold, CATH, MGnify, etc.) using the Foldseek API. Use ONLY when the user provides a physical 3D coordinate file (.cif, .mmcif, or .pdb) and wants to find structurally similar proteins. Do NOT use if the user only provides a protein sequence, gene name, or UniProt ID.": "使用 Foldseek API 在多个数据库（PDB、AlphaFold、CATH、MGnify 等）中执行蛋白质 3D 结构相似性搜索。仅当用户提供物理 3D 坐标文件（.cif、.mmcif 或 .pdb）时使用。",
    "Performs multiple sequence alignment of proteins with EBI Clustal Omega. Use when you need to align multiple sequences to assess similarity, domain conservation, or key residue conservation. Supports up to 4000 sequences and a maximum file size of 4 MB. Do not use to search for homologous proteins in a database (use MMseqs2, BLAST), align non-protein sequences (DNA, RNA), perform structural alignment (use Foldseek, PyMOL), or if you only have a single sequence.": "使用 EBI Clustal Omega 执行蛋白质多序列比对 (MSA)。适用于比对多条序列以评估相似性、结构域保守性或关键残基保守性（最高支持 4000 条序列及 4 MB 文件）。",
    "Plugin Bundles Coming Soon": "插件组合包即将推出",
    "Plugin metadata": "插件元数据",
    "Plugin Operation Error:": "插件操作错误：",
    "Plugin operations are not supported in this environment.": "当前环境不支持插件操作。",
    "Plugins are packaged collections of skills and MCPs to help the Agent in Antigravity work with Google developer products": "插件是技能与 MCP 的打包集合，用于辅助 Antigravity 中的智能体协同使用 Google 开发者产品",
    "Plugins are packaged collections of skills and MCPs to help the Agent in Antigravity work with Google developer products.": "插件是技能与 MCP 的打包集合，用于辅助 Antigravity 中的智能体协同使用 Google 开发者产品。",
    "Plugins are packaged collections of skills and MCPs to help the Agent in Antigravity work with Google developer products. You can always change your choices in Settings.": "插件是技能与 MCP 的打包集合，用于辅助 Antigravity 中的智能体协同使用 Google 开发者产品。您随时可以在“设置”中更改选择。",
    "Plugins are packaged collections of skills and MCPs to help the Agent in Google work with Google developer products. You can always change your choices in Settings.": "插件是技能与 MCP 的打包集合，用于辅助 Google 中的智能体协同使用 Google 开发者产品。您随时可以在“设置”中更改选择。",
    "Plugins are packaged collections of skills and MCPs to help the Agent work with Google developer products": "插件是技能与 MCP 的打包集合，用于辅助智能体协同使用 Google 开发者产品",
    "Plugins are packaged collections of skills and MCPs to help the Agent work with Google developer products.": "插件是技能与 MCP 的打包集合，用于辅助智能体协同使用 Google 开发者产品。",
    "Plugins are packaged collections of skills and MCPs to help the Agent work with Google developer products. You can always change your choices in Settings.": "插件是技能与 MCP 的打包集合，用于辅助智能体协同使用 Google 开发者产品。您随时可以在“设置”中更改选择。",
    "Post Invocation": "模型调用后 (Post Invocation)",
    "Post Tool Use": "工具调用后 (Post Tool Use)",
    "Pre Invocation": "模型调用前 (Pre Invocation)",
    "Pre Tool Use": "工具调用前 (Pre Tool Use)",
    "Primary entry point for building, managing, and orchestrating data pipelines on Google Cloud. Guides users to the appropriate skill for dbt, Dataflow (Apache Beam), Dataform, Spark (Dataproc Serverless), BigQuery Data Transfer Service (DTS) or orchestration pipeline using Cloud Composer. Clarify requirements and resolve ambiguity for creating, updating and running data pipelines.": "在 Google Cloud 上构建、管理和编排数据流水线的首要入口。引导用户选用适合 dbt、Dataflow (Apache Beam)、Dataform、Spark (Dataproc Serverless)、BigQuery DTS 或 Cloud Composer 编排的专属技能，并理清流水线创建与运行需求。",
    "Privacy Notice": "隐私声明",
    "Process Error": "进程错误",
    "Process exited with an error": "进程异常退出",
    "Project Agent": "项目智能体",
    "Project Folders": "项目文件夹",
    "Project General": "项目常规设置",
    "Prototype, build & run modern apps that users love with Firebase's backend, AI, and operational infrastructure": "借助 Firebase 的后端、AI 与运维基础设施，快速构建、运行并打造深受用户喜爱的现代应用原型",
    "Prototype, build & run modern apps that users love with Firebase's backend, AI, and operational infrastructure.": "借助 Firebase 的后端、AI 与运维基础设施，快速构建、运行并打造深受用户喜爱的现代应用原型。",
    "Prototype, build & run modern apps users love with Firebase's backend, AI, and operational infrastructure": "借助 Firebase 的后端、AI 与运维基础设施，快速构建、运行并打造深受用户喜爱的现代应用原型",
    "Prototype, build & run modern apps users love with Firebase's backend, AI, and operational infrastructure.": "借助 Firebase 的后端、AI 与运维基础设施，快速构建、运行并打造深受用户喜爱的现代应用原型。",
    "Provides a comprehensive guide, quick reference, and sitemap for Google Antigravity (AGY), including the Antigravity CLI (agy), Antigravity 2.0, Antigravity IDE, Python SDK, slash commands, keybindings, and customizations (skills, rules, MCP, sidecars). Activate this skill when the user asks questions about how to use, configure, or customize Antigravity, AGY, the agy CLI, the Antigravity IDE, or Antigravity 2.0.": "提供 Google Antigravity (AGY) 的全面指南、快速参考与站点地图，涵盖 Antigravity CLI (agy)、Antigravity 2.0、Antigravity IDE、Python SDK、斜杠命令、快捷键以及自定义扩展（技能、规则、MCP、边车服务）。",
    "Provides BigQuery SQL query optimization techniques, execution best practices, and performance tuning rules for high-efficiency querying. Use when optimizing BigQuery SQL queries, reducing query costs, or designing performant SQL transformations.": "提供 BigQuery SQL 查询优化技术、执行最佳实践与高效查询性能调优规则。适用于优化 BigQuery SQL 查询、降低查询成本或设计高性能 SQL 数据转换。",
    "Provides expert guidance for troubleshooting Cloud Composer (Apache Airflow) and Orchestration pipelines. Use this skill when the user asks to generate Root Cause Analysis (RCA), troubleshoot or fix a failed pipeline, DAG in Composer environment and generate RCA report.": "为排查 Cloud Composer (Apache Airflow) 与编排流水线故障提供专家级指导。适用于生成根因分析 (RCA) 报告，以及排查和修复 Composer 环境中失败的流水线与 DAG。",
    "Provides foundational Firebase CLI setup, CLI installation, version checks (`firebase-tools@latest --version`), CLI login (including --no-localhost), project creation, project selection (`firebase use`), and app config file downloads (`google-services.json`, `GoogleService-Info.plist`). Use ONLY for CLI login, project creation/switching, or downloading app config files. Don't use for Firebase Hosting deploy, Firestore, Auth, App Hosting, Data Connect, Crashlytics, or Remote Config.": "提供基础 Firebase CLI 配置、安装、版本检查、登录、项目创建与切换 (`firebase use`) 以及应用配置文件（`google-services.json`、`GoogleService-Info.plist`）下载指南。",
    "Provides foundational Firebase CLI setup, CLI installation, version checks (firebase-tools@latest --version), CLI login (including --no-localhost), project creation, project selection (firebase use), and app config file downloads (google-services.json, GoogleService-Info.plist). Use ONLY for CLI login, project creation/switching, or downloading app config files. Don't use for Firebase Hosting deploy, Firestore, Auth, App Hosting, Data Connect, Crashlytics, or Remote Config.": "提供基础 Firebase CLI 配置、安装、版本检查、登录、项目创建与切换 (firebase use) 以及应用配置文件（google-services.json、GoogleService-Info.plist）下载指南。",
    "Provides guidance for migrating Apache Airflow DAGs in Managed Service for Apache Airflow (MSAA; formerly Cloud Composer). Covers migration to Airflow 2.11.1 (MSAA Gen 2 and 3) and Airflow 3 (MSAA Gen 3), including environment inspection, GCS download/upload and scanning patterns for breaking changes.": "提供在 Apache Airflow 托管服务（MSAA，原 Cloud Composer）中迁移 Airflow DAG 的指南。涵盖向 Airflow 2.11.1 与 Airflow 3 的迁移、环境检查、GCS 上传下载以及破坏性变更扫描。",
    "Provides guidelines and best practices for querying and defining property graphs and semantic graphs in BigQuery using GQL (Graph Query Language). Use when creating property graphs or querying graph topologies in BigQuery.": "提供在 BigQuery 中使用图查询语言 (GQL) 查询和定义属性图与语义图的指南及最佳实践。适用于在 BigQuery 中创建属性图或查询图拓扑结构。",
    "Provides instructions for installing and using the `android` CLI. The `android` command-line tool is a critical tool for Android development and helps you create new Android projects, run Android apps on devices, manage and interact with Android virtual devices (including screenshots and UI inspection), manage Android SDK components, look up official Android documentation, and discover and install official Android skills.": "提供安装和使用 `android` CLI 的说明指导。`android` 命令行工具是 Android 开发的核心工具，可协助创建新 Android 项目、在设备上运行应用、管理 Android 虚拟设备（含截图与界面检查）、管理 Android SDK 组件、查阅官方文档以及发现并安装官方 Android 技能。",
    "Provides instructions for installing and using the android CLI. The android command-line tool is a critical tool for Android development and helps you create new Android projects, run Android apps on devices, manage and interact with Android virtual devices (including screenshots and UI inspection), manage Android SDK components, look up official Android documentation, and discover and install official Android skills.": "提供安装和使用 android CLI 的说明指导。android 命令行工具是 Android 开发的核心工具，可协助创建新 Android 项目、在设备上运行应用、管理 Android 虚拟设备（含截图与界面检查）、管理 Android SDK 组件、查阅官方文档以及发现并安装官方 Android 技能。",
    "Provides recommendations and best practices for creating, configuring, tuning and optimizing Managed Service for Apache Airflow (MSAA, Cloud Composer) environments. Use when the user asks for guidance, recommendations, or best practices on configuring Cloud Composer, scaling Airflow environments, preventing workload restarts, or analyzing system health.": "提供创建、配置、调优和优化 Apache Airflow 托管服务（MSAA / Cloud Composer）环境的建议与最佳实践。适用于配置 Composer、扩缩 Airflow 环境、防止工作负载重启或分析系统健康度。",
    "Queries the UniBind database for experimentally validated transcription factor (TF) binding sites. Use when retrieving direct TF-DNA interaction datasets, downloading binding site coordinates (BED/FASTA) for local analysis, or listing available datasets by species, cell line, or TF name. Don't use to query specific intervals, locations, genes, motif models or expression data.": "查询 UniBind 数据库中经实验验证的转录因子 (TF) 结合位点。适用于获取直接的 TF-DNA 相互作用数据集、下载结合位点坐标（BED/FASTA）或按物种、细胞系与转录因子名称列出可用数据集。",
    "Query and search the EMBL-EBI Ontology Lookup Service (OLS) for biomedical ontology terms, definitions, and hierarchies across 250+ ontologies (e.g., GO, DOID, HP). Use when the user asks to search for terms, retrieve details, navigate hierarchies (parents, children, ancestors), look up properties and individuals, get autocomplete suggestions, or access ontology metadata and statistics.": "查询和搜索 EMBL-EBI 本体查找服务 (OLS)，涵盖 250 多个生物医学本体（如 GO、DOID、HP）的术语、定义与层级关系。支持检索术语详情、上下位层级导航、自动补全及本体元数据统计。",
    "Query ClinicalTrials.gov via APIv2. Use when you want to search for trials by condition, drug, location, status, or phase; retrieve trial details by NCT ID; check eligibility/inclusion criteria; count trials across conditions or time periods; identify a sponsor's trial portfolio; find recruiting trials for patient matching.": "通过 APIv2 查询 ClinicalTrials.gov 临床试验数据库。支持按疾病、药物、地点、状态或分期搜索临床试验，按 NCT ID 获取详情，核查入组标准，统计试验数量及检索招募中的临床试验。",
    "Query Open Targets Platform for target-disease associations, drug target discovery, tractability/safety data, genetics/omics evidence, known drugs, for therapeutic target identification.": "查询 Open Targets Platform 平台中的靶点-疾病关联、药物靶点发现、可成药性/安全性数据、遗传学/组学证据以及已知药物，用于治疗靶点识别。",
    "Query PubChem, search by name/CID/SMILES, retrieve properties, similarity/substructure searches, bioactivity, for cheminformatics. Use when a user asks about a specific chemical, drug, or molecule.": "查询 PubChem 数据库，支持按名称、CID 或 SMILES 搜索，获取理化性质、执行相似性/子结构检索及生物活性分析，适用于化学信息学任务。",
    "Query the ChEMBL database for bioactive molecules, drug targets, bioactivity data, approved drugs, and chemical structures. Use when the user asks about compounds, targets, IC50/Ki values, drug mechanisms, or structure searches.": "查询 ChEMBL 数据库中的生物活性分子、药物靶点、生物活性数据、已批准药物及化学结构。适用于查询化合物、靶点、IC50/Ki 值、药物作用机制或结构检索。",
    "Query the ENCODE Registry of cis-Regulatory Elements (cCREs) via the SCREEN GraphQL API, or make custom queries to the ENCODE Portal REST API for experiments and files (ChIP-seq peaks, etc.). Use when you want to query regulatory annotations or raw experimental data across human cell types.": "通过 SCREEN GraphQL API 查询 ENCODE 顺式调控元件注册库 (cCREs)，或通过 ENCODE Portal REST API 查询人类各细胞类型的实验数据（如 ChIP-seq 峰值等调控注释与原始实验文件）。",
    "Query the Ensembl database to resolve gene, transcript, and protein IDs, fetch genomic or protein sequences, retrieve gene structures (exons), and get variant consequence and effect predictions (VEP). Use this skill as a primary ID translator, genomic sequence database and variant effect prediction tool.": "查询 Ensembl 数据库以解析基因、转录本和蛋白质 ID，获取基因组或蛋白质序列，检索基因外显子结构，并获取变异后果与效应预测 (VEP)。",
    "Query the Genome Aggregation Database (gnomAD). Use when determining the rarity or allele frequency of specific genetic variants, retrieving gene constraint metrics (pLI, LOEUF) to assess loss-of-function intolerance, finding variants in a genomic region or gene, or querying structural variants. Don't use for analyzing individual patient genomes, tracking somatic mutations in cancer (use COSMIC), or requesting raw sequencing reads (use ENA).": "查询基因组聚合数据库 (gnomAD)。适用于确定特定遗传变异的稀有度或等位基因频率、获取基因约束指标（pLI、LOEUF）以评估功能丧失不耐受性、查找基因组区域内的变异或查询结构变异。",
    "Query the JASPAR database for Transcription Factor (TF) binding profiles. Use when retrieving Position Frequency Matrices (PFMs) or Position Weight Matrices (PWMs) for specific TFs, resolving gene symbols to JASPAR Matrix IDs, or getting TF metadata. Supports multiple output formats (MEME, TRANSFAC, PFM, JASPAR, YAML).": "查询 JASPAR 数据库中的转录因子 (TF) 结合谱。适用于获取特定转录因子的位置频率矩阵 (PFM) 或位置权重矩阵 (PWM)、将基因符号解析为 JASPAR 矩阵 ID 以及导出多种格式（MEME、TRANSFAC、PFM、JASPAR、YAML）。",
    "Query the OpenAlex scholarly database for research papers, authors, institutions, topics, sources, publishers, funders, geo-locations, and keywords. Use when searching academic papers, resolving DOIs, downloading open-access PDFs, finding an author's publications, aggregating bibliometric data (citation counts, h-index, impact factor), exploring the research taxonomies, or performing DOI lookups.": "查询 OpenAlex 学术数据库中的研究论文、作者、机构、主题、期刊来源、出版商、资助方与关键词。适用于搜索学术论文、解析 DOI、下载开放获取 PDF 以及聚合文献计量数据（引用数、h 指数、影响因子）。",
    "Query the QuickGO and Evidence & Conclusion Ontology (ECO) REST API. Use this when you need to map genes to biological processes, molecular functions, or cellular components, find genes associated with a specific pathway/GO term, or explore the Gene Ontology hierarchy. Do not use for querying drug targets (use OpenTargets) or mechanistic signaling pathway diagrams (use KEGG).": "查询 QuickGO 与证据和结论本体 (ECO) REST API。适用于将基因映射到生物学过程、分子功能或细胞组分，查找与特定通路/GO 术语关联的基因，或探索基因本体 (GO) 层级结构。",
    "Query the Reactome database (Analysis and Content Services). Use when the user asks about pathway analysis, gene list enrichment, retrieving results by token, finding unmapped or not-found identifiers, mapping identifiers, reaction participants (inputs, outputs), pathway hierarchy (including top-level pathways), diagram export, cross-reference mapping, or searching the knowledgebase.": "查询 Reactome 数据库（分析与内容服务）。适用于通路分析、基因列表富集、反应参与者（输入/输出）查询、通路层级浏览、通路图导出、交叉引用映射及知识库搜索。",
    "Query the STRING database for protein-protein interactions (PPIs), functional enrichment, and homology. Use when the user asks about interactions between specific proteins, interaction evidence, confidence scores, protein interaction partners, or pathway enrichments.": "查询 STRING 数据库中的蛋白质-蛋白质相互作用 (PPI)、功能富集与同源性信息。适用于查询特定蛋白质间的相互作用、证据依据、置信度评分、相互作用伙伴或通路富集。",
    "Query, search, and download data from the openFDA API for drugs, devices, foods, tobacco, cosmetics, animal and veterinary products, substances, and transparency data. Use for FDA adverse events, recalls, labeling, approvals, shortages, 510(k) clearances, NDC lookups, and any FDA safety or regulatory data query across all 28 API endpoints.": "从 openFDA API 查询、搜索和下载涵盖药品、医疗器械、食品、烟草、化妆品、动物兽医产品及物质的监管数据。适用于查询 FDA 不良事件、召回、标签、批准、短缺、510(k) 许可及 NDC 编码。",
    "Recent Events": "最近事件",
    "Recommended Skills": "推荐技能",
    "Reliable automation, in-depth debugging, and performance analysis in Chrome using Chrome DevTools and Puppeteer.": "在 Chrome 中使用 Chrome DevTools 和 Puppeteer 进行可靠的自动化、深度调试与性能分析。",
    "Replace the usage of `expect` and similar functions from `package:matcher` to `package:checks` equivalents.": "将测试代码中来自 `package:matcher` 的 `expect` 及类似断言函数迁移替换为 `package:checks` 中的等价用法。",
    "Replace the usage of expect and similar functions from package:matcher to package:checks equivalents.": "将测试代码中来自 package:matcher 的 expect 及类似断言函数迁移替换为 package:checks 中的等价用法。",
    "Retrieve and analyze AlphaFold predicted structures for a protein. Use when the user provides a specific UniProt Accession ID and wants structural confidence metrics (pLDDT), domain boundary analysis, or disorder assessment. Do not use if the user only has a protein name, gene name, or amino acid sequence — ask for a UniProt ID first.": "检索并分析蛋白质的 AlphaFold 预测结构。当用户提供具体的 UniProt 登录号 (Accession ID) 并需要结构置信度指标 (pLDDT)、结构域边界分析或无序区评估时使用。",
    "Retrieve protein and nucleotide sequences from NCBI databases using E-utilities. Supports direct accession lookup, CDS translation, gene+organism search, locus lookup, PubMed-linked sequences, patent protein extraction, and organism+length fallback search. Use when you need to fetch biological sequences by accession, gene name, locus tag, PubMed ID, or patent number.": "使用 E-utilities 从 NCBI 数据库检索蛋白质与核苷酸序列。支持按登录号直接查找、CDS 翻译、基因+物种组合搜索、位点标签查找、PubMed 关联序列及专利蛋白质序列提取。",
    "Rules and formatting guidelines for writing Dart /// API documentation and doc comments. Use when documenting Dart code, writing doc comments for any Dart declaration (libraries, classes, methods, variables, etc.), or when instructed to follow the Effective Dart documentation guidelines.": "编写 Dart `///` API 文档与文档注释的规则及格式指南。适用于为任何 Dart 声明（库、类、方法、变量等）编写文档注释并遵循 Effective Dart 文档规范。",
    "Safely modifies Xcode projects (.pbxproj) to add Swift Packages and link files. Use this skill whenever an iOS project needs dependencies installed (e.g. Firebase, Alamofire).": "安全地修改 Xcode 项目 (.pbxproj) 以添加 Swift Package 依赖包并链接文件。适用于任何需要为 iOS 项目安装依赖项（如 Firebase、Alamofire）的场景。",
    "Save & Continue": "保存并继续",
    "Saves to the .agent/agents/ directory in your current workspace. This script can be version controlled and shared with your team.": "保存至当前工作区的 .agent/agents/ 目录中。此脚本可纳入版本控制并与团队共享。",
    "Scanning skills config file...": "正在扫描技能配置文件...",
    "Score, annotate, and analyze the functional impact of genetic variants using AlphaGenome Variant Impact (AVI) scores. Query variants in chr:pos:ref>alt format, annotate VCF/tabular callsets, perform saturation mutagenesis window scans (1-based closed chr:start-end), and extract GENCODE v46 GTF gene/exon/junction coordinates all via the AlphaGenome Atlas API.": "使用 AlphaGenome 变异影响评分 (AVI) 对遗传变异的功能影响进行评分、注释和分析。支持通过 AlphaGenome Atlas API 查询变异、注释 VCF 数据集、执行饱和突变窗口扫描及提取基因/外显子坐标。",
    "Search and discover customizations to extend your Agent's capabilities.": "搜索并发现自定义扩展，以拓展智能体的能力。",
    "Search automations...": "搜索自动化任务...",
    "Search customizations...": "搜索自定义扩展...",
    "Search Europe PMC for scientific literature and download open-access full texts and PDFs. Retrieve full-text XML/plain text by PMCID, get citation lists and bibliography.": "在 Europe PMC 中搜索科学文献并下载开放获取全文与 PDF。支持按 PMCID 获取全文 XML/纯文本，以及检索引用列表与参考文献。",
    "Search for scientific papers, preprints, and publications on arXiv. Extract metadata, abstracts, and download full-text PDFs or HTML versions of papers. Use when the user asks to find research papers, literature, or specific arXiv IDs.": "在 arXiv 上搜索科学论文、预印本和出版物。支持提取元数据与摘要，并下载论文的全文 PDF 或 HTML 版本。",
    "Search plugins...": "搜索插件...",
    "Search PubMed for scientific literature, including published clinical trials. Fetch abstracts and full text. Link published research to biological databases (gene, protein, nucleotide, PubChem) to discover associations between papers and specific compounds or genes. Verify medical spelling, match raw citations, and cache result sets for bulk processing. Interfaces NCBI E-utilities and PMC BioC APIs.": "在 PubMed 中搜索科学文献（含已发表的临床试验），获取摘要与全文，并将已发表研究关联至生物数据库（基因、蛋白质、核苷酸、PubChem）以发现论文与特定化合物或基因之间的关联。",
    "Search tool for modern web development best practices. MANDATORY: Execute FIRST for all HTML/CSS and clientside JS tasks. Do NOT skip — web APIs evolve rapidly and training weights contain obsolete patterns. Trigger immediately for: - UI/Layout: Modals, dialogs, popovers, Glassmorphism/backdrop-filters, anchor positioning, container queries, :has(), :user-valid. - Scroll/Motion: View Transitions, Scroll-driven animations, scroll parallax/reveals. - Performance: CWV (LCP, INP), content-visibility, Fetch Priority, image optimization. - System/APIs: Local filesystem access, WebUSB, WebSockets sync, WebAssembly widgets. - Frameworks: Adapting layout/styles in React, Vue, Angular. - General Frontend: Forms, autofill, advanced inputs, custom scrollbars, modern component states, etc. DO NOT trigger for: - Backend: Database SQL, ORMs, Express API routes. - Pipelines: CI/CD deployment, Docker, Actions. - Generic: Local scripts (Python/Go tools), ESLint, Git.": "现代 Web 开发最佳实践检索工具。【强制要求】：在执行所有 HTML/CSS 与客户端 JS 任务前必须首先运行此工具，切勿跳过，以避免使用过时的 Web API 模式。",
    "Search tool for modern web development best practices. MANDATORY: Execute FIRST for all HTML/CSS and clientside JS tasks. Do NOT skip — web APIs evolve rapidly and training weights contain obsolete patterns. Trigger immediately for: - UI/Layout: Modals, dialogs, popovers, Glassmorphism/backdrop-filters, anchor positioning, container queries, `:has()`, `:user-valid`. - Scroll/Motion: View Transitions, Scroll-driven animations, scroll parallax/reveals. - Performance: CWV (LCP, INP), content-visibility, Fetch Priority, image optimization. - System/APIs: Local filesystem access, WebUSB, WebSockets sync, WebAssembly widgets. - Frameworks: Adapting layout/styles in React, Vue, Angular. - General Frontend: Forms, autofill, advanced inputs, custom scrollbars, modern component states, etc. DO NOT trigger for: - Backend: Database SQL, ORMs, Express API routes. - Pipelines: CI/CD deployment, Docker, Actions. - Generic: Local scripts (Python/Go tools), ESLint, Git.": "现代 Web 开发最佳实践检索工具。【强制要求】：在执行所有 HTML/CSS 与客户端 JS 任务前必须首先运行此工具，切勿跳过，以避免使用过时的 Web API 模式。",
    "Searches for homologous protein sequences using MMseqs2 (fast, default) or BLAST (comprehensive, fallback). Trigger this whenever the user provides a protein sequence or FASTA file and asks to find homologues, sequence matches, or wants to infer protein function based on sequence similarity, but not when the user wants to infer protein function based on structural similarity.": "使用 MMseqs2（快速默认）或 BLAST（全面兜底）搜索同源蛋白质序列。当用户提供蛋白质序列或 FASTA 文件并希望查找同源物、序列匹配或基于序列相似性推断蛋白质功能时触发。",
    "Searching Agent Market...": "正在搜索智能体市场...",
    "Security Notice & Data Use": "安全声明与数据使用",
    "See more results": "查看更多结果",
    "Select a workspace to save agent scripts to your workspace.": "选择一个工作区以保存智能体脚本。",
    "Select one of the": "选择以下",
    "Sent Message": "已发送消息",
    "Sets up Google Cloud Lakehouse federated catalogs to remote Iceberg REST Catalogs. Currently supported catalogs: Databricks Unity, AWS Glue. Supported clouds hosting those catalogs: GCP, AWS. The primary use case is connecting to remote data to query it from GCP engines (BigQuery, Spark). Examples of when to use this: \"federate my lakehouse catalog to databricks\", \"query data in databricks\", \"query data in s3\", \"connect to aws glue\". Do NOT use for direct remote database SQL execution (e.g., Databricks SQL) or managing remote clusters and infrastructure (e.g., Databricks clusters, AWS Glue jobs).": "配置连接到远程 Iceberg REST 目录（如 Databricks Unity、AWS Glue）的 Google Cloud Lakehouse 联邦目录，以便从 GCP 引擎（BigQuery、Spark）查询远程数据。",
    "Sets up, manages, queries, and configures Cloud Firestore databases (Standard/Enterprise edition), including data modeling, security rules, indexes, and SDK integrations (Web, Python, iOS, Android, Flutter). Use when creating/listing Firestore databases, defining data models/indexes, writing SDK queries, or integrating Firestore SDKs. For authoring or modifying Firestore Security Rules (firestore.rules), delegate to the firestore-rules-author subagent if subagent delegation is available, or use firestore-rules-creation otherwise. Don't use for Firebase Hosting, Data Connect, Auth, Storage/GCS, Crashlytics, Functions, or BigQuery.": "配置、管理、查询和设置 Cloud Firestore 数据库（标准版/企业版），涵盖数据建模、安全规则、索引以及多平台 SDK 集成（Web、Python、iOS、Android、Flutter）。",
    "Setup required": "需要配置",
    "Show more results on Agent Market": "在智能体市场中显示更多结果",
    "side pane": "侧边栏面板",
    "Side pane": "侧边栏面板",
    "Side Pane": "侧边栏面板",
    "Side Pane UI Available": "侧边面板界面可用",
    "Sign out": "退出登录",
    "Sign out of this server?": "确定要退出登录此服务器吗？",
    "Skill deletion is not available.": "技能删除功能不可用。",
    "Skill for converting an installed Firebase Extension (or extension source) into a standalone Cloud Functions for Firebase codebase or publishable npm package, including V1 to V2 trigger upgrades, lifecycle hooks, and declarative security": "将已安装的 Firebase 扩展（或扩展源码）转换为独立的 Cloud Functions for Firebase 代码库或可发布的 npm 包，涵盖 V1 至 V2 触发器升级、生命周期钩子与声明式安全配置。",
    "Skills & Rules": "技能与规则",
    "skills and rules": "技能与规则",
    "Skills are instructions that extend what Agent can do.": "技能是用于拓展智能体能力边界的指令集合。",
    "Skills Configuration Error:": "技能配置错误：",
    "Skills providing tailored instructions for happy path Dart and Flutter development workflows": "为 Dart 与 Flutter 标准开发工作流提供量身定制指导的技能集合",
    "Skills providing tailored instructions for happy path Dart and Flutter development workflows.": "为 Dart 与 Flutter 标准开发工作流提供量身定制指导的技能集合。",
    "Specialized suite of skills for data engineers and database practitioners on Google Cloud": "专为 Google Cloud 上的数据工程师与数据库从业者打造的专业技能套件",
    "Specialized suite of skills for data engineers and database practitioners on Google Cloud.": "专为 Google Cloud 上的数据工程师与数据库从业者打造的专业技能套件。",
    "Start Automation": "启动自动化任务",
    "Start Extension": "启动扩展",
    "Stay Tuned": "敬请期待",
    "Stores, retrieves, and manages data as objects in Cloud Storage (Google Cloud Storage, or GCS) buckets. Use when you need to interact with Cloud Storage — create or configure buckets, upload, download, stream, or transfer data, organize objects with folders, generate signed URLs, control access (IAM, ACLs, public access prevention), set storage classes and tiering (Standard, Nearline, Coldline, Archive), manage cost and lifecycle, protect data (versioning, encryption/CMEK, retention and Bucket Lock, object holds, soft delete), host static websites, trigger Pub/Sub notifications on object changes, mount buckets as a file system (gcsfuse), or optimize storage performance at any scale. Covers the gcloud storage / gsutil CLI, JSON and XML APIs, client libraries, Terraform, and Cloud Storage MCP servers. Don't use for block storage (Persistent Disk), data warehousing/analytics (BigQuery), or databases (Cloud SQL, Spanner, Bigtable, Firestore).": "在 Cloud Storage (GCS) 存储桶中将数据作为对象进行存储、检索与管理。涵盖创建与配置存储桶、上传下载与流式传输、签名 URL、IAM/ACL 访问控制、存储类别与生命周期管理、数据保护、静态网站托管及 gcsfuse 挂载优化。",
    "Stream and control": "流式传输与控制",
    "Target Tools:": "目标工具：",
    "Task Logs": "任务日志",
    "Terminal commands the agent can execute.": "智能体可执行的终端命令。",
    "Terms and Privacy:": "条款与隐私：",
    "The browser subagent has been disabled by your administrator. Contact your administrator to enable browser use.": "浏览器子智能体已被您的管理员禁用。请联系您的管理员以启用浏览器功能。",
    "There are currently no Build with": "当前暂无可用的 Build with",
    "There are currently no Build with Antigravity plugins available.": "当前暂无可用的 Build with Antigravity 插件。",
    "There are currently no Build with Google plugins available.": "当前暂无可用的 Build with Google 插件。",
    "There are no customizations enabled.": "当前未启用任何自定义扩展。",
    "These MCP allowlist rules are enforced by your organization's administrator.": "这些 MCP 允许名单规则由您所在组织的管理员强制执行。",
    "These servers need you to sign in before the agent can use their tools.": "这些服务器需要您先登录，然后智能体才能使用其工具。",
    "This automation is currently stopped. Events and stdout streams will appear here once started.": "此自动化任务当前已停止。启动后，事件与标准输出流将显示在此处。",
    "This extension is currently stopped. Events and stdout streams will appear here once started.": "此扩展当前已停止。启动后，事件与标准输出流将显示在此处。",
    "This is a preview of the plugin's source. Nothing below is active until you install it.": "以下是该插件源码的预览。在您安装此插件之前，下方内容均不会生效。",
    "This plugin is disabled, so nothing shown below is active. Enable it above to use it.": "此插件已禁用，因此下方显示的内容均未生效。请在上方启用该插件以使用它。",
    "This plugin provides a specialized suite of skills for data engineers and database practitioners working on Google Cloud. It acts as an expert assistant, allowing you to use natural language prompts in your preferred coding agent to architect complex data pipelines, transform data with dbt, write Spark and BigQuery SQL notebooks, and orchestrate end-to-end workflows across GCP's data ecosystem.": "此插件为在 Google Cloud 上工作的数据工程师和数据库从业者提供专业技能套件。它充当专家助手，支持在您偏好的编码智能体中使用自然语言提示词来设计复杂数据流水线、使用 dbt 转换数据、编写 Spark 与 BigQuery SQL 笔记本，并在 GCP 数据生态系统中编排端到端工作流。",
    "This project was created for": "此项目创建用于",
    "This server needs you to sign in before the agent can use its tools.": "此服务器需要您先登录，然后智能体才能使用其工具。",
    "This skill guides the use of Jupyter notebooks for data analysis, exploration, and visualization, particularly with BigQuery. It outlines best practices for notebook execution and validation (supporting both cell-by-cell execution and full notebook generation depending on tool availability), library installation, and structuring notebooks for clarity. It also covers specific rules for data cleaning, plotting, and integrating with BigQuery SQL and machine learning workflows. Relevant when any of the following conditions are true: 1. The user request involves a data analysis, data exploration, data visualization, or data insights task that requires multiple steps, queries, or visualizations to answer. 2. The user explicitly requests a notebook (.ipynb). 3. You are creating, editing, or executing cells in a Jupyter notebook. 4. You need to query BigQuery from within a notebook. DO NOT use the Python BigQuery client library; instead, you MUST use the %%bqsql magics explained in this skill.": "指导使用 Jupyter 笔记本进行数据分析、探索与可视化（特别是结合 BigQuery）。涵盖单元格执行与验证、库安装、数据清洗、绘图规范，并要求使用 %%bqsql 魔法命令查询 BigQuery。",
    "This skill guides the use of Jupyter notebooks for data analysis, exploration, and visualization, particularly with BigQuery. It outlines best practices for notebook execution and validation (supporting both cell-by-cell execution and full notebook generation depending on tool availability), library installation, and structuring notebooks for clarity. It also covers specific rules for data cleaning, plotting, and integrating with BigQuery SQL and machine learning workflows. Relevant when any of the following conditions are true: 1. The user request involves a data analysis, data exploration, data visualization, or data insights task that requires multiple steps, queries, or visualizations to answer. 2. The user explicitly requests a notebook (.ipynb). 3. You are creating, editing, or executing cells in a Jupyter notebook. 4. You need to query BigQuery from within a notebook. DO NOT use the Python BigQuery client library; instead, you MUST use the `%%bqsql` magics explained in this skill.": "指导使用 Jupyter 笔记本进行数据分析、探索与可视化（特别是结合 BigQuery）。涵盖单元格执行与验证、库安装、数据清洗、绘图规范，并要求使用 `%%bqsql` 魔法命令查询 BigQuery。",
    "This skill helps the agent generate or update orchestration pipeline definitions for Google Cloud Composer to initialize orchestration pipeline or update the orchestration definition for orchestration of various data pipelines, like dbt pipelines, notebooks, Spark jobs, Dataform, Python scripts or inline BigQuery SQL queries. This skill also helps deploy and trigger orchestration pipelines.": "协助智能体生成或更新 Google Cloud Composer 的编排流水线定义，以初始化、更新、部署和触发涵盖 dbt、笔记本、Spark 作业、Dataform、Python 脚本或内联 BigQuery SQL 的各类数据编排流水线。",
    "This skill is installed in your workspace": "此技能已安装在您的工作区中",
    "Try out early-stage features before they ship. These may be changed or removed at any time. These features are experimental, and we make no guarantees about performance or functionality.": "在早期功能正式发布前抢先体验。这些功能随时可能变更或移除。它们属于实验性功能，我们对其性能或功能完整性不做任何保证。",
    "UI extension": "UI 扩展",
    "UI Extension (AuxPane)": "界面扩展 (侧边辅助面板)",
    "UI extensions": "界面扩展",
    "UI plugin": "UI 插件",
    "UI Plugin Navigation": "UI 插件导航",
    "UI plugins": "UI 插件",
    "UI Plugins": "界面插件",
    "Unknown Server": "未知服务器",
    "Untitled project": "未命名项目",
    "URLs the agent can actuate on in this workspace.": "智能体在此工作区内可执行交互操作的 URL。",
    "URLs the agent can actuate on using the browser.": "智能体可使用浏览器执行交互操作的 URL。",
    "URLs the agent can read or open in the browser.": "智能体可在浏览器中读取或打开的 URL。",
    "URLs the agent can read or open in this workspace.": "智能体在此工作区内可读取或打开的 URL。",
    "Use `LayoutBuilder`, `MediaQuery`, or `Expanded/Flexible` to create a layout that adapts to different screen sizes. Use when you need the UI to look good on both mobile and tablet/desktop form factors.": "使用 `LayoutBuilder`、`MediaQuery` 或 `Expanded/Flexible` 创建自适应不同屏幕尺寸的响应式布局，确保界面在手机、平板和桌面端均具备良好的视觉表现。",
    "Use LayoutBuilder, MediaQuery, or Expanded/Flexible to create a layout that adapts to different screen sizes. Use when you need the UI to look good on both mobile and tablet/desktop form factors.": "使用 LayoutBuilder、MediaQuery 或 Expanded/Flexible 创建自适应不同屏幕尺寸的响应式布局，确保界面在手机、平板和桌面端均具备良好的视觉表现。",
    "Use switch expressions and pattern matching where appropriate": "在适当的场景下使用 Dart 的 switch 表达式与模式匹配语法。",
    "Use the `http` package to execute GET, POST, PUT, or DELETE requests. Use when you need to fetch from or send data to a REST API.": "使用 `http` 包执行 GET、POST、PUT 或 DELETE 网络请求。适用于需要从 REST API 获取数据或向其发送数据的场景。",
    "Use the http package to execute GET, POST, PUT, or DELETE requests. Use when you need to fetch from or send data to a REST API.": "使用 http 包执行 GET、POST、PUT 或 DELETE 网络请求。适用于需要从 REST API 获取数据或向其发送数据的场景。",
    "Use this skill for generative video editing, text-to-video, image-referenced video generation, first-frame-to-video, first-and-last-frame transitions, and video extensions using Gemini Omni 1.1 Flash (gemini-omni-1.1-flash) via the official google-genai SDK. Includes workflows for pre-processing/optimizing high-resolution or long source videos with ffmpeg, stripping audio for full sound regeneration, and handling turn-by-turn video editing and parallel execution.": "通过官方 google-genai SDK 使用 Gemini Omni 1.1 Flash (gemini-omni-1.1-flash) 进行生成式视频编辑、文生视频、图生视频、首尾帧过渡与视频延展，包含使用 ffmpeg 预处理高分辨率长视频及多轮视频编辑工作流。",
    "Use this skill when building real-time, bidirectional streaming applications with the Gemini Live API, or migrating legacy Live models (2.0/2.5/3.1) to Gemini 3.8 Live. Covers WebSocket-based audio/video/text streaming, voice activity detection (VAD), background reasoning (extended thinking), asynchronous function calling, session management, ephemeral tokens, live transcription, and live translation. SDKs covered - google-genai (Python), @google/genai (JavaScript/TypeScript).": "当使用 Gemini Live API 构建实时双向流式应用程序，或将旧版 Live 模型 (2.0/2.5/3.1) 迁移到 Gemini 3.8 Live 时使用此技能。涵盖基于 WebSocket 的音频/视频/文本流式传输、语音活动检测 (VAD)、后台推理（深度思考）、异步函数调用、会话管理、临时 Token、实时转录与实时翻译。支持的 SDK：google-genai (Python)、@google/genai (JavaScript/TypeScript)。",
    "Use this skill when building real-time, bidirectional streaming applications with the Gemini Live API. Covers WebSocket-based audio/video/text streaming, voice activity detection (VAD), native audio features, function calling, session management, ephemeral tokens for client-side auth, live translation, and all Live API configuration options. SDKs covered - google-genai (Python), @google/genai (JavaScript/TypeScript).": "使用 Gemini Live API 构建实时双向流式应用时使用此技能。涵盖基于 WebSocket 的音视频与文本流、语音活动检测 (VAD)、原生音频特性、函数调用、会话管理、客户端临时令牌、实时翻译及全套配置选项。",
    "Use this skill when writing code that calls the Gemini API for text generation, multi-turn chat, multimodal understanding, image generation, video generation, speech generation (TTS), voice design, voice replication, streaming responses, background research tasks, function calling, structured output, or migrating from the old generateContent API. Covers SDK usage and best practices for Gemini models and agents in Python and TypeScript.": "当编写调用 Gemini API 进行文本生成、多轮对话、多模态理解、图像生成、视频生成、语音合成 (TTS)、声音设计、声音复制、流式响应、后台研究任务、函数调用 (Function Calling)、结构化输出或从旧版 generateContent API 迁移时使用此技能。涵盖 Python 与 TypeScript 中 Gemini 模型与智能体的 SDK 用法和最佳实践。",
    "Use this skill when writing code that calls the Gemini API for text generation, multi-turn chat, multimodal understanding, image generation, video generation, streaming responses, background research tasks, function calling, structured output, or migrating from the old generateContent API. Covers SDK usage and best practices for Gemini models and agents in Python and TypeScript.": "编写调用 Gemini API 的代码时使用此技能，涵盖文本生成、多轮对话、多模态理解、图像生成、视频生成、流式响应、后台研究任务、函数调用、结构化输出或从旧版 generateContent API 迁移，提供 Python 与 TypeScript SDK 最佳实践。",
    "Use when needing clinical significance, pathogenicity classifications (e.g., Pathogenic, Benign, VUS), clinical evidence rationales, or finding \"hard positive\" benchmark controls for human genomic variants.": "查询人类基因组变异的临床意义、致病性分类（如致病、良性、意义未明变异 VUS）、临床证据依据或基准对照位点时使用此技能。",
    "Use when you want to look up, map, and search for short genetic variants (SNPs, indels) in NCBI's dbSNP database. Resolves between rsIDs, genomic coordinates in VCF format, and HGVS strings. For an rsID, returns variant type, gene associations, clinical significance, allele frequencies, and genomic coordinates (GRCh38).": "在 NCBI 的 dbSNP 数据库中查找、映射和搜索短遗传变异（SNP、Indel）。支持在 rsID、VCF 基因组坐标与 HGVS 字符串之间解析转换，并返回变异类型、基因关联、临床意义、等位基因频率及 GRCh38 坐标。",
    "Use when you want to retrieve quantitative RNA expression data and variant eQTL information from the GTEx (Genotype-Tissue Expression) Project across 54 non-diseased tissue sites.": "从 GTEx（基因型-组织表达）项目中检索涵盖 54 个非病变组织部位的定量 RNA 表达数据与变异 eQTL 信息。",
    "Use when you want to retrieve semi-quantitative protein expression and spatial localisation data from the Human Protein Atlas (HPA).": "从人类蛋白质图谱 (HPA) 数据库中检索半定量蛋白质表达与空间亚细胞定位数据。",
    "Use when you want to search for or download experimentally-determined 3D structures for biomolecules (proteins, nucleic acids, bound ligands). Supports searching by sequence similarity, structure similarity, chemical and other attributes. Also use to get metadata about biomolecular structure experiments.": "搜索或下载实验测定的生物大分子（蛋白质、核酸、结合配体）3D 结构。支持按序列相似性、结构相似性、化学属性进行搜索，并获取生物大分子结构实验元数据。",
    "Uses Chrome DevTools MCP and documentation to troubleshoot connection and target issues. Trigger this skill when list_pages, new_page, or navigate_page fail, or when the server initialization fails.": "使用 Chrome DevTools MCP 与文档排查连接及目标页面问题。当 list_pages、new_page 或 navigate_page 失败，或服务初始化失败时触发此技能。",
    "Uses Chrome DevTools MCP for accessibility (a11y) debugging and auditing based on web.dev guidelines. Use when testing semantic HTML, ARIA labels, focus states, keyboard navigation, tap targets, and color contrast.": "基于 web.dev 指南使用 Chrome DevTools MCP 进行无障碍 (a11y) 调试与审计。适用于测试语义化 HTML、ARIA 标签、焦点状态、键盘导航、触控目标及色彩对比度。",
    "Uses Chrome DevTools via MCP for efficient debugging, troubleshooting and browser automation. Use when debugging web pages, automating browser interactions, analyzing performance, or inspecting network requests. This skill does not apply to --slim mode (MCP configuration).": "通过 MCP 使用 Chrome DevTools 进行高效调试、故障排查与浏览器自动化。适用于调试网页、自动化浏览器交互、分析性能或检查网络请求。此技能不适用于 --slim 精简模式。",
    "Uses Chrome DevTools via MCP for efficient debugging, troubleshooting and browser automation. Use when debugging web pages, automating browser interactions, analyzing performance, or inspecting network requests. This skill does not apply to `--slim` mode (MCP configuration).": "通过 MCP 使用 Chrome DevTools 进行高效调试、故障排查与浏览器自动化。适用于调试网页、自动化浏览器交互、分析性能或检查网络请求。此技能不适用于 `--slim` 精简模式。",
    "Uses get_runtime_errors and lsp to fetch an active stack trace, locate the failing line, apply a fix, and verify resolution via hot_reload.": "使用 get_runtime_errors 和 LSP 获取当前调用栈轨迹、定位报错行、应用修复方案并通过 hot_reload 验证修复结果。",
    "Using the Antigravity Python SDK to build AI agents": "使用 Antigravity Python SDK 构建 AI 智能体",
    "Using the Antigravity Python SDK to build AI agents.": "使用 Antigravity Python SDK 构建 AI 智能体。",
    "Using the Google Antigravity Python SDK to build AI agents.": "使用 Google Antigravity Python SDK 构建 AI 智能体。",
    "View Logs": "查看日志",
    "Visualize, analyze, and render protein and molecular structures using PyMOL. Use when the user wants to create images of protein structures, perform structural alignments or superposition, measure distances or contacts, highlight binding sites or active site residues, color by B-factor/pLDDT, or analyze protein-ligand interactions. Do not use for docking, molecular dynamics, or sequence-only analysis.": "使用 PyMOL 可视化、分析和渲染蛋白质与分子结构。适用于生成蛋白质结构图像、执行结构比对或叠合、测量距离或接触位点、高亮结合位点、按 B 因子/pLDDT 着色或分析蛋白质-配体相互作用。",
    "When enabled, 'Explain and Fix' actions will continue in the current conversation instead of starting a new one.": "启用后，“解释并修复”操作将在当前会话中继续进行，而不会开启新会话。",
    "When enabled, Agent will use IDE's shell integration to detect and report terminal command execution.": "启用后，智能体将使用 IDE 的 Shell 集成来检测并报告终端命令的执行情况。",
    "When enabled, Antigravity will play a sound when Agent finishes generating a response.": "启用后，当智能体完成回复生成时，Antigravity 将播放提示音。",
    "When enabled, the agent will be able to access its knowledge base to inform its responses and automatically generate knowledge items in the background.": "启用后，智能体将能够访问其知识库以辅助生成回复，并在后台自动提炼知识条目。",
    "When enabled, the Changes Overview toolbar will automatically expand when Agent finishes generating a response.": "启用后，当智能体完成回复生成时，“变更概览”工具栏将自动展开。",
    "work with Google developer products": "协同使用 Google 开发者产品",
    "work with Google developer products.": "协同使用 Google 开发者产品。",
    "work with Google developer products. You can always change your choices in Settings.": "协同使用 Google 开发者产品。您随时可以在“设置”中更改选择。",
    "Workflow for fixing package version conflicts. Use this when `pub get` fails due to incompatible package versions.": "解决依赖包版本冲突的标准工作流。当因包版本不兼容导致 `pub get` 失败时使用此技能。",
    "Workflow for fixing package version conflicts. Use this when pub get fails due to incompatible package versions.": "解决依赖包版本冲突的标准工作流。当因包版本不兼容导致 pub get 失败时使用此技能。",
    "Workflows are being deprecated in favor of skills. You can use the agent to migrate your workflows.": "工作流 (Workflows) 正在逐步弃用并由技能 (Skills) 取代。您可以使用智能体迁移现有的工作流。",
    "Workspace Creation": "工作区创建",
    "Write and organize unit tests for functions, methods, and classes using `package:test`. Use when creating new logic or fixing bugs to ensure code remains correct and regression-free.": "使用 `package:test` 为函数、方法和类编写与组织单元测试。适用于编写新业务逻辑或修复 Bug 时确保代码正确性并防止回归问题。",
    "Write and organize unit tests for functions, methods, and classes using package:test. Use when creating new logic or fixing bugs to ensure code remains correct and regression-free.": "使用 package:test 为函数、方法和类编写与组织单元测试。适用于编写新业务逻辑或修复 Bug 时确保代码正确性并防止回归问题。",
    "You can always change your choices in Settings": "您随时可以在“设置”中更改选择",
    "You can always change your choices in Settings.": "您随时可以在“设置”中更改选择。",
    "You don't have any custom agents or plugins configured. Create agent scripts in the agents/ directory or add plugins to the plugins/ directory inside your Gemini configuration folder.": "您尚未配置任何自定义智能体或插件。请在您的 Gemini 配置文件夹下的 agents/ 目录中创建智能体脚本，或向 plugins/ 目录中添加插件。",
    "Your agent's ability to execute commands is also controlled by enterprise security policies.": "您的智能体执行命令的能力同样受企业安全策略管控。",
    "Your agent’s ability to execute commands is also controlled by enterprise security policies.": "您的智能体执行命令的能力同样受企业安全策略管控。",
    "How to write and run a dynamic workflow script with the `run_workflow` tool: a Python script that orchestrates many agents with `agent`, `parallel`, `pipeline`, and `phase`. Use when a task splits into many independent or staged pieces of agent work (fan out over files, modules, bugs, or review angles, then aggregate), or when the user asks for a workflow. Don't use for a single delegated task (use a subagent) or for legacy workflow files (see migrate-workflows).": "如何使用 `run_workflow` 工具编写和运行动态工作流脚本：通过 Python 脚本使用 `agent`、`parallel`、`pipeline` 和 `phase` 编排多个智能体。适用于任务可拆分为多个独立或分阶段的智能体子任务（按文件、模块、Bug 或审查维度并发分发后再聚合），或用户明确要求使用工作流时。不适用于单一委派任务（请改用子智能体）或旧版工作流文件（请参阅 migrate-workflows）。",
    "How to write and run a dynamic workflow script with the run_workflow tool: a Python script that orchestrates many agents with agent, parallel, pipeline, and phase. Use when a task splits into many independent or staged pieces of agent work (fan out over files, modules, bugs, or review angles, then aggregate), or when the user asks for a workflow. Don't use for a single delegated task (use a subagent) or for legacy workflow files (see migrate-workflows).": "如何使用 run_workflow 工具编写和运行动态工作流脚本：通过 Python 脚本使用 agent、parallel、pipeline 和 phase 编排多个智能体。适用于任务可拆分为多个独立或分阶段的智能体子任务（按文件、模块、Bug 或审查维度并发分发后再聚合），或用户明确要求使用工作流时。不适用于单一委派任务（请改用子智能体）或旧版工作流文件（请参阅 migrate-workflows）。",
    "Read, create, and manage Google Calendar events. Use when the user shares a calendar.google.com URL, asks what is on their schedule, wants an event found, created, updated, deleted, or moved, wants to RSVP, wants free/busy or scheduling conflicts checked before proposing a time, wants focus time or an out-of-office block created, wants an event quick-added from a phrase or imported from an ICS file, or wants to know where someone is working from and which timezone they are in. Don't use for Gmail, Chat, or Tasks.": "读取、创建和管理 Google Calendar 日程事件。适用于用户分享 calendar.google.com 链接、询问日程安排、查找/创建/更新/删除/移动日程、回复邀请 (RSVP)、在提议时间前检查忙闲状态或日程冲突、创建专注时间或外出时段、通过短语快速添加日程或从 ICS 文件导入日程，或查询工作地点与所在时区。不适用于 Gmail、Chat 或 Tasks。",
    "Read, create, edit, and manage Google Docs. Use when the user shares a docs.google.com URL, asks to summarize or extract content from a doc, wants a doc drafted, edited, formatted, or commented on, wants tables, images, or smart chips inserted, wants markdown imported or synchronized with a doc, or wants a doc exported. Requires a known document ID — use the gdrive skill to search for or locate documents. Don't use for Google Sheets, Slides, or Drive file management.": "读取、创建、编辑和管理 Google Docs 文档。适用于用户分享 docs.google.com 链接、总结或提取文档内容、起草/编辑/排版/评论文档、插入表格/图片/智能芯片、导入或同步 Markdown 内容，或导出文档。需要已知的文档 ID（如需搜索或定位文档请使用 gdrive 技能）。不适用于 Google Sheets、Slides 或 Drive 文件管理。",
    "Browse, search, and manage Google Drive files and folders. Use when the user shares a drive.google.com URL, asks what is in a folder, wants a file found, downloaded, uploaded, updated in place, moved, copied, or renamed, wants a Google file exported to PDF, Markdown, or CSV, wants comments read or added, wants sharing and permissions checked or changed, or wants Drive activity watched. Don't use for editing the contents of a Doc, Sheet, or Slides deck.": "浏览、搜索和管理 Google Drive 云端硬盘文件与文件夹。适用于用户分享 drive.google.com 链接、查看文件夹内容、查找/下载/上传/就地更新/移动/复制/重命名文件、将 Google 文档导出为 PDF/Markdown/CSV、读取或添加评论、检查或更改共享权限，或监控云端硬盘动态。不适用于编辑 Google Docs、Sheets 或 Slides 的正文内容。",
    "Read, write, format, and manage Google Sheets. Use when the user shares a sheets.google.com or docs.google.com/spreadsheets URL, asks to read or summarize spreadsheet data, wants cells written, formatted, sorted, merged, or validated, wants rows/columns inserted or deleted, wants charts, pivot tables, or tables added, wants CSV imported, or wants a spreadsheet created, copied, shared, or exported. Don't use for Google Docs, Slides, or Drive file management.": "读取、写入、格式化和管理 Google Sheets 电子表格。适用于用户分享 sheets.google.com 或 docs.google.com/spreadsheets 链接、读取或汇总表格数据、写入/格式化/排序/合并/校验单元格、插入或删除行列、添加图表/数据透视表/表格、导入 CSV，或创建/复制/共享/导出电子表格。不适用于 Google Docs、Slides 或 Drive 文件管理。",
    "Read, create, and edit Google Slides presentations. Use when creating presentations, when the user shares a slides.google.com URL, asks to summarize or extract content from a deck, wants slides drafted or updated, or wants a presentation exported. Don't use for Google Docs, Sheets, or Drive file management.": "读取、创建和编辑 Google Slides 演示文稿。适用于创建演示文稿、用户分享 slides.google.com 链接、总结或提取幻灯片内容、起草或更新幻灯片，或导出演示文稿。不适用于 Google Docs、Sheets 或 Drive 文件管理。",
    "Check availability, schedule events, and RSVP.": "查看忙闲状态、安排日程并回复邀请 (RSVP)。",
    "Read, draft, and edit docs.": "读取、起草和编辑文档。",
    "Search, upload, download, and share files.": "搜索、上传、下载和共享文件。",
    "Read, write, and format spreadsheets.": "读取、写入和格式化电子表格。",
    "Read, edit, and export presentations.": "读取、编辑和导出演示文稿。",
    "Enable this plugin to use this prompt": "启用此插件以使用该提示词",
    "Install this plugin to use this prompt": "安装此插件以使用该提示词",
    "Add a whole working set at once — a bundle is a curated group of plugins.": "一次性添加整套工作流组合——组合包 (Bundle) 是经过精选的插件集合。",
    "See less in Bundles": "在组合包中收起",
    "See more in Bundles": "在组合包中查看更多",
    "See more in Plugins": "在插件中查看更多",
    "See less in Plugins": "在插件中收起",
    "What's in this bundle": "此组合包包含的内容",
    "Bundles": "组合包",
    "Loading bundle...": "正在加载组合包...",
    "Each plugin can be managed on its own.": "每个插件均可独立管理。",
    "This bundle has no plugins yet.": "此组合包暂未包含任何插件。",
    "Disabled. Open the plugin page to finish setup.": "已禁用。请打开插件页面以完成配置。",
    "Services this plugin connects to on your behalf. Credentials stay on this machine and are only sent to the domains listed.": "此插件代表您连接的外部服务。凭据仅保存在本机，且仅发送至下方列出的域名。",
    "Search all skills on Agent Market…": "在智能体市场中搜索所有技能…",
    "Search skills…": "搜索技能…",
    "Loading skills…": "正在加载技能…",
    "Customizations & Skills": "自定义扩展与技能",
    "Build applications with the Gemini Interactions API and Live API, including text, image, video, and speech generation, managed agents, and real-time multimodal streaming.": "使用 Gemini Interactions API 和 Live API 构建应用，涵盖文本、图像、视频与语音生成、托管智能体以及实时多模态流式传输。",
    "Build applications with the Gemini Interactions API and Live API, including text, image, video, and speech generation, managed agents, and real-time multimodal streaming": "使用 Gemini Interactions API 和 Live API 构建应用，涵盖文本、图像、视频与语音生成、托管智能体以及实时多模态流式传输",
    "AI Credits": "AI 积分",
    "Show in the menu bar when closed. Right-click to quit.": "关闭窗口后仍保留在菜单栏/系统托盘中。右键点击可彻底退出。",
    "AI Credits are used when you've exceeded your model quota. Keep track of your current AI Credits in the": "AI 积分用于超出模型配额时的计费消耗。可在以下位置跟踪您的当前 AI 积分：",
    "Action List background color for the focused item.": "获得焦点项的操作列表背景颜色。",
    "Action List background color.": "操作列表背景颜色。",
    "Action List foreground color for the focused item.": "获得焦点项的操作列表前景文本颜色。",
    "Action List foreground color.": "操作列表前景文本颜色。",
    "Active Model": "当前模型",
    "Active background color of the command center": "命令中心处于活动状态时的背景颜色",
    "Active border color of the command center": "命令中心处于活动状态时的边框颜色",
    "Active foreground color of the command center": "命令中心处于活动状态时的前景文本颜色",
    "Active tab background color in an active group. Tabs are the containers for editors in the editor area. Multiple tabs can be opened in one editor group. There can be multiple editor groups.": "活动编辑器分组中当前活动标签页的背景颜色。标签页是编辑器区域中编辑器的容器，一个编辑器分组中可打开多个标签页，也可以存在多个编辑器分组。",
    "Active tab background color in an unfocused group. Tabs are the containers for editors in the editor area. Multiple tabs can be opened in one editor group. There can be multiple editor groups.": "未聚焦编辑器分组中活动标签页的背景颜色。标签页是编辑器区域中编辑器的容器，一个编辑器分组中可打开多个标签页，也可以存在多个编辑器分组。",
    "Active tab foreground color in an active group. Tabs are the containers for editors in the editor area. Multiple tabs can be opened in one editor group. There can be multiple editor groups.": "活动编辑器分组中当前活动标签页的前景文本颜色。标签页是编辑器区域中编辑器的容器，一个编辑器分组中可打开多个标签页，也可以存在多个编辑器分组。",
    "Active tab foreground color in an unfocused group. Tabs are the containers for editors in the editor area. Multiple tabs can be opened in one editor group. There can be multiple editor groups.": "未聚焦编辑器分组中活动标签页的前景文本颜色。标签页是编辑器区域中编辑器的容器，一个编辑器分组中可打开多个标签页，也可以存在多个编辑器分组。",
    "Active token streaming duration from the language model.": "来自语言模型的活跃 Token 流式传输持续时间。",
    "Add Custom Model": "添加自定义模型",
    "Add Model": "添加模型",
    "Appearance": "外观",
    "Audio attachment": "音频附件",
    "Background color behind matching brackets": "匹配括号后方的背景高亮颜色",
    "Background color for block quotes in text.": "文本中块级引用（Block Quote）的背景颜色。",
    "Background color for code blocks in text.": "文本中代码块（Code Block）的背景颜色。",
    "Browser Viewport Width": "浏览器视口宽度",
    "Claude and GPT models": "Claude 与 GPT 模型",
    "Color Theme": "颜色主题",
    "Configure Models": "配置模型",
    "Configure external tools via Model Context Protocol.": "通过模型上下文协议 (Model Context Protocol) 配置外部工具。",
    "Configure the agent's visual theme and display preferences.": "配置智能体的视觉主题与显示偏好。",
    "Configure the maximum width of the conversation panel.": "配置对话面板的最大显示宽度。",
    "Conversation Width": "对话面板宽度",
    "Dark Theme": "深色主题",
    "Default Model": "默认模型",
    "Dismiss notification": "忽略通知",
    "Display Options": "显示选项",
    "Display and preserve intermediate thinking steps.": "显示并保留中间思考过程步骤。",
    "Editor Font Family": "编辑器字体系列",
    "Editor Font Size": "编辑器字号大小",
    "Editor Settings": "编辑器设置",
    "Enable AI Credit Overages": "启用超额 AI 积分计费",
    "Enable Notifications for Agent": "启用智能体系统通知",
    "Enable Sounds for Agent": "启用智能体提示音",
    "Experimental model. Click to provide feedback or opt out.": "实验性模型。点击提供反馈或退出。",
    "Font Family": "字体系列",
    "Font Ligatures": "连字字体效果",
    "Font Size": "字体大小",
    "Font Weight": "字重（粗细）",
    "Gemini Models": "Gemini 模型",
    "Keyboard Shortcuts": "键盘快捷键设置",
    "Keyboard shortcuts": "快捷键",
    "LAYOUT CONTROLS": "布局控制",
    "Layout Controls": "布局控制",
    "Layout controls": "布局控制",
    "Light Theme": "浅色主题",
    "Manage Models": "管理模型",
    "Manage your model quota and credits.": "管理您的模型配额与积分。",
    "Markdown Artifact Width": "Markdown 产物文档宽度",
    "Model": "模型",
    "Model Aliases": "模型别名",
    "Model Capabilities": "模型能力",
    "Model Configuration": "模型详细配置",
    "Model Credits": "模型积分",
    "Model Provider": "模型提供商",
    "Model Quota": "模型配额",
    "Model Selection": "模型选择",
    "Model Usage": "模型用量",
    "Models": "模型配置",
    "Models & Usage": "模型与用量",
    "Models in this group": "该分组包含的模型",
    "Models within this group": "该分组包含的模型",
    "Monthly Quota": "每月配额",
    "New Editor Window": "新建编辑器窗口",
    "No Model Selected": "未选择模型",
    "Notification": "通知",
    "Notification Settings": "通知设置",
    "Notifications": "通知",
    "Open Keyboard Shortcuts": "打开快捷键设置",
    "Preset": "预设",
    "Purchase Credits": "购买积分",
    "Quota Remaining": "剩余配额",
    "Quota exceeded": "已超出配额",
    "Quota running low": "配额即将耗尽",
    "Record Audio": "录制音频",
    "Record Audio Ctrl+M": "录制音频 Ctrl+M",
    "Record audio": "录制音频",
    "Refresh quota and credits data": "刷新配额与积分数据",
    "Refresh quota and credits data.": "刷新配额与积分数据。",
    "Remove audio": "移除音频",
    "Request Quota": "请求配额",
    "Reset Zoom": "重置缩放",
    "Select Default Model": "选择默认模型",
    "Select Model": "选择模型",
    "Select Model to Send Message": "选择发送消息所用的模型",
    "Select a model using the model selector in the input box": "使用输入框中的模型选择器选择模型",
    "Select another model": "选择其他模型",
    "Shortcuts": "快捷键",
    "Suggestions in Editor": "编辑器内代码补全建议",
    "System Theme": "跟随系统",
    "Table Width": "表格宽度",
    "Terminal Font Family": "终端字体系列",
    "Terminal Font Size": "终端字号大小",
    "Test Model Response": "测试模型响应",
    "Theme": "主题风格",
    "This error is likely temporary. You can prompt the model to try again after some time.": "此错误可能是暂时的。您可以稍后让模型再试一次。",
    "To modify notification settings, open your operating system's system preferences.": "若要修改通知设置，请打开您操作系统的系统设置。",
    "Toggle Editor": "切换编辑器",
    "Toggle Model Selector": "切换模型选择器",
    "Usage & Quota": "用量与配额",
    "View Model Usage": "查看模型用量",
    "When toggled on, Antigravity will use your AI credits to fulfill model requests once you're out of model quota. Antigravity will always use your model quota first before using AI credits.": "开启后，当模型配额耗尽时，Antigravity 将使用您的 AI 积分来完成模型请求。Antigravity 将始终优先消耗模型配额，然后再使用 AI 积分。",
    "You can prompt the model to try again or start a new conversation if the error persists.": "您可以让模型重试，或在错误持续时开始新会话。",
    "Your quota for this model has run out": "您在此模型上的配额已耗尽",
    "Your quota for this model has run out.": "您在此模型上的配额已耗尽。",
    "Your quota for this model is running low": "您在此模型上的剩余配额即将耗尽",
    "Your quota for this model is running low.": "您在此模型上的剩余配额即将耗尽。",
    "Zoom In": "放大",
    "Zoom Level": "界面缩放",
    "Zoom Out": "缩小",
    "select model": "选择模型",
    "External tools the agent can call via Model Context Protocol.": "智能体可通过模型上下文协议 (Model Context Protocol) 调用的外部工具。",
    "Model A": "模型 A",
    "Model B": "模型 B",
    "Model A was better": "模型 A 表现更优",
    "Model B was better": "模型 B 表现更优",
    "Why did you choose this model?": "您为什么选择此模型？",
    "Display": "显示方式",
    "Maximize Width": "最大化宽度",
    "Minimize Width": "最小化宽度",
    "Play a sound when the agent finishes generating a response.": "当智能体完成回复生成时播放提示音。",
    "Show browser notifications when your action is needed or execution finishes.": "当需要您采取操作或执行完成时显示系统通知。",
    "Notification Sounds": "通知提示音",
    "Network Proxy": "网络代理",
    "Configure network proxy settings.": "配置网络代理设置。",
    "Proxy Mode": "代理模式",
    "Direct (no proxy)": "直接连接 (不使用代理)",
    "Proxy URL": "代理服务器地址",
    "Save Proxy Settings": "保存代理设置",
    "Telemetry": "遥测诊断",
    "Diagnostic Data": "诊断数据",
    "Crash Reporting": "崩溃报告",
    "Terminal Shell": "终端 Shell",
    "Language": "语言",
    "Windows Subsystem for Linux": "Windows 的 Linux 子系统 (WSL)",
    "Run the app against a Linux environment. Connecting relaunches the app into the selected WSL distro.": "在 Linux 环境中运行此应用。连接后将把应用重新启动到所选的 WSL 发行版中。",
    "Local Windows environment": "本地 Windows 环境",
    "The app is currently connected to a WSL distro. Reopening locally relaunches it directly on Windows.": "此应用当前已连接到 WSL 发行版。在本地重新打开将直接在 Windows 上重新启动该应用。",
    "Reopen Locally": "在本地重新打开",
    "Connect to WSL": "连接到 WSL",
    "Connect": "连接",
    "Folder is on the Windows filesystem": "文件夹位于 Windows 文件系统上",
    "This folder is on the Windows filesystem. Accessing it from WSL (via /mnt) can be slow — for best performance keep projects inside the WSL filesystem.": "此文件夹位于 Windows 文件系统上。从 WSL 访问该目录（通过 /mnt）可能会较慢 —— 为获得最佳性能，建议将项目保留在 WSL 文件系统内。",
    "WSL distro not found": "未找到 WSL 发行版",
    "Antigravity opened on Windows instead.": "Antigravity 已改为在 Windows 本地打开。",
    "Baseline model quota reached": "已达到基础模型配额上限",
    "Model quota reached": "已达到模型配额上限",
    "Insufficient AI Credits": "AI 积分不足",
    "See Plans": "查看套餐方案",
    "See plans": "查看套餐方案",
    "See plans.": "查看套餐方案。",
    "View Plans": "查看套餐方案",
    "Your AI credits balance is too low to continue.": "您的 AI 积分余额不足，无法继续。",
    "To continue using this model now, enable AI Credit overages.": "若要立即继续使用此模型，请启用超额 AI 积分计费。",
    "You need more AI Credits to send messages.": "您需要更多 AI 积分才能发送消息。",
    "To continue using this model now, purchase more AI Credits.": "若要立即继续使用此模型，请购买更多 AI 积分。",
    "Too many requests, please try again in a bit!": "请求过于频繁，请稍后再试！",
    "Verification required": "需要验证身份",
    "Please verify your account to continue using": "请验证您的账号以继续使用",
    "Agent terminated due to error": "智能体因错误而终止",
    "See our": "请参阅我们的",
    "troubleshooting guide": "故障排查指南",
    "for more help.": "以获取更多帮助。",
    "Error Loading Models": "加载模型出错",
    "No Models Available": "暂无可用模型",
    "No models available": "暂无可用模型",
    "No models are available for your current project or account. Please check your project settings and IAM permissions.": "您当前的项目或账号暂无可用模型。请检查您的项目设置与 IAM 权限。",
    "No quota information available.": "暂无配额信息。",
    "Labs settings have moved": "实验性功能设置已迁移",
    "Labs settings have moved to the Advanced section of General settings.": "实验性功能设置已迁移至“通用设置”中的“高级”板块。",
    "Best of N Models": "Best-of-N 多模型优选",
    "Custom models are only supported on Linux machines.": "自定义模型仅在 Linux 设备上受支持。",
    "Loading models...": "正在加载模型...",
    "Extension Is Loading": "扩展正在加载中",
    "Model selector loading": "模型选择器正在加载",
    "For Antigravity Business consumption options, see": "有关 Antigravity 商业版用量选项，请参阅",
    "Resets in <1m": "不到 1 分钟后重置",
    "Resets in <1m.": "不到 1 分钟后重置。",
    "Open Trajectory Debug View": "打开轨迹调试视图",
    "Copy Trajectory ID": "复制轨迹 ID",
    "Trajectory ID": "轨迹 ID",
    "Cascade ID": "级联会话 ID",
    "Open in Trajectory Dashboard": "在轨迹控制台中打开",
    "Trajectory Telemetry: Redacted (User Content Stripped)": "轨迹遥测诊断：已脱敏（已剥离用户内容）",
    "Trajectory Telemetry: Active (Uploading)": "轨迹遥测诊断：已激活（正在上传）",
    "Parent Conversation": "父级会话",
    "Root Conversation": "根级会话",
    "Use Global Settings": "使用全局设置",
    "Every command requires approval.": "每条命令均需审批。",
    "Ask before sensitive operations.": "在执行敏感操作前询问。",
    "Security agent decides if commands run.": "由安全智能体决定是否运行命令。",
    "Automatically decide if commands run.": "自动决定是否运行命令。",
    "Run all commands without restrictions.": "无限制运行所有命令。",
    "needs a few details from you before it can run.": "运行前需要您补充几项详细信息。",
    "This extension has no declared permissions requiring user input.": "此扩展程序没有需要用户输入的声明权限。",
    "Please fill out all required values to continue.": "请填写所有必填项以继续。",
    "Resolving...": "正在解析...",
    "Next: Review Permissions": "下一步：审查权限",
    "Resolving permissions...": "正在解析权限...",
    "Folders these agents can access.": "这些智能体可以访问的文件夹。",
    "Commands and files these agents can use.": "这些智能体可以使用的命令与文件。",
    "Confirm & Save": "确认并保存",
    "Agents created by": "由",
    "with its own permissions, which you can change anytime in the": "并拥有独立权限，您可以随时在",
    "settings page.": "设置页面中更改。",
    "No matching plugins found.": "未找到匹配的插件。",
    "Demoted": "已降级",
    "Excluded": "已排除",
    "Account connected.": "账号已连接。",
    "Disconnect your account from this plugin?": "确定要断开您的账号与此插件的连接吗？",
    "Disconnect": "断开连接",
    "This plugin requires authentication before the agent can use its tools.": "智能体使用此插件的工具前需要先完成身份验证。",
    "Set up authentication": "设置身份验证",
    "Authenticate": "验证身份",
    "This plugin was force disabled.": "此插件已被强制禁用。",
    "Customization token budget exceeded. Large customizations are excluded from context.": "已超出自定义项 Token 预算上限。体积较大的自定义项已从上下文中排除。",
    "Rules and customization token budgets exceeded. Large rules are demoted to path pointers and large customizations are excluded from context.": "已超出规则与自定义项 Token 预算上限。体积较大的规则已降级为路径指针，体积较大的自定义项已从上下文中排除。",
    "Rules token budget exceeded. Large rules are demoted to path pointers.": "已超出规则 Token 预算上限。体积较大的规则已降级为路径指针。",
    "Telemetry is disabled in Settings": "设置中已禁用遥测诊断",
    "Enable telemetry in Settings before changing per-conversation telemetry.": "请先在“设置”中启用遥测诊断，然后再更改单会话遥测设置。",
    "Telemetry is off for all conversations.": "所有会话的遥测诊断均已关闭。",
    "Telemetry is off for this conversation.": "此会话的遥测诊断已关闭。",
    "Telemetry is turned off in settings": "设置中已关闭遥测诊断",
    "Turn off telemetry for this conversation": "关闭此会话的遥测诊断",
    "Turn on telemetry for this conversation": "开启此会话的遥测诊断",
    "You have a conversation in progress. Updating will interrupt it, and it will automatically resume once the update completes.": "您当前有 1 个正在进行的会话。更新将暂时中断该会话，并在更新完成后自动恢复。",
    "You have a conversation in progress. Updating will cancel it and you'll need to manually restart it.": "您当前有 1 个正在进行的会话。更新将取消该会话，更新后您需要手动重新开始。",
    "Updating will restart the server and apply the latest changes.": "更新将重启后台服务并应用最新更改。",
    "Failed to inspect license for this project": "检查此项目的许可证失败",
    "Your Antigravity use will be associated with provided project. Make sure you trust the project ID before proceeding. Account activity and data may be logged by your organization.": "您的 Antigravity 使用情况将与所提供的项目关联。继续操作前请确保您信任该项目 ID。您的账号活动与数据可能会被所在组织记录。",
    "Select billing model": "选择计费模式",
    "Billing model": "计费模式",
    "Draws from your organization's pooled Gemini Enterprise usage.": "使用您所在组织共享的 Gemini Enterprise 配额池。",
    "Pay as you go": "按量计费",
    "Pay only for the tokens you use, billed through Agent Platform (formerly Vertex AI).": "仅为您实际使用的 Token 付费，通过 Agent Platform（原 Vertex AI）计费。",
    "Back to licenses": "返回许可证列表",
    "Choose a license": "选择许可证",
    "Available licenses": "可用许可证",
    "Other License": "其他许可证",
    "Forward": "前进",
    "Open in external browser": "在外部浏览器中打开",
    "New Browser": "新建浏览器",
    "Open in Built-in Browser": "在内置浏览器中打开",
    "Embedded web preview": "内嵌网页预览",
    "Toggle file diff": "切换文件差异视图",
    "Archived Only": "仅已归档",
    "Visit": "访问",
    "Legal Help": "法律帮助",
    "to ask for content changes for legal reasons.": "以出于法律原因申请内容变更。",
    "This conversation is in a different workspace.": "此会话位于其他工作区中。",
    "This project is associated with a different workspace.": "此项目关联了其他工作区。",
    "Show less": "收起",
    "Customize sections": "自定义分组",
    "Sidecar feature is not available.": "Sidecar 辅助容器功能不可用。",
    "[/automation](slashCommand;automation) Guide me through creating an automated task": "[/automation](slashCommand;automation) 引导我创建一项自动化任务",
    "Hide Thumbnail Sidebar": "隐藏缩略图侧边栏",
    "Show Thumbnail Sidebar": "显示缩略图侧边栏",
    "Toggle Thumbnails": "切换缩略图",
    "Exit Fullscreen": "退出全屏",
    "Enter Fullscreen": "进入全屏",
    "Download PDF": "下载 PDF",
    "Disable Text Selection": "禁用文本选择",
    "Enable Text Selection": "启用文本选择",
    "Switch to Light Mode": "切换至浅色模式",
    "Switch to Dark Mode": "切换至深色模式",
    "Light Mode": "浅色模式",
    "Dark Mode": "深色模式",
    "Fit to Width": "适应页宽",
    "Fit to Page": "适应页面",
    "Fit Mode": "适应模式",
    "Text Selection": "文本选择",
    "More toolbar actions": "更多工具栏操作",
    "More": "更多",
    "Failed to toggle fullscreen mode": "切换全屏模式失败",
    "Initializing...": "正在初始化...",
    "Developer": "开发者",
    "Choose how technical the interface should be.": "选择界面的专业技术复杂度。",
    "Simplified": "精简模式",
    "The agent auto-executes commands matched by an allow list entry.": "智能体会自动执行与允许列表条目匹配的命令。",
    "The agent asks for permission before executing commands matched by a deny list entry.": "智能体在执行与拒绝列表条目匹配的命令前会请求许可。",
    "Give the agent awareness of lint errors created by its edits so it can fix them without explicit prompting.": "让智能体感知其编辑操作产生的代码检查（Lint）错误，以便无需显式提示即可自动修复。",
    "Allow sandboxed commands to make network requests.": "允许沙箱中的命令发起网络请求。",
    "Use the IDE's shell integration to detect and report terminal command execution. When disabled, the agent uses its own shell. Restart the application for this to take effect.": "使用 IDE 的 Shell 集成来检测并报告终端命令执行情况。禁用后，智能体将使用其自带的 Shell。重启应用后生效。",
    "Specifies the agent's behavior when asking for review on artifacts, which are documents it creates to enable a richer conversation experience.": "指定智能体在请求审查产物文档（用于提供更丰富对话体验的生成文档）时的行为方式。",
    "Let the agent access past conversations to inform its responses.": "允许智能体访问历史会话以辅助生成更准确的回复。",
    "Open files in the background if the agent creates or edits them": "当智能体创建或编辑文件时在后台自动打开这些文件",
    "Open the agent panel on window reload": "重新加载窗口时自动打开智能体面板",
    "Custom Context Menus": "自定义右键菜单",
    "Replace the default browser right-click menu with quick actions.": "使用快捷操作菜单替换默认的浏览器右键菜单。",
    "Configure the default width of markdown artifacts.": "配置 Markdown 产物文档的默认显示宽度。",
    "Fill": "铺满",
    "Show suggestions when typing in the editor": "在编辑器中输入代码时显示补全建议",
    "Predict the location of your next edit and navigate you there with a tab keypress.": "预测您下一次编辑的位置，按 Tab 键即可快速跳转至该处。",
    "Quickly add and update imports with a tab keypress.": "按 Tab 键快速添加并更新导入语句（Imports）。",
    "Set the speed of tab suggestions": "设置 Tab 补全建议的触发速度",
    "Slow": "慢速",
    "Highlight newly inserted text after accepting a Tab completion.": "接受 Tab 补全后高亮显示新插入的文本。",
    "Path to the Chrome/Chromium executable. Leave empty for auto-detection.": "Chrome/Chromium 可执行文件的路径。留空则自动探测。",
    "Absolute path to the Chrome/Chromium executable": "Chrome/Chromium 可执行文件的绝对路径",
    "Custom path for the browser user profile directory. Leave empty for default (~/.gemini/antigravity-browser-profile).": "浏览器用户配置目录的自定义路径。留空则使用默认值（~/.gemini/antigravity-browser-profile）。",
    "Browser CDP Port": "浏览器 CDP 端口",
    "Port number for Chrome DevTools Protocol remote debugging. Leave empty for default (9222).": "用于 Chrome DevTools Protocol 远程调试的端口号。留空则使用默认值（9222）。",
    "Show \"Edit\" and \"Chat\" buttons when selecting text in the editor.": "在编辑器中选中文本时显示“编辑”与“对话”浮动按钮。",
    "Include default customizations, such as default skills.": "包含默认自定义项（例如内置默认技能）。",
    "Show a floating notification card when background conversations need your input. Answer questions, approve commands, and grant permissions without leaving your current conversation. Share feedback at go/inline-actions-feedback.": "当后台会话需要您的输入时显示浮动通知卡片。无需离开当前会话即可回答问题、批准命令并授予权限。",
    "Default Workspace VCS": "默认工作区版本控制系统 (VCS)",
    "VCS used when creating a new workspace, including workspaces generated based off your initial prompt.": "创建新工作区（包括根据您的初始提示词生成的工作区）时使用的版本控制系统。",
    "The breakdown below shows token usage from customizations like rules, skills, and MCP. If a budget is exceeded, large rules are demoted to path pointers and large customizations are excluded automatically.": "下方的明细展示了来自规则、技能及 MCP 等自定义扩展的 Token 占用情况。如果超出预算，大型规则将自动降级为路径指针，大型自定义扩展将被自动排除。",
    "Other Customizations": "其他自定义扩展",
    "tokens (": "个 Token (",
    "tokens)": "个 Token)",
    "When Turbo mode is on, the agent will automatically capture screenshots in the Browser without explicit user input. You can toggle this setting in Antigravity's settings.": "开启极速模式 (Turbo) 后，智能体将在浏览器中自动捕获截图而无需用户手动确认。您可以在 Antigravity 设置中切换此选项。",
    "Best of N settings have moved": "多候选对决设置已迁移",
    "Best of N settings have moved to the Advanced section of General settings.": "多候选对决 (Best-of-N) 设置已迁移至“通用”设置下的“高级”区域。",
    "Workspace settings have moved": "工作区设置已迁移",
    "Workspace settings have moved to the Advanced section of General settings.": "工作区设置已迁移至“通用”设置下的“高级”区域。",
    "Open Editor Settings": "打开编辑器设置",
    "To modify editor settings, open Settings within the editor window.": "若要修改编辑器设置，请在编辑器窗口内打开“设置”。",
    "Configure editor-specific behaviors and shortcuts.": "配置编辑器专属行为与快捷键。",
    "Notification Preferences": "通知偏好设置",
    "Manage your notification preferences.": "管理您的通知偏好设置。",
    "Enable Notifications": "启用通知",
    "Get More AI Credits": "获取更多 AI 积分",
    "See Activity": "查看活动记录",
    "Remote Control link": "远程控制链接",
    "Show Remote Control QR code": "显示远程控制二维码",
    "Open in Remote Control": "在远程控制中打开",
    "Continue your work from another device with Remote Control. Scan the QR code or open the link below.": "通过远程控制从其他设备继续您的工作。请扫描二维码或打开下方链接。",
    "Remote Control Issue": "远程控制问题",
    "Describe your Remote Control issue...": "请描述您遇到的远程控制问题...",
    "Remote Control isn't active on this instance. Enable it in": "当前实例尚未启用远程控制。请在",
    ", then reopen this dialog.": "中启用后重新打开此对话框。",
    "Manage your conversations from the companion website.": "从配套网页端管理您的会话。",
    "These settings can only be changed on the computer running the app, not from a remote session.": "这些设置仅可在运行应用的本地计算机上更改，无法在远程会话中修改。",
    "Enter device name...": "输入设备名称...",
    "A label for this computer when you connect from another device. Changing it reconnects.": "从其他设备连接时用于标识此计算机的名称。修改后将重新连接。",
    "QR code": "二维码",
    "Edit Custom Model": "编辑自定义模型",
    "Model Label": "模型名称标签",
    "My Custom Gemini Model": "我的自定义 Gemini 模型",
    "Model URL": "模型 URL",
    "Model URL info": "模型 URL 说明",
    "Model must be available on the Gemini API and use the gemini-api scheme.": "模型必须在 Gemini API 上可用，且使用 gemini-api 协议头。",
    "Max Tokens Until Compaction": "触发压缩前的最大 Token 数",
    "Max tokens until compaction info": "触发压缩前的最大 Token 数说明",
    "Save Configuration": "保存配置",
    "Select Theme": "选择主题",
    "Use theme to be imported with settings": "使用随设置导入的主题",
    "Toggle Between Light/Dark Themes": "切换浅色/深色主题",
    "One Light": "One Light 浅色",
    "Solarized Light": "Solarized Light 浅色",
    "Inherit Editor": "继承编辑器设置",
    "Select the workspace type that will be used for new conversations started with the New Workspace option.": "选择通过“新建工作区”选项发起新会话时默认使用的工作区类型。",
    "Change VCS in General settings, under Advanced": "可在“通用 -> 高级”设置中更改版本控制系统 (VCS)",
    "Connect to Remote Workspace": "连接到远程工作区",
    "Open SSH connection in setup window. When finished, you will be able to select the workspace in the sidebar.": "在设置窗口中打开 SSH 连接。完成后，您将可以在侧边栏中选择该工作区。",
    "Recent Remote Workspaces": "最近的远程工作区",
    "Open Setup Window": "打开设置窗口",
    "Search Recent Workspaces": "搜索最近的工作区",
    "Create project from scratch": "从头创建项目",
    "Set Project Name": "设置项目名称",
    "Select a folder to create a new project.": "选择一个文件夹以创建新项目。",
    "Select a folder.": "选择一个文件夹。",
    "Select a folder": "选择一个文件夹",
    "Instantly create a new project and folder to start building.": "即刻创建新项目和文件夹以开始构建。",
    "Instantly create a new project and folder to start building": "即刻创建新项目和文件夹以开始构建",
    "Create a new project using normal folders and/or citc workspaces.": "使用常规文件夹和/或 CitC 工作区创建新项目。",
    "Create a new project using normal folders and/or citc workspaces": "使用常规文件夹和/或 CitC 工作区创建新项目",
    "Work in a CitC workspace.": "在 CitC 工作区中工作。",
    "Work in a CitC workspace": "在 CitC 工作区中工作",
    "Work in a Cog workspace.": "在 Cog 工作区中工作。",
    "Work in a Cog workspace": "在 Cog 工作区中工作",
    "Work in an ABFS workspace.": "在 ABFS 工作区中工作。",
    "Work in an ABFS workspace": "在 ABFS 工作区中工作",
    "Concierge (Dev only)": "接待员（仅限开发者）",
    "Enter project name...": "输入项目名称...",
    "A project with this name already exists.": "已存在同名项目。",
    "Available workspaces": "可用工作区",
    "No workspaces found": "未找到工作区",
    "Unmount workspace": "卸载工作区",
    "Delete workspace": "删除工作区",
    "Open project settings": "打开项目设置",
    "No projects created": "尚未创建任何项目",
    "You don't have any projects created. Please create a project first.": "您尚未创建任何项目，请先创建一个项目。",
    "Create with Prompt": "使用提示词创建",
    "Settings Unavailable": "设置不可用",
    "Pages currently open in Antigravity's Browser instance are shown below.": "下方展示了当前在 Antigravity 浏览器实例中打开的页面。",
    "Open Browser Setup": "打开浏览器设置",
    "Browser Configuration Required": "需要配置浏览器",
    "The agent will wait for you to install the browser extension.": "智能体将等待您完成浏览器扩展程序的安装。",
    "Launching the browser...": "正在启动浏览器...",
    "Within each group, models share a weekly limit and a 5-hour limit. Quota is consumed proportionally to the cost of the tokens. Thus, limits will last longer with shorter tasks or using more cost-effective models. The 5-hour limit smooths out aggregate demand to fairly distribute global capacity across all users, while your weekly limit is tied directly to your individual tier.": "在每个分组中，各模型共享周限额与 5 小时限额。配额消耗与 Token 成本成正比。因此，执行较短任务或使用性价比更高的模型可延长限额的使用周期。5 小时限额用于平滑总体请求峰值，以在所有用户之间公平分配全球算力；而周限额则直接与您所属的订阅套餐等级挂钩。",
    "Weekly limit": "周限额",
    "5-hour limit": "5 小时限额",
    "5-Hour Limit": "5 小时限额",
    "Weekly Limit": "周限额",
    "Resets in": "重置于",
    "Resets at": "重置于",
    "Quota limits": "配额上限",
    "Adds an Autonomous Mode switch to the modes dropdown below the input box. Turns sent with it on run non-interactively: the agent does not ask questions or request new permissions.": "在输入框下方的模式下拉菜单中添加“自主模式”开关。开启后发送的对话轮次将以非交互方式运行：智能体不会提问或请求新权限。",
    "Set the volume of agent sounds.": "设置智能体提示音的音量。",
    "Chime volume": "提示音音量",
    "Sound": "声音",
    "Choose the experience that fits how you work.": "选择最适合您工作方式的使用体验。",
    "Failed to parse settings. Fix and restart.": "解析设置失败，请修复后重启。",
    "Reset Onboarding": "重置新手引导",
    "Reset NUX": "重置新用户体验 (NUX)",
    "Delete Data Directory": "删除数据目录",
    "To update:": "更新方法：",
    "Go to the machine you are controlling and quit Antigravity. It installs pending updates the next time it starts.": "请前往受控主机并退出 Antigravity。下次启动时将自动安装待处理的更新。",
    "Reload this window.": "重新加载此窗口。",
    "Business Account Sign In": "企业账号登录",
    "Use Advanced SSO Config": "使用高级 SSO 配置",
    "Use this if your admin gave you a WIF config. Paste it below to sign in.": "如果您的管理员提供了工作负载身份联合 (WIF) 配置，请将其粘贴至下方以登录。",
    "Provide Google Cloud Project": "提供 Google Cloud 项目",
    "Your Antigravity use will be associated with provided project.": "您的 Antigravity 使用情况将与所提供的项目关联。",
    "Choose Region": "选择区域",
    "Select License": "选择许可证",
    "Verify that these licenses were provided by your administrator and that you trust the project ID before proceeding. Account activity and data may be logged by your organization.": "继续操作前，请确认这些许可证由您的管理员提供，并且您信任该项目 ID。账号活动和数据可能会被您所在的组织记录。",
    "Contact your administrator to set up Gemini Enterprise for this project": "请联系您的管理员为此项目配置 Gemini Enterprise",
    "Select Billing Model": "选择计费模式",
    "Choose a License": "选择一项许可证",
    "Enter Google Cloud Project Details": "输入 Google Cloud 项目详情",
    "Google Cloud Project ID": "Google Cloud 项目 ID",
    "Loading licenses...": "正在加载许可证...",
    "Pay As You Go": "按量计费 (Pay As You Go)",
    "Managed by Enterprise Gateway": "由企业网关 (Enterprise Gateway) 托管",
    "United States": "美国",
    "Europe": "欧洲"
  },
  "patterns": [
    {
      "regex": "^Thought\\s+for\\s+(\\d+)\\s*h\\s+(\\d+)\\s*m\\s+(\\d+(?:\\.\\d+)?)\\s*s$",
      "replacement": "已思考 $1 小时 $2 分 $3 秒"
    },
    {
      "regex": "^Thought\\s+for\\s+(\\d+)\\s*h\\s+(\\d+)\\s*m$",
      "replacement": "已思考 $1 小时 $2 分钟"
    },
    {
      "regex": "^Thought\\s+for\\s+(\\d+)\\s*h$",
      "replacement": "已思考 $1 小时"
    },
    {
      "regex": "^Thought\\s+for\\s+(\\d+)\\s*m\\s+(\\d+(?:\\.\\d+)?)\\s*s$",
      "replacement": "已思考 $1 分 $2 秒"
    },
    {
      "regex": "^Thought\\s+for\\s+(\\d+)\\s*m$",
      "replacement": "已思考 $1 分钟"
    },
    {
      "regex": "^Thought\\s+for\\s+(\\d+(?:\\.\\d+)?)\\s*s$",
      "replacement": "已思考 $1 秒"
    },
    {
      "regex": "^See all\\s*\\((\\d+)\\)$",
      "replacement": "查看全部 ($1)"
    },
    {
      "regex": "^See all\\s+(\\d+)$",
      "replacement": "查看全部 $1 项"
    },
    {
      "regex": "^\\((\\d+)\\s+subagents?\\)$",
      "replacement": "($1 个子智能体)"
    },
    {
      "regex": "^(\\d+)\\s+subagents?$",
      "replacement": "$1 个子智能体"
    },
    {
      "regex": "^(\\d+)\\s+seconds?\\s+ago$",
      "replacement": "$1 秒前"
    },
    {
      "regex": "^(\\d+)\\s+minutes?\\s+ago$",
      "replacement": "$1 分钟前"
    },
    {
      "regex": "^(\\d+)\\s+hours?\\s+ago$",
      "replacement": "$1 小时前"
    },
    {
      "regex": "^(\\d+)\\s+days?\\s+ago$",
      "replacement": "$1 天前"
    },
    {
      "regex": "^(\\d+)\\s+weeks?\\s+ago$",
      "replacement": "$1 周前"
    },
    {
      "regex": "^(\\d+)\\s+months?\\s+ago$",
      "replacement": "$1 个月前"
    },
    {
      "regex": "^(\\d+)\\s+years?\\s+ago$",
      "replacement": "$1 年前"
    },
    {
      "regex": "^(\\d+)[sS]\\s+ago$",
      "replacement": "$1 秒前"
    },
    {
      "regex": "^(\\d+)[mM]\\s+ago$",
      "replacement": "$1 分钟前"
    },
    {
      "regex": "^(\\d+)[hH]\\s+ago$",
      "replacement": "$1 小时前"
    },
    {
      "regex": "^(\\d+)[dD]\\s+ago$",
      "replacement": "$1 天前"
    },
    {
      "regex": "^(\\d{1,2}:\\d{2})\\s*\\/\\s*(\\d{1,2}:\\d{2})$",
      "replacement": "$1 / $2"
    },
    {
      "regex": "^(\\d{1,2}:\\d{2}:\\d{2})\\s*\\/\\s*(\\d{1,2}:\\d{2}:\\d{2})$",
      "replacement": "$1 / $2"
    },
    {
      "regex": "^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\s+(\\d{1,2})\\s*[-–—]\\s*(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\s+(\\d{1,2})$",
      "replacement": "$1 $2日 - $3 $4日"
    },
    {
      "regex": "^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\s+(\\d{1,2})\\s*[-–—]\\s*(\\d{1,2})$",
      "replacement": "$1 $2日 - $3日"
    },
    {
      "regex": "^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\s+(\\d{1,2}),\\s*(\\d{4}),\\s*(\\d{1,2}:\\d{2}(?::\\d{2})?)\\s*(AM|PM)?$",
      "replacement": "$3年 $1 $2日 $5 $4"
    },
    {
      "regex": "^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\s+(\\d{1,2}),\\s*(\\d{1,2}:\\d{2}(?::\\d{2})?)\\s*(AM|PM)?$",
      "replacement": "$1 $2日 $4 $3"
    },
    {
      "regex": "^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\s+(\\d{1,2}),\\s*(\\d{4})$",
      "replacement": "$3年 $1 $2日"
    },
    {
      "regex": "^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\s+(\\d{1,2})$",
      "replacement": "$1 $2日"
    },
    {
      "regex": "\\bJan\\b(?=\\s+\\d+日)",
      "replacement": "1月"
    },
    {
      "regex": "\\bFeb\\b(?=\\s+\\d+日)",
      "replacement": "2月"
    },
    {
      "regex": "\\bMar\\b(?=\\s+\\d+日)",
      "replacement": "3月"
    },
    {
      "regex": "\\bApr\\b(?=\\s+\\d+日)",
      "replacement": "4月"
    },
    {
      "regex": "\\bMay\\b(?=\\s+\\d+日)",
      "replacement": "5月"
    },
    {
      "regex": "\\bJun\\b(?=\\s+\\d+日)",
      "replacement": "6月"
    },
    {
      "regex": "\\bJul\\b(?=\\s+\\d+日)",
      "replacement": "7月"
    },
    {
      "regex": "\\bAug\\b(?=\\s+\\d+日)",
      "replacement": "8月"
    },
    {
      "regex": "\\bSep\\b(?=\\s+\\d+日)",
      "replacement": "9月"
    },
    {
      "regex": "\\bOct\\b(?=\\s+\\d+日)",
      "replacement": "10月"
    },
    {
      "regex": "\\bNov\\b(?=\\s+\\d+日)",
      "replacement": "11月"
    },
    {
      "regex": "\\bDec\\b(?=\\s+\\d+日)",
      "replacement": "12月"
    },
    {
      "regex": "\\bAM\\b(?=\\s+\\d{1,2}:\\d{2})",
      "replacement": "上午"
    },
    {
      "regex": "\\bPM\\b(?=\\s+\\d{1,2}:\\d{2})",
      "replacement": "下午"
    },
    {
      "regex": "(?<=\\d{1,2}:\\d{2}(?::\\d{2})?\\s*)AM\\b",
      "replacement": "上午"
    },
    {
      "regex": "(?<=\\d{1,2}:\\d{2}(?::\\d{2})?\\s*)PM\\b",
      "replacement": "下午"
    },
    {
      "regex": "^([\\d\\.]+)% of the customization budget is available\\.$",
      "replacement": "$1% 的自定义扩展预算可用。"
    },
    {
      "regex": "^Show (\\d+) breakdowns?$",
      "replacement": "显示 $1 项明细"
    },
    {
      "regex": "^Hide (\\d+) breakdowns?$",
      "replacement": "隐藏 $1 项明细"
    },
    {
      "regex": "^You have used some of your weekly limit, it will fully refresh in (.+)\\.$",
      "replacement": "您已消耗了部分每周额度，将在 $1 后完全重置刷新。"
    },
    {
      "regex": "^You have used some of your 5 hour limit, it will fully refresh in (.+)\\.$",
      "replacement": "您已消耗了部分 5 小时额度，将在 $1 后完全重置刷新。"
    },
    {
      "regex": "^You have hit your 5-hour limit, so the weekly limit does not currently apply\\. Your 5-hour limit will refresh in (.+)\\.$",
      "replacement": "您已达到 5 小时上限，因此每周额度当前不适用。您的 5 小时额度将在 $1 后重置刷新。"
    },
    {
      "regex": "^You have hit your 5-hour limit, it will refresh in (.+)\\. If on a supported paid plan, you can use AI credits in the interim\\.$",
      "replacement": "您已达到 5 小时上限，将在 $1 后重置刷新。如果使用的是支持的付费套餐，您可以在此期间使用 AI 积分。"
    },
    {
      "regex": "(\\d+) days?, (\\d+) hours?",
      "replacement": "$1 天 $2 小时"
    },
    {
      "regex": "(\\d+) hours?, (\\d+) minutes?",
      "replacement": "$1 小时 $2 分钟"
    },
    {
      "regex": "(\\d+) days?",
      "replacement": "$1 天"
    },
    {
      "regex": "(\\d+) hours?",
      "replacement": "$1 小时"
    },
    {
      "regex": "(\\d+) minutes?",
      "replacement": "$1 分钟"
    },
    {
      "regex": "^(\\d+) files? changed$",
      "replacement": "$1 个文件已修改"
    },
    {
      "regex": "^(\\d+) insertions?\\(\\+\\)$",
      "replacement": "$1 行新增(+)"
    },
    {
      "regex": "^(\\d+) deletions?\\(-\\)$",
      "replacement": "$1 行删除(-)"
    },
    {
      "regex": "^Step (\\d+) of (\\d+)$",
      "replacement": "第 $1 步（共 $2 步）"
    },
    {
      "regex": "^Task (\\d+) running$",
      "replacement": "正在运行任务 $1"
    },
    {
      "regex": "^Saved at (\\d{1,2}:\\d{2}(?::\\d{2})?)$",
      "replacement": "已于 $1 保存"
    },
    {
      "regex": "^(\\d+) active subagents?$",
      "replacement": "$1 个运行中的子智能体"
    },
    {
      "regex": "^Created (\\d+) files?$",
      "replacement": "已创建 $1 个文件"
    },
    {
      "regex": "^Modified (\\d+) files?$",
      "replacement": "已修改 $1 个文件"
    },
    {
      "regex": "^Thinking for (\\d+)s$",
      "replacement": "已思考 $1 秒"
    },
    {
      "regex": "^Stopped after (\\d+) steps?$",
      "replacement": "已在 $1 步后停止"
    },
    {
      "regex": "Scan the code to open this device in\\s*",
      "replacement": "扫描二维码在此设备中打开 "
    },
    {
      "regex": "to browse the store, or add a custom server via the MCP config\\.?",
      "replacement": "浏览应用商店，或通过 MCP 配置文件添加自定义服务。"
    },
    {
      "regex": "^(\\d+(?:\\.\\d+)?)% of the customization budget is available\\.?$",
      "replacement": "$1% 的自定义扩展预算可用。"
    },
    {
      "regex": "了解更多关于\\s*Inherit General",
      "replacement": "了解更多关于继承通用设置"
    },
    {
      "regex": "Also includes global settings when working in this project\\.?",
      "replacement": "在此项目中工作时也包含全局设置。"
    },
    {
      "regex": "\\bInherit General\\b",
      "replacement": "继承通用设置"
    },
    {
      "regex": "It requires\\s+([a-zA-Z0-9\\s]+?)\\s+to be installed\\.?",
      "replacement": "需要安装 $1 才能运行。"
    },
    {
      "regex": "(\\d+(?:\\.\\d+)?)% of the customization budget is available",
      "replacement": "$1% 的自定义扩展预算可用"
    },
    {
      "regex": "Configure (?:the )?browser subagent\\s*\\.?",
      "replacement": "配置浏览器子智能体。"
    },
    {
      "regex": "(\\d+(?:\\.\\d+)?)% of the customization budget is available\\.?",
      "replacement": "$1% 的自定义扩展预算可用。"
    },
    {
      "regex": "(?:^|\\s*)of the customization budget is available\\.?",
      "replacement": " 的自定义扩展预算可用。"
    },
    {
      "regex": "Manage project folders,\\s*agent settings,?\\s*and permissions\\.?",
      "replacement": "管理项目文件夹、智能体设置与权限。"
    },
    {
      "regex": "No folders added yet\\.?",
      "replacement": "暂未添加任何文件夹。"
    },
    {
      "regex": "^\\+\\s*Add Folder$",
      "replacement": "+ 添加文件夹"
    },
    {
      "regex": "You have used some of your 5-?hour limit,?\\s*it will fully refresh in (.*?)\\.?$",
      "replacement": "您已消耗了部分 5 小时额度，将在 $1 后完全重置刷新。"
    },
    {
      "regex": "You have used some of your weekly limit,?\\s*it will fully refresh in (.*?)\\.?$",
      "replacement": "您已消耗了部分每周额度，将在 $1 后完全重置刷新。"
    },
    {
      "regex": "You have hit your 5-?hour limit,?\\s*it will refresh in (.*?)\\.?$",
      "replacement": "您已达到 5 小时上限，将在 $1 后重置刷新。"
    },
    {
      "regex": "You have hit your weekly limit,?\\s*it will refresh in (.*?)\\.?$",
      "replacement": "您已达到每周上限，将在 $1 后重置刷新。"
    },
    {
      "regex": "^Permanently delete (.*?)\\.?$",
      "replacement": "永久删除 $1。"
    },
    {
      "regex": "配置浏览器子智能体[。.]\\s*It requires",
      "replacement": "配置浏览器子智能体。需要安装"
    },
    {
      "regex": "Configure (?:the )?browser subagent[。.]\\s*It requires",
      "replacement": "配置浏览器子智能体。需要安装"
    },
    {
      "regex": "\\bIt requires\\b",
      "replacement": "需要安装"
    },
    {
      "regex": "^快捷键\\s*for quick navigation and control\\.?$",
      "replacement": "快捷键，用于快速导航和操作控制。"
    },
    {
      "regex": "^(?:Shortcuts\\s+)?for quick navigation and control\\.?$",
      "replacement": "用于快速导航和操作控制。"
    },
    {
      "regex": "^(?:LAYOUT|Layout)\\s+CONTROLS$",
      "replacement": "布局控制"
    },
    {
      "regex": "Attach (?:a )?screenshot(?:s)?\\s*\\(optional\\)",
      "replacement": "附上屏幕截图（可选）"
    },
    {
      "regex": "Please list the steps to reproduce the issue\\.?",
      "replacement": "请列出重现该问题的具体操作步骤…"
    },
    {
      "regex": "Describe the bug you encountered\\.{0,3}",
      "replacement": "请详细描述您遇到的问题或缺陷…"
    },
    {
      "regex": "^(?:Steps\\s+to\\s+[Rr]eproduce|STEPS\\s+TO\\s+REPRODUCE)\\b",
      "replacement": "重现步骤"
    },
    {
      "regex": "^(Enter|Alt\\+Enter|Shift\\+Enter|Ctrl\\+Enter|Cmd\\+Enter)\\s+Queues after the turn$",
      "replacement": "$1 轮次结束后进入排队"
    },
    {
      "regex": "^(Enter|Alt\\+Enter|Shift\\+Enter|Ctrl\\+Enter|Cmd\\+Enter)\\s+Sends immediately$",
      "replacement": "$1 立即发送"
    },
    {
      "regex": "^(Enter|Alt\\+Enter|Shift\\+Enter|Ctrl\\+Enter|Cmd\\+Enter)\\s+On empty prompt,\\s*sends next in queue$",
      "replacement": "$1 在输入框为空时发送队列中的下一条消息"
    },
    {
      "regex": "^On empty prompt,\\s*sends next in queue$",
      "replacement": "在输入框为空时发送队列中的下一条消息"
    },
    {
      "regex": "^Queues after the turn$",
      "replacement": "轮次结束后进入排队"
    },
    {
      "regex": "^Sends immediately$",
      "replacement": "立即发送"
    },
    {
      "regex": "^Models\\s+within\\s+this\\s+group:?\\s*(.*)$",
      "replacement": "该分组包含的模型：$1"
    },
    {
      "regex": "^Inherits\\s+your\\s+General\\s+settings\\s*在此项目中工作时[。.]?$",
      "replacement": "在此项目中工作时，继承您的“通用”设置。"
    },
    {
      "regex": "^Inherits\\s+(?:your\\s+)?(?:General|default)\\s+settings[。.]?$",
      "replacement": "继承您的“通用”设置。"
    },
    {
      "regex": "\\bInherits\\s+your\\s+General\\s+settings\\b",
      "replacement": "继承您的“通用”设置"
    },
    {
      "regex": "^Your\\s+quota\\s+for\\s+this\\s+model\\s+is\\s+running\\s+low\\.?",
      "replacement": "您在此模型上的剩余配额即将耗尽。"
    },
    {
      "regex": "^Your\\s+quota\\s+for\\s+this\\s+model\\s+has\\s+run\\s+out\\.?",
      "replacement": "您在此模型上的配额已耗尽。"
    },
    {
      "regex": "^View\\s+Usage\\b",
      "replacement": "查看用量明细"
    },
    {
      "regex": "\\bSends\\s+after\\s+agent\\s+finishes\\s+working\\b",
      "replacement": "智能体结束工作后发送"
    },
    {
      "regex": "^Sends\\s+after\\s+agent\\s+finishes\\s+working[。.]?$",
      "replacement": "智能体结束工作后发送"
    },
    {
      "regex": "^Send\\s+Now$",
      "replacement": "立即发送"
    },
    {
      "regex": "^Select\\s+Project(\\s+(?:Ctrl|Cmd|Alt|Shift)\\+[\\w;:,\\/\\+\\-]+)?$",
      "replacement": "选择项目$1"
    },
    {
      "regex": "^Select\\s+Model(\\s+(?:Ctrl|Cmd|Alt|Shift)\\+[\\w;:,\\/\\+\\-]+)?$",
      "replacement": "选择模型$1"
    },
    {
      "regex": "^No\\s+Project$",
      "replacement": "无项目关联"
    },
    {
      "regex": "^Quick\\s+Start$",
      "replacement": "快速入门"
    },
    {
      "regex": "^Copy\\s+项目名称$",
      "replacement": "复制项目名称"
    },
    {
      "regex": "^Copy\\s+Project\\s+Name$",
      "replacement": "复制项目名称"
    },
    {
      "regex": "^Cancel\\s*\\(((?:Ctrl|Cmd|Alt|Shift)\\+[\\w\\+\\-]+)\\)$",
      "replacement": "取消 ($1)"
    },
    {
      "regex": "^Pin$",
      "replacement": "置顶"
    },
    {
      "regex": "^Unpin$",
      "replacement": "取消置顶"
    },
    {
      "regex": "^Good\\s+response$",
      "replacement": "优质回答"
    },
    {
      "regex": "^Bad\\s+response$",
      "replacement": "不佳回答"
    },
    {
      "regex": "^Mark\\s+Unread$",
      "replacement": "标记为未读"
    },
    {
      "regex": "^Mark\\s+Read$",
      "replacement": "标记为已读"
    },
    {
      "regex": "^Copy\\s+Command$",
      "replacement": "复制命令"
    },
    {
      "regex": "^(\\d+)\\s+tasks?\\s+running$",
      "replacement": "$1 个运行中的任务"
    },
    {
      "regex": "^Ran\\s+(.*)$",
      "replacement": "运行 $1"
    },
    {
      "regex": "^Explored\\s+(\\d+)\\s+files?$",
      "replacement": "已浏览探索 $1 个文件"
    },
    {
      "regex": "^Explored\\s+(.*)$",
      "replacement": "已浏览探索 $1"
    },
    {
      "regex": "^Edited\\s+(.*)$",
      "replacement": "已编辑 $1"
    },
    {
      "regex": "^Viewed\\s+(.*)$",
      "replacement": "已查看 $1"
    },
    {
      "regex": "^Ran\\s+(\\d+)\\s+commands?$",
      "replacement": "已运行 $1 个命令"
    },
    {
      "regex": "^Explored\\s+(\\d+)\\s+tasks?$",
      "replacement": "已查看 $1 个任务"
    },
    {
      "regex": "^Timed\\s+(\\d+)\\s+seconds?$",
      "replacement": "已计时 $1 秒"
    },
    {
      "regex": "^Timed\\s+(\\d+)\\s+minutes?$",
      "replacement": "已计时 $1 分钟"
    },
    {
      "regex": "(:?\\s*)Timer has expired$",
      "replacement": "$1定时器已到期"
    },
    {
      "regex": "(\\s+)finished$",
      "replacement": "$1已完成"
    },
    {
      "regex": "^Outside\\s+of\\s+Project$",
      "replacement": "项目外"
    },
    {
      "regex": "^Inside\\s+of\\s+Project$",
      "replacement": "项目内"
    },
    {
      "regex": "^Updated\\s+(.*)$",
      "replacement": "更新于 $1"
    },
    {
      "regex": "^Created\\s+(?!worker\\b)(.*)$",
      "replacement": "创建于 $1"
    },
    {
      "regex": "继承您的“通用”设置\\s+when working in this project\\.?",
      "replacement": "在此项目中工作时，继承您的“通用”设置。"
    },
    {
      "regex": "Inherits\\s+your\\s+[“\\\"]?General[”\\\"]?\\s+settings\\s+when working in this project\\.?",
      "replacement": "在此项目中工作时，继承您的“通用”设置。"
    },
    {
      "regex": "\\bwhen working in this project\\.?",
      "replacement": "在此项目中工作时。"
    },
    {
      "regex": "^Tool\\s+Permissions$",
      "replacement": "工具权限"
    },
    {
      "regex": "^Controls\\s+the\\s+actions\\s+the\\s+agent\\s+can\\s+take[。.]?$",
      "replacement": "控制智能体可以执行的操作。"
    },
    {
      "regex": "^Whether\\s+the\\s+agent\\s+asks\\s+you\\s+to\\s+review\\s+its\\s+documents[。.]?$",
      "replacement": "智能体在创建产物文档时是否请求您审查。"
    },
    {
      "regex": "^Browser\\s+settings\\s+have\\s+moved$",
      "replacement": "浏览器设置已迁移"
    },
    {
      "regex": "Browser\\s+settings\\s+have\\s+moved\\s+to\\s+the\\s+Browser\\s+section\\s+of\\s+General\\s+settings\\.?",
      "replacement": "浏览器设置已迁移至“通用设置”中的“浏览器”板块。"
    },
    {
      "regex": "^Go\\s+to\\s+General\\s+settings$",
      "replacement": "前往通用设置"
    },
    {
      "regex": "^Worked\\s+for\\s+(\\d+)\\s*h\\s+(\\d+)\\s*m\\s+(\\d+(?:\\.\\d+)?)\\s*s$",
      "replacement": "已运行 $1 小时 $2 分 $3 秒"
    },
    {
      "regex": "^Worked\\s+for\\s+(\\d+)\\s*h\\s+(\\d+)\\s*m$",
      "replacement": "已运行 $1 小时 $2 分钟"
    },
    {
      "regex": "^Worked\\s+for\\s+(\\d+)\\s*h$",
      "replacement": "已运行 $1 小时"
    },
    {
      "regex": "^Worked\\s+for\\s+(\\d+)\\s*m\\s+(\\d+(?:\\.\\d+)?)\\s*s$",
      "replacement": "已运行 $1 分 $2 秒"
    },
    {
      "regex": "^Worked\\s+for\\s+(\\d+)\\s*m$",
      "replacement": "已运行 $1 分钟"
    },
    {
      "regex": "^Worked\\s+for\\s+(\\d+(?:\\.\\d+)?)\\s*s$",
      "replacement": "已运行 $1 秒"
    },
    {
      "regex": "^Stopped\\s+after\\s+(\\d+)\\s*h\\s+(\\d+)\\s*m\\s+(\\d+(?:\\.\\d+)?)\\s*s$",
      "replacement": "在 $1 小时 $2 分 $3 秒后停止"
    },
    {
      "regex": "^Stopped\\s+after\\s+(\\d+)\\s*h\\s+(\\d+)\\s*m$",
      "replacement": "在 $1 小时 $2 分钟后停止"
    },
    {
      "regex": "^Stopped\\s+after\\s+(\\d+)\\s*h$",
      "replacement": "在 $1 小时后停止"
    },
    {
      "regex": "^Stopped\\s+after\\s+(\\d+)\\s*m\\s+(\\d+(?:\\.\\d+)?)\\s*s$",
      "replacement": "在 $1 分 $2 秒后停止"
    },
    {
      "regex": "^Stopped\\s+after\\s+(\\d+)\\s*m$",
      "replacement": "在 $1 分钟后停止"
    },
    {
      "regex": "^Stopped\\s+after\\s+(\\d+(?:\\.\\d+)?)\\s*s$",
      "replacement": "在 $1 秒后停止"
    },
    {
      "regex": "^Message\\s+from\\s+(.+)$",
      "replacement": "来自 $1 的消息"
    },
    {
      "regex": "^Executing\\s+task:\\s+(.+)$",
      "replacement": "正在执行任务: $1"
    },
    {
      "regex": "^Record Audio(\\s+Ctrl\\+[A-Za-z])$",
      "replacement": "录制音频$1"
    },
    {
      "regex": "^Create\\s+(?:New\\s+)?Project$",
      "replacement": "新建项目"
    },
    {
      "regex": "^New Terminal(\\s+Ctrl\\+Shift\\+.*?)$",
      "replacement": "新建终端$1"
    },
    {
      "regex": "^Add Terminal(\\s+Ctrl\\+Shift\\+.*?)$",
      "replacement": "添加终端$1"
    },
    {
      "regex": "^Add Context(\\s+.*)$",
      "replacement": "添加上下文$1"
    },
    {
      "regex": "^(\\d+)\\s+agents?\\s+running$",
      "replacement": "$1 个运行中的智能体"
    },
    {
      "regex": "Remote Control,\\s*or\\s*",
      "replacement": "远程控制，或 "
    },
    {
      "regex": "^(?:继承您的全局权限|Inherits\\s+your\\s+(?:Global\\s+Permissions|global\\s+permissions))[\\s,，]*(?:when\\s+working\\s+in\\s+this\\s+project|在此项目中工作时)[。.]?$",
      "replacement": "在此项目中工作时，继承您的全局权限。"
    },
    {
      "regex": "^Inherits\\s+your\\s+(?:Global\\s+Permissions|global\\s+permissions)[。.]?$",
      "replacement": "继承您的全局权限。"
    },
    {
      "regex": "\\b(?:Inherits\\s+your|继承您的)[\\s,，]*(?:Global\\s+Permissions|global\\s+permissions|全局权限)[\\s,，]*(?:when\\s+working\\s+in\\s+this\\s+project|在此项目中工作时)[。.]?",
      "replacement": "在此项目中工作时，继承您的全局权限。"
    },
    {
      "regex": "^(?:Also\\s+includes|也包含)[\\s,，]*(?:Global\\s+Permissions|global\\s+permissions|全局权限)[\\s,，]*(?:when\\s+working\\s+in\\s+this\\s+project|在此项目中工作时)[。.]?\\s*(?:Learn\\s+more|了解更多)[。.]?$",
      "replacement": "在此项目中工作时也包含全局权限。了解更多。"
    },
    {
      "regex": "^(?:Also\\s+includes|也包含)[\\s,，]*(?:Global\\s+Permissions|global\\s+permissions|全局权限)[\\s,，]*(?:when\\s+working\\s+in\\s+this\\s+project|在此项目中工作时)[。.]?$",
      "replacement": "在此项目中工作时也包含全局权限。"
    },
    {
      "regex": "\\b(?:Also\\s+includes|也包含)[\\s,，]*(?:Global\\s+Permissions|global\\s+permissions|全局权限)[\\s,，]*(?:when\\s+working\\s+in\\s+this\\s+project|在此项目中工作时)[。.]?",
      "replacement": "在此项目中工作时也包含全局权限。"
    },
    {
      "regex": "^[Rr]esets?\\s+in\\s+(\\d+)\\s*(?:d|days?)[,\\s]+(\\d+)\\s*(?:h|hours?)[,\\s]+(\\d+)\\s*(?:m|mins?|minutes?)[。.]?$",
      "replacement": "$1 天 $2 小时 $3 分钟后重置"
    },
    {
      "regex": "^[Rr]esets?\\s+in\\s+(\\d+)\\s*(?:d|days?)[,\\s]+(\\d+)\\s*(?:h|hours?)[。.]?$",
      "replacement": "$1 天 $2 小时后重置"
    },
    {
      "regex": "^[Rr]esets?\\s+in\\s+(\\d+)\\s*(?:h|hours?)[,\\s]+(\\d+)\\s*(?:m|mins?|minutes?)[。.]?$",
      "replacement": "$1 小时 $2 分钟后重置"
    },
    {
      "regex": "^[Rr]esets?\\s+in\\s+(\\d+)\\s*(?:m|mins?|minutes?)[,\\s]+(\\d+)\\s*(?:s|secs?|seconds?)[。.]?$",
      "replacement": "$1 分 $2 秒后重置"
    },
    {
      "regex": "^[Rr]esets?\\s+in\\s+(\\d+)\\s*(?:d|days?)[。.]?$",
      "replacement": "$1 天后重置"
    },
    {
      "regex": "^[Rr]esets?\\s+in\\s+(\\d+)\\s*(?:h|hours?)[。.]?$",
      "replacement": "$1 小时后重置"
    },
    {
      "regex": "^[Rr]esets?\\s+in\\s+(\\d+)\\s*(?:m|mins?|minutes?)[。.]?$",
      "replacement": "$1 分钟后重置"
    },
    {
      "regex": "^[Rr]esets?\\s+in\\s+(\\d+)\\s*(?:s|secs?|seconds?)[。.]?$",
      "replacement": "$1 秒后重置"
    },
    {
      "regex": "^[Rr]esets?\\s+in\\s+less\\s+than\\s+a\\s+minute[。.]?$",
      "replacement": "不到 1 分钟后重置"
    },
    {
      "regex": "^[Rr]esets?\\s+in\\s+a\\s+few\\s+seconds[。.]?$",
      "replacement": "几秒后重置"
    },
    {
      "regex": "^[Rr]esets?\\s+soon[。.]?$",
      "replacement": "即将重置"
    },
    {
      "regex": "\\b[Rr]esets?\\s+in\\s+(\\d+)\\s*(?:d|days?)[,\\s]+(\\d+)\\s*(?:h|hours?)",
      "replacement": "$1 天 $2 小时后重置"
    },
    {
      "regex": "\\b[Rr]esets?\\s+in\\s+(\\d+)\\s*(?:h|hours?)[,\\s]+(\\d+)\\s*(?:m|mins?|minutes?)",
      "replacement": "$1 小时 $2 分钟后重置"
    },
    {
      "regex": "\\b[Rr]esets?\\s+in\\s+(\\d+)\\s*(?:m|mins?|minutes?)[,\\s]+(\\d+)\\s*(?:s|secs?|seconds?)",
      "replacement": "$1 分 $2 秒后重置"
    },
    {
      "regex": "\\b[Rr]esets?\\s+in\\s+(\\d+)\\s*(?:d|days?)",
      "replacement": "$1 天后重置"
    },
    {
      "regex": "\\b[Rr]esets?\\s+in\\s+(\\d+)\\s*(?:h|hours?)",
      "replacement": "$1 小时后重置"
    },
    {
      "regex": "\\b[Rr]esets?\\s+in\\s+(\\d+)\\s*(?:m|mins?|minutes?)",
      "replacement": "$1 分钟后重置"
    },
    {
      "regex": "^[Rr]efreshes?\\s+in\\s+(\\d+)\\s*(?:d|days?)[,\\s]+(\\d+)\\s*(?:h|hours?)[,\\s]+(\\d+)\\s*(?:m|mins?|minutes?)[。.]?$",
      "replacement": "$1 天 $2 小时 $3 分钟后重置刷新"
    },
    {
      "regex": "^[Rr]efreshes?\\s+in\\s+(\\d+)\\s*(?:d|days?)[,\\s]+(\\d+)\\s*(?:h|hours?)[。.]?$",
      "replacement": "$1 天 $2 小时后重置刷新"
    },
    {
      "regex": "^[Rr]efreshes?\\s+in\\s+(\\d+)\\s*(?:h|hours?)[,\\s]+(\\d+)\\s*(?:m|mins?|minutes?)[。.]?$",
      "replacement": "$1 小时 $2 分钟后重置刷新"
    },
    {
      "regex": "^[Rr]efreshes?\\s+in\\s+(\\d+)\\s*(?:m|mins?|minutes?)[,\\s]+(\\d+)\\s*(?:s|secs?|seconds?)[。.]?$",
      "replacement": "$1 分 $2 秒后重置刷新"
    },
    {
      "regex": "^[Rr]efreshes?\\s+in\\s+(\\d+)\\s*(?:d|days?)[。.]?$",
      "replacement": "$1 天后重置刷新"
    },
    {
      "regex": "^[Rr]efreshes?\\s+in\\s+(\\d+)\\s*(?:h|hours?)[。.]?$",
      "replacement": "$1 小时后重置刷新"
    },
    {
      "regex": "^[Rr]efreshes?\\s+in\\s+(\\d+)\\s*(?:m|mins?|minutes?)[。.]?$",
      "replacement": "$1 分钟后重置刷新"
    },
    {
      "regex": "^[Rr]efreshes?\\s+in\\s+(\\d+)\\s*(?:s|secs?|seconds?)[。.]?$",
      "replacement": "$1 秒后重置刷新"
    },
    {
      "regex": "^[Rr]efreshes?\\s+soon[。.]?$",
      "replacement": "即将重置刷新"
    },
    {
      "regex": "^(?:All|全部)\\s+scheduled\\s+tasks\\s+run\\s+as\\s+(.+?)[。.]?$",
      "replacement": "所有定时任务均以 $1 模型运行。"
    },
    {
      "regex": "^scheduled\\s+tasks\\s+run\\s+as\\s+(.+?)[。.]?$",
      "replacement": "定时任务均以 $1 模型运行。"
    },
    {
      "regex": "^Search\\s+tasks[\\.…]*$",
      "replacement": "搜索任务..."
    },
    {
      "regex": "^Search\\s+conversations[\\.…]*$",
      "replacement": "搜索会话..."
    },
    {
      "regex": "^Enter\\s+scheduled\\s+task\\s+name[\\.…]*$",
      "replacement": "输入定时任务名称..."
    },
    {
      "regex": "^Enter\\s+a\\s+prompt\\s+for\\s+the\\s+agent\\s+to\\s+run[\\.…]*$",
      "replacement": "输入供智能体执行的提示词..."
    },
    {
      "regex": "\\bProject\\s*\\+\\s*Worktree\\b",
      "replacement": "项目 + 工作树"
    },
    {
      "regex": "^Undo\\s+to\\s+(?:this\\s+point|here)[。.]?$",
      "replacement": "撤销到此处"
    },
    {
      "regex": "^Failed\\s+to\\s+revalidate\\s+slash\\s+commands:[\\s]*(.*)$",
      "replacement": "重新验证斜杠命令失败：$1"
    },
    {
      "regex": "^Failed\\s+to\\s+add\\s+plugin[。.]?\\s*(?:Please\\s+try\\s+again[。.]?)?$",
      "replacement": "添加插件失败。请重试。"
    },
    {
      "regex": "^(?:All|全部)\\s+scheduled\\s+tasks?\\s+run\\s+as\\s+(.+?)[。.]?$",
      "replacement": "所有定时任务均以 $1 模型运行。"
    },
    {
      "regex": "^(?:All|全部)\\s+plugins?\\s+run\\s+as\\s+(.+?)[。.]?$",
      "replacement": "所有插件均以 $1 模型运行。"
    },
    {
      "regex": "^(?:All|全部)\\s+automations?\\s+run\\s+as\\s+(.+?)[。.]?$",
      "replacement": "所有自动化任务均以 $1 模型运行。"
    },
    {
      "regex": "^Mark\\s+all\\s+(\\d+)\\s+conversations\\s+as\\s+read$",
      "replacement": "将全部 $1 个会话标记为已读"
    },
    {
      "regex": "^Mark\\s+(\\d+)\\s+conversations?\\s+as\\s+read$",
      "replacement": "将 $1 个会话标记为已读"
    },
    {
      "regex": "^Are\\s+you\\s+sure\\s+you\\s+want\\s+to\\s+mark\\s+all\\s+(\\d+)\\s+conversations\\s+as\\s+read\\?\\s+This\\s+action\\s+cannot\\s+be\\s+undone\\.?$",
      "replacement": "您确定要将全部 $1 个会话标记为已读吗？此操作无法撤销。"
    },
    {
      "regex": "^Are\\s+you\\s+sure\\s+you\\s+want\\s+to\\s+mark\\s+(\\d+)\\s+conversations?\\s+as\\s+read\\?\\s+This\\s+action\\s+cannot\\s+be\\s+undone\\.?$",
      "replacement": "您确定要将 $1 个会话标记为已读吗？此操作无法撤销。"
    },
    {
      "regex": "\\bWorkspace\\s*\\+\\s*Worktree\\b",
      "replacement": "工作区 + 工作树"
    },
    {
      "regex": "^(\\d+)\\s+active\\s+conversations?$",
      "replacement": "$1 个活跃会话"
    },
    {
      "regex": "^(\\d+)\\s+archived\\s+conversations?$",
      "replacement": "$1 个已归档会话"
    },
    {
      "regex": "^Try\\s+(?:远程控制|Remote Control)$",
      "replacement": "体验远程控制"
    },
    {
      "regex": "^(\\d+)\\s+tools?\\s+enabled$",
      "replacement": "已启用 $1 个工具"
    },
    {
      "regex": "^Plugin:\\s*(.*)$",
      "replacement": "插件: $1"
    },
    {
      "regex": "^This plugin provides a specialized suite of skills for data engineers.*$",
      "replacement": "此插件为在 Google Cloud 上工作的数据工程师和数据库从业者提供专业技能套件。它充当专家助手，让您轻松与数据库交互、分析数据并优化数据库工作负载。"
    },
    {
      "regex": "^Build applications with the Gemini Interactions API.*$",
      "replacement": "使用 Gemini Interactions API 和 Live API 构建应用，包括文本生成、多轮对话、流式传输、函数调用、托管智能体以及实时音视频。"
    },
    {
      "regex": "^Kick off work on your computer and continue working with your agents from your phone or another device\\.\\s*Turn on (?:远程控制|Remote Control) in app settings\\.?$",
      "replacement": "在您的计算机上开启工作，并通过手机或其他设备继续与您的智能体协同。可在应用设置中开启远程控制。"
    },
    {
      "regex": "^Build with (.+) Plugins$",
      "replacement": "Build with $1 插件目录"
    },
    {
      "regex": "^Plugins are packaged collections of skills and MCPs to help the Agent in (.+?) work with Google developer products\\.\\s*You can always change your choices in Settings\\.?$",
      "replacement": "插件是技能与 MCP 的打包集合，用于辅助 $1 中的智能体协同使用 Google 开发者产品。您随时可以在“设置”中更改选择。"
    },
    {
      "regex": "^Plugins are packaged collections of skills and MCPs to help the Agent work with Google developer products\\.\\s*You can always change your choices in Settings\\.?$",
      "replacement": "插件是技能与 MCP 的打包集合，用于辅助智能体协同使用 Google 开发者产品。您随时可以在“设置”中更改选择。"
    },
    {
      "regex": "^There are currently no Build with (.+) plugins available\\.?$",
      "replacement": "当前暂无可用的 Build with $1 插件。"
    },
    {
      "regex": "^Specialized suite of skills for data engineers and database practitioners (?:working )?on Google Cloud\\.?$",
      "replacement": "专为 Google Cloud 上的数据工程师与数据库从业者打造的专业技能套件。"
    },
    {
      "regex": "^(\\d+)\\s+tools?\\s+disabled$",
      "replacement": "已禁用 $1 个工具"
    },
    {
      "regex": "^Disable\\s+(.+)\\s+tool\\s+for\\s+(.+)$",
      "replacement": "为 $2 禁用 $1 工具"
    },
    {
      "regex": "^Enable\\s+(.+)\\s+tool\\s+for\\s+(.+)$",
      "replacement": "为 $2 启用 $1 工具"
    },
    {
      "regex": "^Auth code for (.+)$",
      "replacement": "$1 的授权码"
    },
    {
      "regex": "^The (.+) MCP server requires configuration parameters before it can be started\\.?$",
      "replacement": "$1 MCP 服务需要先配置参数才能启动。"
    },
    {
      "regex": "^See more in (.+)$",
      "replacement": "在 $1 中查看更多"
    },
    {
      "regex": "^(?:See less|收起) in (.+)$",
      "replacement": "在 $1 中收起"
    },
    {
      "regex": "^(?:More actions|更多操作) for (.+)$",
      "replacement": "$1 的更多操作"
    },
    {
      "regex": "^Failed to enable plugin (.+)$",
      "replacement": "启用插件 $1 失败"
    },
    {
      "regex": "^Failed to update agent:\\s*(.+)$",
      "replacement": "更新智能体失败：$1"
    },
    {
      "regex": "^Failed to remove agent:\\s*(.+)$",
      "replacement": "移除智能体失败：$1"
    },
    {
      "regex": "^Failed to remove plugin:\\s*(.+)$",
      "replacement": "移除插件失败：$1"
    },
    {
      "regex": "^Failed to toggle plugin:\\s*(.+)$",
      "replacement": "切换插件状态失败：$1"
    },
    {
      "regex": "^Error updating agent:\\s*(.+)$",
      "replacement": "更新智能体出错：$1"
    },
    {
      "regex": "^Failed to write MCP config:\\s*(.+)$",
      "replacement": "写入 MCP 配置失败：$1"
    },
    {
      "regex": "^Unnamed [Aa]gent (\\d+)$",
      "replacement": "未命名智能体 $1"
    },
    {
      "regex": "^Unnamed [Ss]kill (\\d+)$",
      "replacement": "未命名技能 $1"
    },
    {
      "regex": "^UI Extension (\\d+)$",
      "replacement": "界面扩展 $1"
    },
    {
      "regex": "^Automation (\\d+)$",
      "replacement": "自动化任务 $1"
    },
    {
      "regex": "^Rule (\\d+)$",
      "replacement": "规则 $1"
    },
    {
      "regex": "^Show (\\d+) breakdowns?$",
      "replacement": "显示 $1 项明细"
    },
    {
      "regex": "^(.+),\\s*setup required$",
      "replacement": "$1（需要配置）"
    },
    {
      "regex": "^Your\\s+plan's\\s+baseline\\s+quota\\s+will\\s+refresh\\s+on\\s+(.+?)\\.\\s+You\\s+can\\s+upgrade\\s+to\\s+a\\s+Google\\s+AI\\s+Ultra\\s+plan\\s+to\\s+receive\\s+higher\\s+rate\\s+limits[。.]?$",
      "replacement": "您的套餐基础配额将于 $1 重置刷新。您可以升级至 Google AI Ultra 以获取更高的请求配额与速率上限。"
    },
    {
      "regex": "^Your\\s+plan's\\s+baseline\\s+quota\\s+will\\s+refresh\\s+on\\s+(.+?)\\.\\s+To\\s+continue\\s+using\\s+this\\s+model\\s+now,\\s*enable\\s+AI\\s+Credit\\s+overages[。.]?$",
      "replacement": "您的套餐基础配额将于 $1 重置刷新。若要立即继续使用此模型，请启用超额 AI 积分计费。"
    },
    {
      "regex": "^Your\\s+plan's\\s+baseline\\s+quota\\s+will\\s+refresh\\s+on\\s+([^.。]+)[。.]?$",
      "replacement": "您的套餐基础配额将于 $1 重置刷新。"
    },
    {
      "regex": "^(?:Model|Your)\\s+quota\\s+will\\s+refresh\\s+on\\s+([^.。]+)[。.]?$",
      "replacement": "您的模型配额将于 $1 重置刷新。"
    },
    {
      "regex": "^You\\s+need\\s+at\\s+least\\s+(\\d+)\\s+AI\\s+Credits\\s+to\\s+send\\s+messages[。.]?$",
      "replacement": "您至少需要 $1 点 AI 积分才能发送消息。"
    },
    {
      "regex": "^To\\s+continue\\s+using\\s+this\\s+model\\s+now,\\s*purchase\\s+more\\s+AI\\s+Credits[。.]?$",
      "replacement": "若要立即继续使用此模型，请购买更多 AI 积分。"
    },
    {
      "regex": "^To\\s+continue\\s+using\\s+this\\s+model\\s+now,\\s*enable\\s+AI\\s+Credit\\s+overages[。.]?$",
      "replacement": "若要立即继续使用此模型，请启用超额 AI 积分计费。"
    },
    {
      "regex": "^To\\s+continue\\s+using\\s+(.+?)\\s+now,\\s*purchase\\s+more\\s+AI\\s+Credits[。.]?$",
      "replacement": "若要立即继续使用 $1，请购买更多 AI 积分。"
    },
    {
      "regex": "^To\\s+continue\\s+using\\s+(.+?)\\s+now,\\s*enable\\s+AI\\s+Credit\\s+overages[。.]?$",
      "replacement": "若要立即继续使用 $1，请启用超额 AI 积分计费。"
    },
    {
      "regex": "^Available\\s+AI\\s+Credits:\\s*(.+)$",
      "replacement": "可用 AI 积分：$1"
    },
    {
      "regex": "^Shared\\s+with:\\s*(.+)$",
      "replacement": "共享模型：$1"
    },
    {
      "regex": "^Your\\s+Plan:\\s*(.+)$",
      "replacement": "当前方案：$1"
    },
    {
      "regex": "^(\\d+)\\s+models\\s+selected$",
      "replacement": "已选择 $1 个模型"
    },
    {
      "regex": "^Select\\s+model,\\s*current:\\s*(.+)$",
      "replacement": "选择模型，当前：$1"
    },
    {
      "regex": "^You have (\\d+) conversations in progress\\. Updating will interrupt them, and they will automatically resume once the update completes\\.$",
      "replacement": "您当前有 $1 个正在进行的会话。更新将暂时中断这些会话，并在更新完成后自动恢复。"
    },
    {
      "regex": "^You have (\\d+) conversations in progress\\. Updating will cancel them and you'll need to manually restart them\\.$",
      "replacement": "您当前有 $1 个正在进行的会话。更新将取消这些会话，更新后您需要手动重新开始。"
    },
    {
      "regex": "^Set up (.+)$",
      "replacement": "设置 $1"
    },
    {
      "regex": "^Review permissions for (.+)$",
      "replacement": "审查 $1 的权限"
    },
    {
      "regex": "^(.+) needs a few details from you before it can run\\.$",
      "replacement": "$1 运行前需要您补充几项详细信息。"
    },
    {
      "regex": "^Agents created by (.+) run in a dedicated (?:project|workspace) with its own permissions, which you can change anytime in the (?:project|workspace) settings page\\. On top of those defaults, (.+) requests the access below\\.$",
      "replacement": "由 $1 创建的智能体将在专属工作区中运行并拥有独立权限，您可以随时在设置页面中更改。除默认权限外，$2 还请求以下访问权限。"
    },
    {
      "regex": "^Agents created by (.+) run in a dedicated (?:project|workspace) with its own permissions, which you can change anytime in the (?:project|workspace) settings page\\.$",
      "replacement": "由 $1 创建的智能体将在专属工作区中运行并拥有独立权限，您可以随时在设置页面中更改。"
    },
    {
      "regex": "^On top of those defaults, (.+) requests the access below\\.$",
      "replacement": "除默认权限外，$1 还请求以下访问权限。"
    },
    {
      "regex": "^Failed to load skills:\\s*(.+)$",
      "replacement": "加载技能失败：$1"
    },
    {
      "regex": "^Failed to scan skills config file:\\s*(.+)$",
      "replacement": "扫描技能配置文件失败：$1"
    },
    {
      "regex": "^Failed to load page (\\d+):\\s*(.+)$",
      "replacement": "加载第 $1 页失败：$2"
    },
    {
      "regex": "^Failed to load text layer for page (\\d+):\\s*(.+)$",
      "replacement": "加载第 $1 页的文本图层失败：$2"
    },
    {
      "regex": "^Text layer render failed:\\s*(.+)$",
      "replacement": "文本图层渲染失败：$1"
    },
    {
      "regex": "^Failed to initialize text layer:\\s*(.+)$",
      "replacement": "初始化文本图层失败：$1"
    },
    {
      "regex": "^Tool Definition:\\s*(.+)$",
      "replacement": "工具定义：$1"
    },
    {
      "regex": "^Invocation:\\s*(.+)$",
      "replacement": "调用：$1"
    },
    {
      "regex": "^Agent permissions preset selector, current:\\s*(.+)$",
      "replacement": "智能体权限预设选择器，当前：$1"
    },
    {
      "regex": "^([\\d,]+)\\s*\\/\\s*([\\d,]+)\\s*tokens\\s*\\(([\\d.]+%)\\)$",
      "replacement": "$1 / $2 个 Token ($3)"
    },
    {
      "regex": "^\\(([\\d,]+)\\s*tokens\\)\\s*([\\d.]+%)$",
      "replacement": "($1 个 Token) $2"
    },
    {
      "regex": "^\\(([\\d,]+)\\s*tokens\\)$",
      "replacement": "($1 个 Token)"
    },
    {
      "regex": "^Unused capacity:\\s*([\\d,]+)\\s*tokens$",
      "replacement": "未用容量：$1 个 Token"
    },
    {
      "regex": "^Rules:\\s*([\\d,]+)\\s*tokens$",
      "replacement": "规则：$1 个 Token"
    },
    {
      "regex": "^Skills:\\s*([\\d,]+)\\s*tokens$",
      "replacement": "技能：$1 个 Token"
    },
    {
      "regex": "^Subagents:\\s*([\\d,]+)\\s*tokens$",
      "replacement": "子智能体：$1 个 Token"
    },
    {
      "regex": "^MCP Tools:\\s*([\\d,]+)\\s*tokens$",
      "replacement": "MCP 工具：$1 个 Token"
    },
    {
      "regex": "^MCP Servers:\\s*([\\d,]+)\\s*tokens$",
      "replacement": "MCP 服务：$1 个 Token"
    },
    {
      "regex": "^System Prompt:\\s*([\\d,]+)\\s*tokens$",
      "replacement": "系统提示词：$1 个 Token"
    },
    {
      "regex": "^Customizations:\\s*([\\d,]+)\\s*tokens$",
      "replacement": "自定义扩展：$1 个 Token"
    },
    {
      "regex": "^Other Customizations:\\s*([\\d,]+)\\s*tokens$",
      "replacement": "其他自定义扩展：$1 个 Token"
    },
    {
      "regex": "^(.+):\\s*([\\d,]+)\\s*tokens$",
      "replacement": "$1：$2 个 Token"
    },
    {
      "regex": "^(\\d+)\\s+demoted$",
      "replacement": "$1 项已降级"
    },
    {
      "regex": "^(\\d+)\\s+excluded$",
      "replacement": "$1 项已排除"
    },
    {
      "regex": "^(\\d+)\\s+tools?\\s+excluded$",
      "replacement": "已排除 $1 个工具"
    },
    {
      "regex": "^(\\d+)\\s+tools$",
      "replacement": "$1 个工具"
    },
    {
      "regex": "^Show\\s+(\\d+)\\s+breakdowns?$",
      "replacement": "显示 $1 项明细"
    },
    {
      "regex": "^(\\d+)\\s+rules?\\s+exceeded the rules budget and (?:was|were) demoted from full inline content to a file-path pointer\\.$",
      "replacement": "$1 条规则超出规则预算，已从完整内联内容降级为文件路径指针。"
    },
    {
      "regex": "^(\\d+)\\s+items?\\s+in\\s+(.+?)\\s+exceeded the customization budget and (?:was|were) excluded from context\\.$",
      "replacement": "$2 中的 $1 个项目超出自定义扩展预算，已从上下文中排除。"
    },
    {
      "regex": "^Exceeded the rules token budget\\. Full rule content \\(([\\d,]+)\\s*tokens\\) was replaced with a lightweight file-path pointer in context\\.$",
      "replacement": "已超出规则 Token 预算。完整规则内容（$1 个 Token）已在上下文中替换为轻量级文件路径指针。"
    },
    {
      "regex": "^All tools in this MCP server \\(([\\d,]+)\\s*tokens\\) exceeded the customization budget and were excluded from context\\.$",
      "replacement": "此 MCP 服务中的所有工具（$1 个 Token）均超出自定义扩展预算，已从上下文中排除。"
    },
    {
      "regex": "^(\\d+)\\s+tools?\\s+in this MCP server \\(([\\d,]+)\\s*tokens\\) exceeded the customization budget and were excluded from context\\.$",
      "replacement": "此 MCP 服务中的 $1 个工具（$2 个 Token）超出自定义扩展预算，已从上下文中排除。"
    },
    {
      "regex": "^Exceeded the customization token budget \\(([\\d,]+)\\s*tokens\\) and was excluded from context\\.$",
      "replacement": "已超出自定义扩展 Token 预算（$1 个 Token），已从上下文中排除。"
    },
    {
      "regex": "^Worked\\s+for\\s+(\\d+)\\s*d\\s+(\\d+)\\s*h\\s+(\\d+)\\s*m$",
      "replacement": "已工作 $1 天 $2 小时 $3 分钟"
    },
    {
      "regex": "^Stopped\\s+after\\s+(\\d+)\\s*d\\s+(\\d+)\\s*h\\s+(\\d+)\\s*m$",
      "replacement": "在 $1 天 $2 小时 $3 分钟后停止"
    },
    {
      "regex": "^Send\\s+feedback\\s+as\\s+(.+)$",
      "replacement": "以 $1 身份发送反馈"
    },
    {
      "regex": "^Branch\\s+([a-zA-Z0-9_\\-\\.\\/]+)$",
      "replacement": "分支 $1"
    },
    {
      "regex": "^All changes since\\s+(.+)$",
      "replacement": "自 $1 以来的全部更改"
    },
    {
      "regex": "^(\\d+)\\s+commits?\\s+to\\s+push$",
      "replacement": "$1 个待推送的提交"
    },
    {
      "regex": "^(\\d+)\\s+commits?\\s+to\\s+pull$",
      "replacement": "$1 个待拉取的提交"
    },
    {
      "regex": "^Send\\s+[mM]essage\\s+(Enter|Return|Ctrl\\+Enter|Cmd\\+Enter|↵)$",
      "replacement": "发送消息 $1"
    },
    {
      "regex": "^Send\\s+[mM]essage\\s+\\((Enter|Return|Ctrl\\+Enter|Cmd\\+Enter|↵)\\)$",
      "replacement": "发送消息 ($1)"
    },
    {
      "regex": "^Playback speed ([0-9.]+)x$",
      "replacement": "播放倍速 $1x"
    },
    {
      "regex": "^Zoom (\\d+)%, reset to fit$",
      "replacement": "缩放 $1%，点击重置为适应屏幕"
    },
    {
      "regex": "^Enlarged media:\\s*(.+)$",
      "replacement": "放大查看媒体：$1"
    },
    {
      "regex": "^Fix with Agent:\\s*(.+)$",
      "replacement": "使用智能体修复：$1"
    },
    {
      "regex": "^Error restarting (.+?):\\s*(.+)$",
      "replacement": "重启 $1 时出错：$2"
    },
    {
      "regex": "^Zipping\\s+(.+?)(?:…|\\.\\.\\.)?$",
      "replacement": "正在压缩 $1…"
    },
    {
      "regex": "^Could not attach folder \"(.+?)\":\\s*Folder is empty$",
      "replacement": "无法附加文件夹“$1”：文件夹为空"
    },
    {
      "regex": "^Could not attach folder \"(.+?)\":\\s*Folder has more than 1000 files$",
      "replacement": "无法附加文件夹“$1”：文件夹包含超过 1000 个文件"
    },
    {
      "regex": "^Could not attach folder \"(.+?)\":\\s*Folder is larger than 20MB$",
      "replacement": "无法附加文件夹“$1”：文件夹大小超过 20MB"
    },
    {
      "regex": "^Could not attach folder \"(.+?)\":\\s*(.+)$",
      "replacement": "无法附加文件夹“$1”：$2"
    },
    {
      "regex": "^Could not open folder:\\s*(.+)$",
      "replacement": "无法打开文件夹：$1"
    },
    {
      "regex": "^Search for \"(.+?)\" in the Marketplace$",
      "replacement": "在扩展市场中搜索“$1”"
    },
    {
      "regex": "^No plugins found for \"(.+?)\"\\.$",
      "replacement": "未找到与“$1”相关的插件。"
    },
    {
      "regex": "^(\\d+) matching bundles?$",
      "replacement": "$1 个匹配的组合包"
    },
    {
      "regex": "^Get Anything Done with\\s+(.+)$",
      "replacement": "借助 $1 搞定一切"
    },
    {
      "regex": "^Select\\s+(.+?)\\s+Theme$",
      "replacement": "选择 $1 主题"
    }
  ]
};
    /**
 * Antigravity Chinese Localization Engine (Runtime v3.3.4)
 * 支持 2.17.0 复合 Alert 自愈 / WSL 跨平台菜单与弹窗适配 / 官方 10 大插件与 131 项技能全量汉化 / 极速性能闭环
 *
 * 核心改进：
 * 1. 彻底阻断 requestIdleCallback 自旋死循环，改为 15 秒低频保底扫描
 * 2. 增加 DOM 否定标记，未命中节点二次扫描 O(1) 瞬时退出
 * 3. 增加悬浮 Portal/Tooltip 门禁过滤与 100ms 节流阀，根绝 mouseover 树暴搜
 * 4. 算法与死代码优化：英文字母快速短路、移除 Step 5 patterns 死代码、空格/长度门禁、双向 Map 缓存
 */
(function (root) {
  'use strict';

  if (!root) {
    root = typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this);
  }
  if (!root) return;

  function createI18nEngine(dictData) {
    var data = dictData || {};
    var exactDict = data.exact || {};
    var allPatterns = (data.patterns || []).concat(data.rules || []);
    var patterns = allPatterns.map(function (p) {
      return {
        regex: new RegExp(p.regex),
        replacement: p.replacement
      };
    });

    var translatedValues = {};
    for (var k in exactDict) {
      if (exactDict.hasOwnProperty(k)) {
        translatedValues[exactDict[k]] = true;
      }
    }

    var translationCache = typeof Map !== 'undefined' ? new Map() : null;
    var MAX_CACHE_SIZE = 10000;

    function cacheAndReturn(key, value) {
      if (translationCache) {
        if (translationCache.size >= MAX_CACHE_SIZE) {
          var iter = translationCache.keys();
          for (var ci = 0; ci < 1000; ci++) {
            var oldK = iter.next().value;
            if (oldK !== undefined) {
              translationCache.delete(oldK);
            } else {
              break;
            }
          }
        }
        translationCache.set(key, value);
      }
      return value;
    }

    function normalizeWhitespace(str) {
      return str.replace(/\s+/g, ' ').trim();
    }

    var hasOwn = Object.prototype.hasOwnProperty;

    function translateSingleUnit(rawStr) {
      if (!rawStr || typeof rawStr !== 'string') return null;
      var normalized = normalizeWhitespace(rawStr);
      if (!normalized) return null;

      if (translationCache && translationCache.has(normalized)) {
        return translationCache.get(normalized);
      }

      if (hasOwn.call(exactDict, normalized)) {
        return cacheAndReturn(normalized, exactDict[normalized]);
      }

      if (!/[a-zA-Z]/.test(normalized)) {
        return cacheAndReturn(normalized, null);
      }

      if (hasOwn.call(translatedValues, normalized)) {
        return cacheAndReturn(normalized, null);
      }

      if (/[\u4e00-\u9fa5]/.test(normalized) && !/[a-zA-Z]{2,}/.test(normalized)) {
        return cacheAndReturn(normalized, null);
      }

      for (var i = 0; i < patterns.length; i++) {
        var p = patterns[i];
        if (p.regex.test(normalized)) {
          var result = normalized.replace(p.regex, p.replacement);
          for (var pi = 0; pi < patterns.length; pi++) {
            if (patterns[pi].regex.test(result)) {
              result = result.replace(patterns[pi].regex, patterns[pi].replacement);
            }
          }
          p.regex.lastIndex = 0;
          return cacheAndReturn(normalized, result);
        }
      }

      var punctuationMatch = normalized.match(/^([\w\s\-\/]+)([:：…\.？\?!！]+)$/);
      if (punctuationMatch) {
        var base = punctuationMatch[1].trim();
        var punc = punctuationMatch[2];
        if (hasOwn.call(exactDict, base)) {
          return cacheAndReturn(normalized, exactDict[base] + (punc === ':' ? '：' : punc));
        }
      }

      var hotkeyMatch = normalized.match(/^([\w\s\-\/]+?)\s*(\((?:Ctrl|Cmd|Alt|Shift)\+[^\s\)]+\)|\b(?:Ctrl|Cmd|Alt|Shift)\+[\w;:,\\/+\-]+)$/i);
      if (hotkeyMatch) {
        var cmdBase = hotkeyMatch[1].trim();
        var hotkey = hotkeyMatch[2].trim();
        if (hasOwn.call(exactDict, cmdBase)) {
          return cacheAndReturn(normalized, exactDict[cmdBase] + (hotkey.charAt(0) === '(' ? ' ' + hotkey : ' ' + hotkey));
        }
      }

      if (normalized.indexOf('. ') !== -1 || normalized.indexOf('! ') !== -1 || normalized.indexOf('? ') !== -1 || normalized.indexOf('。') !== -1) {
        var sentences = normalized.split(/([.!?]\s+|[。！？]\s*)/);
        var anyTranslated = false;
        var allTranslated = true;
        var translatedParts = [];
        for (var sIdx = 0; sIdx < sentences.length; sIdx++) {
          var part = sentences[sIdx];
          var trimmedPart = part.trim();
          if (!trimmedPart || /^[.!?。！？\s]+$/.test(part)) {
            translatedParts.push(part.replace(/\.\s*/g, '。 '));
            continue;
          }
          var transPart = (hasOwn.call(exactDict, trimmedPart) ? exactDict[trimmedPart] : null) ||
                          (hasOwn.call(exactDict, trimmedPart + '.') ? exactDict[trimmedPart + '.'] : null);
          if (!transPart) {
            for (var pIdx = 0; pIdx < patterns.length; pIdx++) {
              if (patterns[pIdx].regex.test(trimmedPart)) {
                transPart = trimmedPart.replace(patterns[pIdx].regex, patterns[pIdx].replacement);
                for (var pi2 = 0; pi2 < patterns.length; pi2++) {
                  if (patterns[pi2].regex.test(transPart)) {
                    transPart = transPart.replace(patterns[pi2].regex, patterns[pi2].replacement);
                  }
                }
                break;
              }
            }
          }
          if (!transPart) {
            var pMatch = trimmedPart.match(/^([\w\s\-\/]+)([:：…\.？\?!！]+)$/);
            if (pMatch && hasOwn.call(exactDict, pMatch[1].trim())) {
              transPart = exactDict[pMatch[1].trim()] + (pMatch[2] === ':' ? '：' : pMatch[2]);
            }
          }
          if (transPart) {
            anyTranslated = true;
            translatedParts.push(transPart);
          } else {
            allTranslated = false;
            translatedParts.push(part);
          }
        }
        if (anyTranslated && allTranslated) {
          return cacheAndReturn(normalized, translatedParts.join('').replace(/([。！？])[。！？.]*\s*/g, '$1 ').trim());
        }
      }

      return cacheAndReturn(normalized, null);
    }

    return {
      translate: translateSingleUnit,
      exactDict: exactDict,
      patterns: patterns,
      cache: translationCache,
      normalizeWhitespace: normalizeWhitespace
    };
  }

  // 若处于 Node.js 环境，优先准备导出
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      createI18nEngine: createI18nEngine
    };
  }

  if (root && root.__AGY_I18N_INITIALIZED__) return;
  if (root) root.__AGY_I18N_INITIALIZED__ = true;

  var doc = root ? (root.document || (typeof document !== 'undefined' ? document : null)) : null;

  var I18N_DATA = (root && root.__AGY_I18N_DATA__) || { exact: {}, patterns: [] };
  var defaultEngine = createI18nEngine(I18N_DATA);
  var exactDict = defaultEngine.exactDict;
  var patterns = defaultEngine.patterns;
  var translationCache = defaultEngine.cache;
  var normalizeWhitespace = defaultEngine.normalizeWhitespace;
  var translateSingleUnit = defaultEngine.translate;

  var IGNORED_TAGS = {
    'SCRIPT': 1, 'STYLE': 1, 'CODE': 1, 'PRE': 1, 'NOSCRIPT': 1,
    'SVG': 1, 'PATH': 1, 'CANVAS': 1,
    'IFRAME': 1, 'VIDEO': 1, 'AUDIO': 1
  };

  var IGNORED_CLASSES = [
    'monaco-editor',
    'view-lines',
    'view-line',
    'monaco-mouse-cursor-text',
    'xterm',
    'terminal',
    'token',
    'hljs',
    'code-block',
    'editor-instance'
  ];

  var TRANSLATABLE_ATTRS = ['title', 'placeholder', 'aria-label', 'data-tooltip', 'alt', 'aria-description'];

  function isModelSelectorBoundary(elem) {
    if (!elem || elem.nodeType !== 1) return false;
    var testId = elem.getAttribute ? elem.getAttribute('data-testid') : null;
    if (testId) {
      if (testId === 'model-selector-trigger' ||
          testId === 'model-selector-item' ||
          testId === 'model-selector-effort-option' ||
          testId === 'model-selector-effort-group' ||
          testId === 'model-selector-list') {
        return true;
      }
    }
    if (elem.hasAttribute && elem.hasAttribute('data-effort')) {
      return true;
    }
    return false;
  }

  function isThinkingContentBoundary(elem) {
    if (!elem || elem.nodeType !== 1) return false;
    if (elem.getAttribute && elem.getAttribute('role') === 'group') {
      var prev = elem.previousElementSibling;
      if (prev && prev.getAttribute && prev.getAttribute('data-testid') === 'thinking-collapsible-trigger') {
        return true;
      }
    }
    return false;
  }

  function shouldIgnoreElement(el) {
    if (!el || el.nodeType !== 1) return false;
    if (IGNORED_TAGS[el.tagName]) return true;
    if (el.isContentEditable) return true;

    // 模型选择器与思考过程内容区保持英文/原版原样
    if (isModelSelectorBoundary(el) || isThinkingContentBoundary(el)) return true;

    var className = typeof el.className === 'string' ? el.className : '';
    if (className) {
      for (var i = 0; i < IGNORED_CLASSES.length; i++) {
        if (className.indexOf(IGNORED_CLASSES[i]) !== -1) return true;
      }
    }

    // 向上检查最近 6 层祖先，防止子文本/段落元素在受保护区域（如思考内容面板、模型选择器内部）被静态词典替换
    var ancestor = el.parentElement;
    for (var depth = 0; ancestor && depth < 6; depth++) {
      if (IGNORED_TAGS[ancestor.tagName]) return true;
      if (isModelSelectorBoundary(ancestor) || isThinkingContentBoundary(ancestor)) return true;
      var ancestorClass = typeof ancestor.className === 'string' ? ancestor.className : '';
      if (ancestorClass && depth < 3) {
        for (var ci = 0; ci < IGNORED_CLASSES.length; ci++) {
          if (ancestorClass.indexOf(IGNORED_CLASSES[ci]) !== -1) return true;
        }
      }
      ancestor = ancestor.parentElement;
    }
    return false;
  }



  // 标记属性名，用于避免重复翻译
  var MARK_ATTR = '_agyDone';

  // 扫描轮次 ID，同一轮全量扫描中元素只处理一次
  var currentScanId = 0;

  function translateTextNode(node) {
    if (!node || node.nodeType !== 3) return;
    var parent = node.parentElement || node.parentNode;
    if (parent && (shouldIgnoreElement(parent) || parent.tagName === 'INPUT' || parent.tagName === 'TEXTAREA')) return;

    var original = node.nodeValue;
    if (!original) return;

    // 如果节点已标记原始文本且未变化，直接 O(1) 瞬时退出
    if (node._agyOriginal === original) return;

    var trimmed = original.trim();
    if (!trimmed) {
      // 对纯空白节点补充否定标记，二次扫描直接 O(1) 退出，避免重复调用 trim()
      node._agyOriginal = original;
      return;
    }

    if (trimmed === '.' && node.previousSibling && /[\u4e00-\u9fa5]/.test(node.previousSibling.textContent || '')) {
      node.nodeValue = original.replace('.', '。');
      node._agyOriginal = node.nodeValue;
      return;
    }

    var translated = translateSingleUnit(trimmed);
    if (translated !== null && translated !== trimmed) {
      var leadingSpace = original.match(/^\s*/)[0];
      var trailingSpace = original.match(/\s*$/)[0];
      // 盘古之白排版优化：若前一个兄弟节点以英数结尾且当前译文以汉字开头，自动补齐规范空格
      if (!leadingSpace && node.previousSibling) {
        var prevText = (node.previousSibling.textContent || '').trim();
        if (/[a-zA-Z0-9]$/.test(prevText) && /^[\u4e00-\u9fa5]/.test(translated)) {
          leadingSpace = ' ';
        }
      }
      node.nodeValue = leadingSpace + translated + trailingSpace;
      node._agyOriginal = node.nodeValue; // 记录翻译后的值，防止重复处理
    } else {
      // 关键性能优化：补充 DOM 否定标记，未命中时记录原始文本，二次扫描直接 O(1) 退出
      node._agyOriginal = original;
    }
  }

  function hookSameOriginIframe(iframeEl) {
    try {
      if (!iframeEl || iframeEl.tagName !== 'IFRAME') return;
      if (iframeEl.getAttribute && iframeEl.getAttribute('data-agy-ignore') === 'true') return;
      var mountSubDoc = function () {
        try {
          var subDoc = iframeEl.contentDocument || (iframeEl.contentWindow && iframeEl.contentWindow.document);
          if (!subDoc || !subDoc.documentElement) return;
          translateElement(subDoc.documentElement);
          if (!subDoc._agyIframeObserver && typeof MutationObserver !== 'undefined') {
            var subObs = new MutationObserver(function (mutations) {
              for (var mi = 0; mi < mutations.length; mi++) {
                var m = mutations[mi];
                if (m.type === 'childList') {
                  for (var ai = 0; ai < m.addedNodes.length; ai++) {
                    enqueueNode(m.addedNodes[ai]);
                  }
                } else if (m.type === 'characterData' && m.target) {
                  m.target._agyOriginal = undefined;
                  enqueueNode(m.target);
                }
              }
              if (pendingNodes.length > 0) scheduleFlush();
            });
            subObs.observe(subDoc.documentElement, { childList: true, subtree: true, characterData: true });
            subDoc._agyIframeObserver = subObs;
          }
        } catch (_) {}
      };
      if (!iframeEl._agyLoadHooked) {
        iframeEl._agyLoadHooked = true;
        if (iframeEl.addEventListener) {
          iframeEl.addEventListener('load', mountSubDoc);
        }
      }
      mountSubDoc();
    } catch (_) {}
  }

  function translateElement(el, scanId) {
    if (!el || el.nodeType !== 1) return;
    if (el.tagName === 'IFRAME') {
      hookSameOriginIframe(el);
      return;
    }
    if (shouldIgnoreElement(el)) return;

    // 同一轮扫描中，已处理的元素跳过
    if (scanId && el._agyScanId === scanId) return;
    if (scanId) el._agyScanId = scanId;

    // 复合组件自愈：处理特定 JSX 碎片化 Alert（如 plan-command-fyi-alert）
    if (el.getAttribute && el.getAttribute('data-testid') === 'plan-command-fyi-alert') {
      var alertSpan = el.querySelector ? el.querySelector('span') : null;
      if (alertSpan && !alertSpan._agyAlertDone) {
        var alertChild = alertSpan.firstChild;
        while (alertChild) {
          if (alertChild.nodeType === 3 && alertChild.nodeValue && alertChild.nodeValue.trim() === 'Type') {
            alertChild.nodeValue = alertChild.nodeValue.replace('Type', '输入');
            alertChild._agyOriginal = alertChild.nodeValue;
          }
          alertChild = alertChild.nextSibling;
        }
        alertSpan._agyAlertDone = true;
      }
    }

    // 翻译属性
    for (var i = 0; i < TRANSLATABLE_ATTRS.length; i++) {
      var attr = TRANSLATABLE_ATTRS[i];
      if (el.hasAttribute && el.hasAttribute(attr)) {
        var val = el.getAttribute(attr);
        if (val) {
          // 检查是否已翻译过此属性
          var markKey = MARK_ATTR + '_' + attr;
          if (el[markKey] === val) continue;

          var trans = translateSingleUnit(val);
          if (trans !== null && trans !== val) {
            el.setAttribute(attr, trans);
            el[markKey] = trans; // 标记已翻译的值
          } else {
            // 关键性能优化：补充 DOM 否定标记，未命中时记录原属性值，二次扫描直接 O(1) 退出
            el[markKey] = val;
          }
        }
      }
    }

    // 遍历子节点
    // 联合文本自愈：如果元素直接子节点全为纯文本节点且数量 > 1（常见于 React 碎片化模板拆分，如 "All ", e, "s run as Flash."）
    var first = el.firstChild;
    if (first && first.nextSibling) {
      var allText = true;
      var cur = first;
      while (cur) {
        if (cur.nodeType !== 3) {
          allText = false;
          break;
        }
        cur = cur.nextSibling;
      }
      if (allText) {
        var combinedText = el.textContent;
        if (combinedText) {
          var combinedTrans = translateSingleUnit(combinedText);
          if (combinedTrans !== null && combinedTrans !== combinedText) {
            first.nodeValue = combinedTrans;
            first._agyOriginal = combinedTrans;
            var other = first.nextSibling;
            while (other) {
              other.nodeValue = '';
              other._agyOriginal = '';
              other = other.nextSibling;
            }
            return;
          }
        }
      } else {
        // 跨内联元素语序重排自愈：针对 "Also includes" + <span>Global Permissions</span> + "when working in this project."
        var alsoNode = null;
        var whenNode = null;
        var scanCur = first;
        while (scanCur) {
          if (scanCur.nodeType === 3 && scanCur.nodeValue) {
            var tVal = scanCur.nodeValue.trim();
            if (tVal === 'Also includes' || tVal === '也包含') {
              alsoNode = scanCur;
            } else if (alsoNode && (tVal === 'when working in this project.' || tVal === '在此项目中工作时。')) {
              whenNode = scanCur;
              break;
            }
          }
          scanCur = scanCur.nextSibling;
        }
        if (alsoNode && whenNode) {
          alsoNode.nodeValue = '在此项目中工作时，也包含';
          alsoNode._agyOriginal = alsoNode.nodeValue;
          var between = alsoNode.nextSibling;
          while (between && between !== whenNode) {
            if (between.nodeType === 3 && !between.nodeValue.trim()) {
              between.nodeValue = '';
              between._agyOriginal = '';
            }
            between = between.nextSibling;
          }
          whenNode.nodeValue = '。';
          whenNode._agyOriginal = whenNode.nodeValue;
        }
      }
    }

    var child = el.firstChild;
    while (child) {
      if (child.nodeType === 3) {
        translateTextNode(child);
      } else if (child.nodeType === 1) {
        translateElement(child, scanId);
      }
      child = child.nextSibling;
    }
  }

  // ============ Observer 与扫描调度 ============

  var observer = null;
  var observing = false;

  function disconnectObserver() {
    if (observer && observing) {
      observer.disconnect();
      observing = false;
    }
  }

  function reconnectObserver() {
    if (observer && !observing && doc && doc.documentElement) {
      observer.observe(doc.documentElement, {
        childList: true,
        subtree: true,
        characterData: true
        // 不再监听 attributes！避免 setAttribute 触发死循环
      });
      observing = true;
    }
  }

  /**
   * 安全地翻译一组节点
   * 在翻译期间暂停 Observer，完成后重新连接
   */
  function safeTranslateNodes(nodes) {
    disconnectObserver();
    try {
      for (var i = 0; i < nodes.length; i++) {
        var node = nodes[i];
        if (node.nodeType === 1) {
          translateElement(node);
        } else if (node.nodeType === 3) {
          translateTextNode(node);
        }
      }
    } catch (e) {
      // 静默吞错，避免一个异常阻断整体
    }
    reconnectObserver();
  }

  /**
   * 安全地执行全量扫描
   */
  function safeFullScan() {
    if (!doc || !doc.documentElement) return;
    currentScanId++;
    disconnectObserver();
    try {
      translateElement(doc.documentElement, currentScanId);
    } catch (e) {}
    reconnectObserver();
  }

  // ---- 节流与去重：合并高频 mutation 到下一个 rAF ----
  var pendingNodes = [];
  var pendingNodeSet = typeof Set !== 'undefined' ? new Set() : null;
  var rafScheduled = false;

  function enqueueNode(node) {
    if (!node) return;
    if (pendingNodeSet) {
      if (pendingNodeSet.has(node)) return;
      if (pendingNodes.length < 500) {
        pendingNodes.push(node);
        pendingNodeSet.add(node);
      }
    } else {
      if (pendingNodes.length < 500) {
        pendingNodes.push(node);
      }
    }
  }

  function flushPendingNodes() {
    rafScheduled = false;
    if (pendingNodes.length === 0) return;
    var batch = pendingNodes.splice(0, 200);
    if (pendingNodeSet) {
      for (var bIdx = 0; bIdx < batch.length; bIdx++) {
        pendingNodeSet.delete(batch[bIdx]);
      }
    }
    safeTranslateNodes(batch);
    // 如果还有剩余，安排下一帧处理
    if (pendingNodes.length > 0) {
      scheduleFlush();
    }
  }

  function scheduleFlush() {
    if (!rafScheduled) {
      rafScheduled = true;
      if (root.requestAnimationFrame) {
        root.requestAnimationFrame(flushPendingNodes);
      } else {
        setTimeout(flushPendingNodes, 16);
      }
    }
  }

  function startObserver() {
    if (!doc || !doc.documentElement) return;

    // 首次全量扫描
    safeFullScan();

    var MutationObserverClass = root.MutationObserver || (typeof MutationObserver !== 'undefined' ? MutationObserver : null);
    if (MutationObserverClass) {
      observer = new MutationObserverClass(function (mutations) {
        for (var i = 0; i < mutations.length; i++) {
          var mutation = mutations[i];
          if (mutation.type === 'childList') {
            var added = mutation.addedNodes;
            for (var j = 0; j < added.length; j++) {
              enqueueNode(added[j]);
            }
          } else if (mutation.type === 'characterData') {
            // 文本内容变化，重置标记使其可以被重新翻译
            if (mutation.target) {
              mutation.target._agyOriginal = undefined;
              enqueueNode(mutation.target);
            }
          }
        }
        if (pendingNodes.length > 0) {
          scheduleFlush();
        }
      });

      reconnectObserver();
    }

    // 低频保底扫描：彻底阻断 50~60Hz 无限自旋死循环，改为每 15 秒配合 requestIdleCallback 执行一次低频保底扫描
    var idleScanScheduled = false;
    function scheduleIdleScan() {
      if (idleScanScheduled) return;
      if (root.requestIdleCallback) {
        idleScanScheduled = true;
        root.requestIdleCallback(function () {
          idleScanScheduled = false;
          safeFullScan();
        }, { timeout: 5000 });
      } else {
        safeFullScan();
      }
    }
    setInterval(scheduleIdleScan, 15000);
  }

  function isFloatingElement(el) {
    if (!el || el.nodeType !== 1) return false;
    if (doc && (el === doc.body || el === doc.documentElement)) return false;
    if (el.id === 'workbench') return false;
    var cls = typeof el.className === 'string' ? el.className : '';
    if (cls && cls.indexOf('monaco-workbench') !== -1) return false;

    if (el.matches) {
      try {
        if (el.matches('[role="tooltip"], [role="menu"], [role="dialog"], [data-floating-ui-portal], [data-radix-popper-content-wrapper], .popover, .tooltip, .context-view, .monaco-hover')) {
          return true;
        }
      } catch (e) {}
    }
    var role = el.getAttribute ? el.getAttribute('role') : '';
    if (role === 'tooltip' || role === 'menu' || role === 'dialog') return true;
    if (el.hasAttribute && (el.hasAttribute('data-floating-ui-portal') || el.hasAttribute('data-radix-popper-content-wrapper'))) return true;
    if (cls) {
      if (cls.indexOf('popover') !== -1 || cls.indexOf('tooltip') !== -1 || cls.indexOf('context-view') !== -1 || cls.indexOf('monaco-hover') !== -1) {
        return true;
      }
    }
    return false;
  }

  function isWorkbenchOrRoot(el) {
    if (!el || el.nodeType !== 1) return true;
    if (doc && (el === doc.body || el === doc.documentElement)) return true;
    if (el.id === 'workbench') return true;
    var cls = typeof el.className === 'string' ? el.className : '';
    if (cls && cls.indexOf('monaco-workbench') !== -1) return true;
    return false;
  }

  if (doc) {
    if (doc.readyState === 'loading') {
      doc.addEventListener('DOMContentLoaded', startObserver);
    } else {
      startObserver();
    }

    // 全局悬浮气泡 (Hover Tooltips / Popovers) 快速反应拦截器
    // 专门防御光标移入时才动态挂载或改变属性的临时注释节点
    try {
      var lastHoverTime = 0;
      var hoverScanTimer = null;

      function scanFloatingContainers() {
        if (!doc || !doc.body) return;
        disconnectObserver();
        try {
          // 定向扫描顶层 Portal 容器、Tooltip、Popover 节点，门禁拦截非浮层元素，绝不遍历整棵 DOM 树
          var last = doc.body.lastElementChild;
          if (last && isFloatingElement(last)) {
            translateElement(last);
          }
          if (last && last.previousElementSibling && isFloatingElement(last.previousElementSibling)) {
            translateElement(last.previousElementSibling);
          }
          var tooltips = doc.querySelectorAll ? doc.querySelectorAll('[role="tooltip"], [role="menu"], [role="dialog"], [data-floating-ui-portal], [data-radix-popper-content-wrapper], .popover, .tooltip, .context-view, .monaco-hover') : null;
          if (tooltips && tooltips.length > 0) {
            for (var tIdx = 0; tIdx < tooltips.length; tIdx++) {
              translateElement(tooltips[tIdx]);
            }
          }
        } catch (e) {}
        reconnectObserver();
      }

      var onHoverAction = function (e) {
        // 120ms 节流阀：阻断高频事件风暴，杜绝掉帧卡顿
        var now = Date.now ? Date.now() : (+new Date());
        if (now - lastHoverTime < 120) return;
        lastHoverTime = now;

        var target = e.target;
        if (!target) return;
        disconnectObserver();
        try {
          if (target.nodeType === 1) {
            translateElement(target);
            // 严禁对 #workbench / body 根容器递归全树深搜，防止剧烈掉帧
            if (target.parentElement && !isWorkbenchOrRoot(target.parentElement)) {
              translateElement(target.parentElement);
            }
          }
        } catch (e) {}
        reconnectObserver();

        // 防抖延迟定向扫描浮动提示层（捕获动态延迟 50ms 挂载的气泡）
        if (hoverScanTimer) clearTimeout(hoverScanTimer);
        hoverScanTimer = setTimeout(function () {
          hoverScanTimer = null;
          scanFloatingContainers();
        }, 50);
      };

      doc.addEventListener('pointerenter', onHoverAction, { capture: true, passive: true });
      doc.addEventListener('contextmenu', onHoverAction, { capture: true, passive: true });
    } catch (e) {}
  }

  if (root) {
    root.__AGY_CREATE_ENGINE__ = createI18nEngine;
    root.__AGY_TRANSLATE_UNIT__ = translateSingleUnit;
    root.__AGY_TRANSLATE_EL__ = translateElement;
    root.__AGY_RUN_FULL_SCAN__ = safeFullScan;
    root.__AGY_CACHE__ = translationCache;
    root.__AGY_IS_FLOATING__ = isFloatingElement;
  }
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this));


    if (window.__AGY_RUN_FULL_SCAN__) window.__AGY_RUN_FULL_SCAN__();
    if (window.electronUpdater && !window.__AGY_AUTO_UPDATE_HOOKED__) {
      window.__AGY_AUTO_UPDATE_HOOKED__ = true;
      var __triggerAutoUpdate = function(state) {
        if (state && state.type === 'ready' && !window.__AGY_UPDATE_TRIGGERED__) {
          window.__AGY_UPDATE_TRIGGERED__ = true;
          setTimeout(function() {
            try { window.electronUpdater.quitAndInstall(); } catch (_) {}
          }, 12000);
        }
      };
      if (typeof window.electronUpdater.onStateChanged === 'function') {
        window.electronUpdater.onStateChanged(__triggerAutoUpdate);
      }
      if (typeof window.electronUpdater.getState === 'function') {
        Promise.resolve(window.electronUpdater.getState()).then(__triggerAutoUpdate).catch(function() {});
      }
    }
  } catch(e) {
    console.error('[AGY-i18n] Runtime Injection Error:', e);
  }
})();